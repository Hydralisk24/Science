#include <math.h>
#include <stdio.h>

#define PI 3.14159265358979
	


struct data{
	double JD;
	double mag;	
	double err;
};










// utolagosan meghatarozza a szint (egyszeruen kivonja az egyikbol a masikat)

int main ()
{
 
 
int m=0;   // g szama
int n;

				n=8;

data Adatk[100][n];  //beolvasand� adatok a
float BC[100];
float BCe[100];

int i;   // ciklus v�ltoz�k
int j;
int k;

float e=0;   //szemet
float sz=0;  //seged
float s=0;   //seged1
float szz=0; //seged3




FILE *f[n];




//bemenet: sz�r�nk�nt 1-1
f[0]=fopen("B-gorbe.txt","r");
f[1]=fopen("V-gorbe.txt","r");
f[2]=fopen("R-gorbe.txt","r");
f[3]=fopen("I-gorbe.txt","r");

f[4]=fopen("B-gorbeC.txt","r");
f[5]=fopen("V-gorbeC.txt","r");
f[6]=fopen("R-gorbeC.txt","r");
f[7]=fopen("I-gorbeC.txt","r");




//szini kimenet
fbol=fopen("bol-gorbe.txt","wt");











// szinfugges ===============================================

for(i=0;i<100;i++) for(j=0;j<n;j++){  Adatk[i][j].err=0; Adatk[i][j].mag=0; Adatk[i][j].JD=0; }


for(i=0;i<100;i++) BC[i]=0;
for(i=0;i<100;i++) BCe[i]=0;


rewind (fg);
rewind (fi);


//g-t olvasva, hossz meghatarozashoz. Ido, g fenyesseget, hibat berakja a tombbe
printf("\nBeolvasva:\n");
m=0;
while(!feof(f[0])){
  fscanf(f[0],"%f %f %f %f\n",&Adatk[m][0].JD,&Adatk[m][0].mag,&e,&Adatk[m][0].err);
  m++; }

printf("szamolt hossz: %d, g/B\n",m);


//i-t olvasva, datummal ellenorizve, g melle rakja, hibat is
i=0;
while(!feof(f[k])){
  fscanf(f[k],"%f %f %f %f\n",&s,&sz,&e,&szz);
  for(j=0;j<m+1;j++){ if( int(s)==int(Adatk[j][0]) ){Adatk[j][2]=sz; Adatk[j][4]=sqrt(szz*szz+Adatk[j][4]*Adatk[j][4]); j=m+1;}  }
  i++; }
                   
printf("szamolt hossz: %d, r/I\n",i);

// kiszedi ha 0 van i-ben (g-ben nem lehet, mert az melle raktuk)
for(i=0;i<m+1;i++)   if(Adatk[i][2]==0){ for(j=i;j<m+1;j++) for(k=0;k<5;k++) Adatk[j][k]=Adatk[j+1][k];
					 					m--; i--;}


// extinkciora korrigal
for(i=0;i<m+1;i++){
				  Adatk[i][1]=Adatk[i][1]-nedgb;
				  Adatk[i][2]=Adatk[i][2]-nedri;
				  }



//g-i tombbe rakja, BC szamitas, kiirja
printf("\nA szinek (extinkcio korrigalt):\n");
printf("JD, g/B, r/I, g-r/B-I, hiba, BC, BC hiba\n");
for(i=0;i<m+1;i++){
                   if( Adatk[i][1]+Adatk[i][2]!=0 ) Adatk[i][3]=Adatk[i][1]-Adatk[i][2];
                   
				   BC[i] =bolom(Adatk[i][3]);
				   BCe[i]=bolomh(Adatk[i][3],Adatk[i][4]);
				   BCe[i]=sqrt(Adatk[i][1]*Adatk[i][1]+BCe[i]*BCe[i] );
				   
				   printf("%f %f %f %f %f %f %f\n",Adatk[i][0],Adatk[i][1],Adatk[i][2],Adatk[i][3],Adatk[i][4],BC[i],BCe[i]);
                   }
                   



// itt vegzi a BC-t es a tav modulust
for(i=0;i<m+1;i++){            
                   if(Adatk[i][3]!=0) fprintf(fbol,"%f %f %f\n",Adatk[i][0],Adatk[i][1]+BC[i]-5*log10(tav)+5,BCe[i] );
                   }




      //kimenet: JD, bol, hiba

fclose(fg);
fclose(fi);

fclose(fbol);


printf("\n\n");
getchar();
return 0;		

}

