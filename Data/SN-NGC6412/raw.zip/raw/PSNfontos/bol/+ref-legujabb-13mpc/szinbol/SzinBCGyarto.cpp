#include <math.h>
#include <stdio.h>

#define PI 3.14159265358979
	

//Lyman et al. 2014 (all)
//BC_B=-0.057-0.219�(B-I)-0.169�(B-I)^2
//BC_g= 0.055-0.219�(g-r)-0.629�(g-r)^2

// SNe II
//BC_B = 0.004 - 0.297 � (B - I) - 0.149 � (B - I)^2
//BC_g = 0.053 - 0.089 � (g - r) - 0.736 � (g - r)^2




// Johnson
float bolom(float szin){
	  float BC;
	  float a               = -0.141534;     
	  float b               = -0.398507;     
	  float c               = 1.3905;        
	  float d               = 0.748243;       
	  float e               = -0.143532;   
	  
	  //BC=0.004 - 0.297*szin-0.149*szin*szin;
	  BC=a - b * szin - c * szin*szin  + d * szin*szin*szin + e * szin*szin*szin*szin;
	  
	  return BC;
	  }
	  
// Johnson
float bolomh(float szin, float szine){
	  float BCe;
	  float a               = -0.141534;     
	  float b               = -0.398507;     
	  float c               = 1.3905;        
	  float d               = 0.748243;       
	  float e               = -0.143532;   
	  
	  //BCe=-0.297-0.149*2*szin;
	  BCe=b  - 2*c * szin  + 3*d * szin*szin + 4*e * szin*szin*szin;
	  BCe=BCe*szine;
	  
	  return BCe;
	  }



/*
// SDSS
float bolom(float szin){
	  float BC;
	  
	  BC=0.055-0.219*szin-0.629*szin*szin;
	  
	  return BC;
	  }
	  
// SDSS
float bolomh(float szin, float szine){
	  float BCe;
	  
	  BCe=-0.219-0.629*2*szin;
	  BCe=BCe*szine;
	  
	  return BCe;
	  }
*/







// utolagosan meghatarozza a szint (egyszeruen kivonja az egyikbol a masikat)

int main ()
{
 
 
int m=0;   // g szama

float Adatk[100][5];  //beolvasand� adatok a
float BC[100];
float BCe[100];
float hiba[100];

int i;   // ciklus v�ltoz�k
int j;
int k;

float e=0;   //szemet
float sz=0;  //seged
float s=0;   //seged1
float szz=0; //seged3




FILE *fg;
FILE *fi;

FILE *fbol;




//bemenet: sz�r�nk�nt 1-1
fg=fopen("B-gorbeA.txt","r");
fi=fopen("I-gorbeA.txt","r");
//fg=fopen("g-gorbe.txt","r");
//fi=fopen("r-gorbe.txt","r");


//szini kimenet
fbol=fopen("bol-gorbe.txt","wt");



	        // NED korrekci�k megad�sa: g/B  r/I 
            float nedgb=0.146;
            float nedri=0.061;
            
            float tav=23.5  * pow(10,6);  //Mpc --> pc
			//* 3.086*pow(10,22);   // Mpc --> m








// szinfugges ===============================================

for(i=0;i<100;i++) Adatk[i][0]=0;
for(i=0;i<100;i++) Adatk[i][1]=0;
for(i=0;i<100;i++) Adatk[i][2]=0;
for(i=0;i<100;i++) Adatk[i][3]=0;
for(i=0;i<100;i++) Adatk[i][4]=0;

for(i=0;i<100;i++) BC[i]=0;
for(i=0;i<100;i++) BCe[i]=0;
for(i=0;i<100;i++) hiba[i]=0;


rewind (fg);
rewind (fi);


//g-t olvasva, hossz meghatarozashoz. Ido, g fenyesseget, hibat berakja a tombbe
printf("\nBeolvasva:\n");
m=0;
while(!feof(fg)){
  fscanf(fg,"%f %f %f %f\n",&Adatk[m][0],&Adatk[m][1],&e,&Adatk[m][4]);
  hiba[m]=Adatk[m][4];
  m++; }

printf("szamolt hossz: %d, g/B\n",m);


//i-t olvasva, datummal ellenorizve, g melle rakja, hibat is
i=0;
while(!feof(fi)){
  fscanf(fi,"%f %f %f %f\n",&s,&sz,&e,&szz);
  for(j=0;j<m+1;j++){ if( int(s)==int(Adatk[j][0]) ){Adatk[j][2]=sz; Adatk[j][4]=sqrt(szz*szz+Adatk[j][4]*Adatk[j][4]); j=m+1;}  }
  i++; }
                   
printf("szamolt hossz: %d, r/I\n",i);

// kiszedi ha 0 van i-ben (g-ben nem lehet, mert az melle raktuk)
for(i=0;i<m+1;i++)   if(Adatk[i][2]==0){ for(j=i;j<m+1;j++){ for(k=0;k<5;k++) Adatk[j][k]=Adatk[j+1][k]; hiba[j]=hiba[j+1]; }
					 					m--; i--;}


// extinkciora korrigal
for(i=0;i<m+1;i++){
				  Adatk[i][1]=Adatk[i][1]-nedgb;
				  Adatk[i][2]=Adatk[i][2]-nedri;
				  }



//g-i tombbe rakja, BC szamitas, kiirja
printf("\nA szinek (extinkcio korrigalt):\n");
printf("JD, g/B, r/I, g-r/B-I, hiba, BC, BC hiba\n");
for(i=0;i<m+1;i++){
                   if( Adatk[i][1]+Adatk[i][2]!=0 ) Adatk[i][3]=Adatk[i][1]-Adatk[i][2];
                   
				   BC[i] =bolom(Adatk[i][3]);
				   BCe[i]=bolomh(Adatk[i][3],Adatk[i][4]);
				   BCe[i]=sqrt(hiba[i]*hiba[i]+BCe[i]*BCe[i] );
				   
				   printf("%f %f %f %f %f %f %f\n",Adatk[i][0],Adatk[i][1],Adatk[i][2],Adatk[i][3],Adatk[i][4],BC[i],BCe[i]);
                   }
                   



// itt vegzi a BC-t es a tav modulust
for(i=0;i<m+1;i++){            
                   if(Adatk[i][3]!=0) fprintf(fbol,"%f %f %f\n",Adatk[i][0],Adatk[i][1]+BC[i]-5*log10(tav)+5,BCe[i] );
                   }



      //kimenet: JD, bol, hiba

fclose(fg);
fclose(fi);

fclose(fbol);


printf("\n\n");
getchar();
return 0;		

}

