
#include <math.h>
#include <stdio.h>

#define PI 3.14159265358979



float h(float x, float y){
	  return sqrt(x*x+y*y);
	  }





/*
Kivalasztott idopont fluxusat kivonja a tobbiebol
Azaz ha van egy referencia meres, akkor annak a fenyesseg erteket levonja az objektumebol
fluxus helyesen
dat idopontban a ref
*/



int main ()
{
 
 
int n=2; 
int m=0;   //szamol

//ref tarolo
float Tg;
float Tr;
float Ti;
float Tz;
//ref hiba tarolo
float Tgh;
float Trh;
float Tih;
float Tzh;

float Adat[n+1][4];   //beolvasando adatok
float Adatk[7];  //adattarolas a beolvasashoz

int i;   // ciklus v�ltoz�k
int j;
int k;
float e=0;   //eredm�ny
float ee=0;
float eee=0;
double dat;    // d�tum


FILE *fg;
FILE *fr;
FILE *fi;
FILE *fz;
FILE *fgk;
FILE *frk;
FILE *fik;
FILE *fzk;



//kimenet: sz�r�nk�nt 1-1
fg=fopen("V-gorbeS.txt","r");
fr=fopen("R-gorbeS.txt","r");
fi=fopen("I-gorbeS.txt","r");
fz=fopen("B-gorbeS.txt","r");

//kimenet: sz�r�nk�nt 1-1
fgk=fopen("V-gorbeR.txt","wt");
frk=fopen("R-gorbeR.txt","wt");
fik=fopen("I-gorbeR.txt","wt");
fzk=fopen("B-gorbeR.txt","wt");











			// Melyik idopontra vegezze el?
			dat=57834.25;








Adatk[0]=0;
Adatk[1]=0;
Adatk[2]=0;
Adatk[3]=0;
Tg=1000;
Tr=1000;
Ti=1000;
Tz=1000;
Tgh=0;
Trh=0;
Tih=0;
Tzh=0;
//ha nincs adat akkor nagyon kicsi szam miatt nincs korrekcio


//Beolvassal, es ahol dat a datum azt megjegyzi
printf("\n\nBeolvasva:\n");
m=0;
while(!feof(fg)){
  fscanf(fg,"%f %f %f %f\n",&Adatk[0],&Adatk[1],&Adatk[2],&Adatk[3]);
  if(int(Adatk[0])==int(dat)){ Tg=Adatk[1];  Tgh=Adatk[2]; }
  m++; }

printf("szamolt hossz: %d, g\n",m);

m=0;
while(!feof(fr)){
  fscanf(fr,"%f %f %f %f\n",&Adatk[0],&Adatk[1],&Adatk[2],&Adatk[3]);
  if(int(Adatk[0])==int(dat)){ Tr=Adatk[1];  Trh=Adatk[2]; }
  m++; }
  
m=0;
while(!feof(fi)){
  fscanf(fi,"%f %f %f %f\n",&Adatk[0],&Adatk[1],&Adatk[2],&Adatk[3]);
  if(int(Adatk[0])==int(dat)){ Ti=Adatk[1];  Tih=Adatk[2]; }
  m++; }
  
m=0;
while(!feof(fz)){
  fscanf(fz,"%f %f %f %f\n",&Adatk[0],&Adatk[1],&Adatk[2],&Adatk[3]);
  if(int(Adatk[0])==int(dat)){ Tz=Adatk[1];  Tzh=Adatk[2]; }
  m++; }





//korrekcio elvegzese                   
                   
                   
rewind (fg);
rewind (fr);
rewind (fi);
rewind (fz);


//Sima-t beolvassa, korrigal, kiir, keplet lent
while(!feof(fg)){
                   fscanf(fg,"%f %f %f %f\n",&Adat[0][0],&Adat[0][1],&Adat[0][2],&Adat[0][3]);
                   if(Adat[0][1]<Tg)  e=2.5*log(  1 - pow(10,-0.4*(Tg-Adat[0][1]) )  );   else e=-100;
                   if(Adat[0][1]<Tg) ee=2.5*log(  1 - pow(10,-0.4*(Tg-Adat[0][1]+Adat[0][2]) )  );   else ee=-100;
                   if(Adat[0][1]<Tg)eee=2.5*log(  1 - pow(10,-0.4*(Tg+Tgh-Adat[0][1]) )  );   else eee=-100;
				   fprintf(fgk,"%f %f %f %f\n", Adat[0][0], Adat[0][1]-e, h(eee-e,ee-e), Adat[0][3]);
				   }  

while(!feof(fr)){                  
                   fscanf(fr,"%f %f %f %f\n",&Adat[0][0],&Adat[0][1],&Adat[0][2],&Adat[0][3]);
                   if(Adat[0][1]<Tr)  e=2.5*log(  1 - pow(10,-0.4*(Tr-Adat[0][1]) )  );   else e=-100;
                   if(Adat[0][1]<Tr) ee=2.5*log(  1 - pow(10,-0.4*(Tr-Adat[0][1]+Adat[0][2]) )  );   else ee=-100;
                   if(Adat[0][1]<Tr)eee=2.5*log(  1 - pow(10,-0.4*(Tr+Trh-Adat[0][1]) )  );   else eee=-100;
				   fprintf(frk,"%f %f %f %f\n", Adat[0][0], Adat[0][1]-e, h(eee-e,ee-e), Adat[0][3]);
				   }

while(!feof(fi)){
                   fscanf(fi,"%f %f %f %f\n",&Adat[0][0],&Adat[0][1],&Adat[0][2],&Adat[0][3]);
                   if(Adat[0][1]<Ti)  e=2.5*log(  1 - pow(10,-0.4*(Ti-Adat[0][1]) )  );   else e=-100;
                   if(Adat[0][1]<Ti) ee=2.5*log(  1 - pow(10,-0.4*(Ti-Adat[0][1]+Adat[0][2]) )  );   else ee=-100;
                   if(Adat[0][1]<Ti)eee=2.5*log(  1 - pow(10,-0.4*(Ti+Tih-Adat[0][1]) )  );   else eee=-100;
				   fprintf(fik,"%f %f %f %f\n", Adat[0][0], Adat[0][1]-e, h(eee-e,ee-e), Adat[0][3]);
				   }
                   
while(!feof(fz)){;
                   fscanf(fz,"%f %f %f %f\n",&Adat[0][0],&Adat[0][1],&Adat[0][2],&Adat[0][3]);
                   if(Adat[0][1]<Tz)  e=2.5*log(  1 - pow(10,-0.4*(Tz-Adat[0][1]) )  );   else e=-100;
                   if(Adat[0][1]<Tz) ee=2.5*log(  1 - pow(10,-0.4*(Tz-Adat[0][1]+Adat[0][2]) )  );   else ee=-100;
                   if(Adat[0][1]<Tz)eee=2.5*log(  1 - pow(10,-0.4*(Tz+Tzh-Adat[0][1]) )  );   else eee=-100;
				   fprintf(fzk,"%f %f %f %f\n", Adat[0][0], Adat[0][1]-e, h(eee-e,ee-e), Adat[0][3]);
				   }              
                   

	//mo fenyesebb m2-nel, flux1+flux2=fluxo
	//m1=-2.5log(   10**-0.4*mo +K  -  10**-0.4*m2 +K     ) + K
	//a ()-ben flux arany van
	
	//m1=mo-2.5log(  1 - 10**-0.4*(m2-mo)  )
	
	// flux1=fluxo* (1 - flux2/fluxo)
	// / -2.5log()+K megkapjuk a kozepso kepletet







      //kimenet: d�tum, korr f�nyess�g, f�nyess�g hiba, kivon�s hib�ja !!!


fclose(fg);
fclose(fr);
fclose(fi);
fclose(fz);

fclose(fgk);
fclose(frk);
fclose(fik);
fclose(fzk);


printf("\n\nLefutott\n");
getchar();
return 0;		

}

