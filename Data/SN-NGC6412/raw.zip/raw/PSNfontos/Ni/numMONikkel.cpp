#include <stdio.h>
#include <math.h>

#define PI 3.14159265l

// Ni-Co-Fe bomlasi lanc es ebbol szarmazo elnyelesi energia elnyelesenek hatekonysaga

int main(){

double N;   // Ni
double N1;  // Co
double N2;  // Fe

double dN;    // dNi
double dN1;   // dCo
double dN2;   // dFe

double Oszl;  // Oszlop s�r�s�g

double dt;
double t;
double c1;    // boml�si �ll
double c2;

double e1;    // magok boml�si E-je
double e2;

double k;   // �tl�tsz�s�g (0-1)

int i;     // ciklus v�ltoz�


FILE *f;

f=fopen("numNi.txt","wt");



// �llitand� param�terek:

// Nikkel t�meg [nap t�meg]
       N=0.0006;
       
// Oszlop s�r�s�g [g/cm^2]
       Oszl=99910600;

       
       
  t=300000;
  dt=0.001;
  // dt*t= ennyi napig fut

       
       
k=1;   // eneriga elnyel�s hat�konys�ga

N1=0;
N2=0;


N=N * 2.0*pow(10,33);    // Napt�meg --> gramm
//N=0.6 * 12.0*pow(10,56)/56.0;     // napt�megben az atom magok sz�ma



c1=log(2)/6.075;   // 6.1nap
c2=log(2)/77;   // 77nap

//e1=158000 * 1.6*pow(10,-19);    // eV
//e2=120000 * 1.6*pow(10,-19);    // eV

e1=3.89*pow(10,3);   // joule/s/gramm
e2=6.8*pow(10,2);    // joule/s/gramm


// boml�si t�rv�nyek diff egyenleteinek num megold�sa (Euler m�dszer)
for(i=0;i<t;i++){

dN=-N*c1;
dN1=N*c1-N1*c2;
dN2=N1*c2;

N=N+dN*dt;
N1=N1+dN1*dt;
N2=N2+dN2*dt;


// 0.033: Co kappa, 11.575=1000000sec: ekkor Oszl az oszlop s�r�s�g 
k=1-pow(2.718281,-0.033*Oszl*11.575/((i*dt)*(i*dt)) );  // cikkre alapozva

// (k*0.96795+0.03205) jelent�se: gamm�b�l �s leptonb�l sz�rmaz� energi�t ar�nya, ahol csak a gamma elnyel�s hat�konys�ga cs�kken (3606, 119.4 KeV)



 if(i%100==0)
 fprintf(f,"%f %f %e %e %e %e %e %e\n",i*dt,-2.5*log10( k*e1*N + (k*0.96795+0.03205)*e2*N1 )+71.21,k*e1*N + (k*0.96795+0.03205)*e2*N1,N,N1,N2,dN,dN1);
           }

fclose(f);

//id� [nap], absz f�nyess�g [mag], �ssz energia [Joule], Anyagmag, Le�nymag, (2.) Unokamag, 1. boml�s sebess�g, 2. boml�s sebess�g,


}
