#include <math.h>
#include <stdio.h>

#define PI 3.14159265358979



/*
void Ell(FILE *b, FILE *f, float A[], float B[], int IDa, int IDb, char asz, char bsz){
	 
	 if(IDa>IDb && IDa<IDb+5){
	  				 fprintf(f,"%f %f\n",IDa,asz);
	  				 printf("ok\n");
					 }
	  
	  else           {
	  				 fprintf(f,"%d %c %f %f %f\n",IDb,bsz,B[0],B[1],B[2]);
	  				 fscanf(b,"%d %c %f %f %f\n",&IDb,&bsz,&B[0],&B[1],&B[2]);
	  				 Ell(b,f,A,B,IDa,IDb,asz,bsz);
	 			   	}
	 
	 
	 }*/




main ()
{
 	 
int n;
int m;

int i;
int j;

float A[3000];
float B[3000];
float C[3000];
for(i=0;i<3000;i++) C[i]=0;

float temp1;
float temp2;
float temp3;




FILE *a;
FILE *b;
FILE *f;

a=fopen("PSNspectraCut2.txt","r");
//b=fopen("vPSN-NGC6412-BestFit.sp","r");
b=fopen("fasz","r");
f=fopen("Eredmeny.txt","wt");



// A recenter on, B recenter off

i=0;
while(!feof(a)){
				  
				  
	  fscanf(a,"%f %f\n",&A[i],&B[i]); A[i]=A[i]/(1+0.0044);
	  i++;

	 	  
	  
	  
	  }
	  
	  
	 
n=i; 


i=0;
while(!feof(b)){
				  
				  
	  fscanf(b,"%f %f %f\n",&temp1,&temp2,&temp3); 
	  //printf("%f  %f   %f\n",temp1,temp2,temp3); getchar();
	  
	  for(j=0;j<n;j++) if(temp1>A[j] && temp1<A[j]+5){  C[j]=temp2; /*break;*/ }
	  printf("%d\n",i);
	  i++;

	 	  
	  
	  
	  }





for(j=0;j<n;j++) fprintf(f,"%f %f %f\n",A[j],B[j]*0.432e16,C[j]);










fclose(a);
fclose(b);
fclose(f);

printf("\n\n");
		

	
	
	
	
	
	
	
}
