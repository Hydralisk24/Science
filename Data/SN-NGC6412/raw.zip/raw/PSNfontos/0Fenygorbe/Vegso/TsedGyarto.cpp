#include <math.h>
#include <stdio.h>

#define PI 3.14159265358979

/*	
	// sdss
	float lg=477.0e-9;
	float lr=623.1e-9;
	float li=762.5e-9;
	float lz=913.4e-9;
	
	float lgn=0;
	float lrn=0;
	float lin=0;
	float lzn=0;
	
	
// Fekete Test Sugarzas, F_f
float FTS(float l, float T){
	  float B;
	  
	  B=-2.5*log10( 2*PI*3e8*3e8*6.626e-34* pow(l,-5) /(exp(3e8*6.626e-34/l/T/1.38e-23)-1) * l*l/3e8);
	  
	  return B;
	  }
*/
	  
	  
	  
	// Johnson
	float lg=547.7e-9;
	float lr=634.9e-9;
	float li=879.7e-9;
	float lz=435.3e-9;
	
	float lgn=21.10;
	float lrn=21.65;
	float lin=22.37;
	float lzn=20.50;
	
	
	
// Fekete Test Sugarzas, F_l
float FTS(float l, float T){
	  float B;
	  
	  B=-2.5*log10( 2*PI*3e8*3e8*6.626e-34* pow(l,-5) /(exp(3e8*6.626e-34/l/T/1.38e-23)-1) );
	  
	  return B;
	  }
	  
	  
	  
			// V R I B
            float nedg=0.111;
            float nedr=0.087;
            float nedi=0.061;
            float nedz=0.146;




float h(float x){
	  return x*x;	  
	  }











int main ()
{
 
 
int m=0;   // g szama

float Adatk[100][9];  //beolvasand� adatok a
float Tszin[100][3];  //szin tomb
float T[100][5];      //T tomb

int i;   // ciklus v�ltoz�k
int j;
int k;

float e=0;   //szemet
float sz=0;  //seged
float s=0;   //seged1
float szz=0; //seged3

float dt;
float Ttemp;


FILE *fg;
FILE *fr;
FILE *fi;
FILE *fz;


FILE *fT;




//bemenet: sz�r�nk�nt 1-1
//fg=fopen("g-gorbe.txt","r");
//fr=fopen("r-gorbe.txt","r");
//fi=fopen("i-gorbe.txt","r");
//fz=fopen("z-gorbe.txt","r");
fg=fopen("V-gorbe.txt","r");
fr=fopen("R-gorbe.txt","r");
fi=fopen("I-gorbe.txt","r");
fz=fopen("B-gorbe.txt","r");




if(fg==NULL && fr==NULL && fi==NULL && fz==NULL){printf("Nincs eleg fajl!\n"); getchar(); return 0;}

if(fg==NULL) printf("Nincs g/V file!\n");
if(fr==NULL) printf("Nincs r/R file!\n");
if(fi==NULL) printf("Nincs i/I file!\n");
if(fz==NULL) printf("Nincs z/B file!\n");



//T kimenet
fT=fopen("T-gorbe.txt","w");





for(i=0;i<100;i++) Adatk[i][0]=0;
for(i=0;i<100;i++) Adatk[i][1]=0;
for(i=0;i<100;i++) Adatk[i][2]=0;
for(i=0;i<100;i++) Adatk[i][3]=0;
for(i=0;i<100;i++) Adatk[i][4]=0;
for(i=0;i<100;i++) Adatk[i][5]=0;
for(i=0;i<100;i++) Adatk[i][6]=0;
for(i=0;i<100;i++) Adatk[i][7]=0;
for(i=0;i<100;i++) Adatk[i][8]=0;










//g-t olvasva, hossz meghatarozashoz. Ido, g fenyesseget, hibat berakja a tombbe
printf("\nBeolvasva:\n");
m=0;
if(fg!=NULL) while(!feof(fg)){
  fscanf(fg,"%f %f %f %f\n",&Adatk[m][0],&Adatk[m][1],&e,&Adatk[m][2]);
  m++; }

printf("szamolt hossz: %d, g/V\n",m);





//r-t olvasva, datummal ellenorizve, g melle rakja, hibat is
i=0;
if(fr!=NULL) while(!feof(fr)){
  fscanf(fr,"%f %f %f %f\n",&s,&sz,&e,&szz);
  k=0;
  for(j=0;j<m;j++){ if( int(s)==int(Adatk[j][0]) ) {Adatk[j][3]=sz; Adatk[j][4]=szz; j=m+1; k++; }  }
  if(k==0){ Adatk[m][0]=s; Adatk[m][3]=sz; Adatk[m][4]=szz; m++; }
  i++;
  }


//i-t olvasva, datummal ellenorizve, g melle rakja, hibat is
i=0;
if(fi!=NULL) while(!feof(fi)){
  fscanf(fi,"%f %f %f %f\n",&s,&sz,&e,&szz);
  k=0;
  for(j=0;j<m;j++){ if( int(s)==int(Adatk[j][0]) ) {Adatk[j][5]=sz; Adatk[j][6]=szz; j=m+1; k++; }  }
  if(k==0){ Adatk[m][0]=s; Adatk[m][5]=sz; Adatk[m][6]=szz; m++; }
  i++;
  }


//z-t olvasva, datummal ellenorizve, g melle rakja, hibat is
i=0;
if(fz!=NULL) while(!feof(fz)){
  fscanf(fz,"%f %f %f %f\n",&s,&sz,&e,&szz);
  k=0;
  for(j=0;j<m;j++){ if( int(s)==int(Adatk[j][0]) ) {Adatk[j][7]=sz; Adatk[j][8]=szz; j=m+1; k++; }  }
  if(k==0){ Adatk[m][0]=s; Adatk[m][7]=sz; Adatk[m][8]=szz; m++; }
  i++;
  }


      
printf("szamolt osszhossz: %d\n",m);






/*
//kiirja
printf("\nA tomb:\n");
printf("JD, g, g hiba, r, r hiba, i, i hiba, z, z hiba\n");
for(i=0;i<m+1;i++){
                   printf("%f %f %f %f %f %f %f %f %f\n",Adatk[i][0],Adatk[i][1],Adatk[i][2],Adatk[i][3],Adatk[i][4],Adatk[i][5],Adatk[i][6],Adatk[i][7],Adatk[i][8]);
                   }
*/
                   


if(fg!=NULL) fclose(fg);
if(fr!=NULL) fclose(fr);
if(fi!=NULL) fclose(fi);
if(fz!=NULL) fclose(fz);









// HOMERSEKLET SZAMOLASA +++++++++++++++++++++++++++++++++++++++++++++++++++++++


// extinkcio korrekcio
for(i=0;i<m;i++){
				 if( Adatk[i][1]!=0 ) Adatk[i][1]=Adatk[i][1]-nedg;
				 if( Adatk[i][3]!=0 ) Adatk[i][3]=Adatk[i][3]-nedr;
				 if( Adatk[i][5]!=0 ) Adatk[i][5]=Adatk[i][5]-nedi;
				 if( Adatk[i][7]!=0 ) Adatk[i][7]=Adatk[i][7]-nedz;
				 }



// azt feltelezve, hogy az elso pont is 10k, ami nyilvan nem feltetlenul igaz
printf("\n10000K-n a kulombseg: %f (-12 +10 ami lehet!)\n\n",Adatk[0][1]-FTS(lg,10000)+lgn);
if(Adatk[0][1]==0) printf("Manualisan kell ezt megadni!!!!!!!\n\n");
dt=Adatk[0][1]-FTS(lg,10000)+lgn;
								 //dt=75;


for(i=0;i<m;i++){
				 
				 T[i][0]=Adatk[i][0];
				 
				 // ha nincs adat, azzal nem szamol.
				 k=0; szz=0;
				 if( Adatk[i][1]==0 ) k++;  if( Adatk[i][1]!=0 ) szz=szz+1/h(Adatk[i][2]); 
				 if( Adatk[i][3]==0 ) k++;  if( Adatk[i][3]!=0 ) szz=szz+1/h(Adatk[i][4]); 
				 if( Adatk[i][5]==0 ) k++;  if( Adatk[i][5]!=0 ) szz=szz+1/h(Adatk[i][6]); 
				 if( Adatk[i][7]==0 ) k++;  if( Adatk[i][7]!=0 ) szz=szz+1/h(Adatk[i][8]); 
				 if(szz==0) szz=0.0001;
				 //printf("k:%d\n",k);
							 
				
				
							 
				 T[i][2]=10000;
				 T[i][4]=50;
				 Ttemp=1500;
				 j=0;
				 
				 while(Ttemp<20100){
				  sz=10000;					
				  e=dt-12;					
				  while(e<dt+10){ 
 			 	 			 
							 s=0;
							 // hiba negyzettel sulyozott szoras, legkisebb negyzetek			 
 			 	 			 if(Adatk[i][1]!=0) s=s+h( Adatk[i][1]-FTS(lg,Ttemp)-e+lgn )/h(Adatk[i][2]);
 			 	 			 if(Adatk[i][3]!=0) s=s+h( Adatk[i][3]-FTS(lr,Ttemp)-e+lrn )/h(Adatk[i][4]);
 			 	 			 if(Adatk[i][5]!=0) s=s+h( Adatk[i][5]-FTS(li,Ttemp)-e+lin )/h(Adatk[i][6]);
 			 	 			 if(Adatk[i][7]!=0) s=s+h( Adatk[i][7]-FTS(lz,Ttemp)-e+lzn )/h(Adatk[i][8]);
 			 	 			 s=sqrt( s/szz );
 			 	 			 
 			 	 			 
				 			 if( s<T[i][2] ){ T[i][1]=Ttemp; T[i][2]=s; T[i][3]=e; }
				 			 if( s<sz ){ sz=s; } // adott T-n a legjobb erteket tarolja
				 			 
				 			 if(s<1)  e=e+0.1; 
				 			 if(s>=1) e=e+0.5;
							 }
				 
				 // 10% szoras elteres megengedheto, ha 11 nagyobb aktualis szoras van (mint a legjobb *1.1), akkor vegig porgeti
				 // Hiba: +10% szorashoz tartozo homerseklet - a legjobb homerseklet
				 if(sz>1.1*T[i][2])  j++;
				 if(sz<=1.1*T[i][2]){ j=0; T[i][4]=Ttemp-T[i][1]; }		 
				 if(j<11)  Ttemp=Ttemp+50; 
				 if(j>=11) Ttemp=Ttemp+300; 
				 //if(i==8) printf("%f %f         %f\n",sz,Ttemp,T[i][0]);
				}			 
			
			// minimum 50 a hiba	 
			if(T[i][4]<50) T[i][4]=50;	 
	  
	        }



// kiiras
printf("\nJD           T    Terr    C(R)   szoras!!\n");
for(i=0;i<m;i++){    
				   if(T[i][3]<dt-11.7 || T[i][3]>dt+9.7) printf("Kifutott az intervallumbol!   ");	         
                   printf("%f %d %d %f %f\n",T[i][0],int(T[i][1]+0.5),int(T[i][4]+0.5),T[i][3],T[i][2] );
                   }


// fajlba iras, ugyan az
for(i=0;i<m;i++){            
                   //fprintf(fT,"%f %d %f %f\n",T[i][0],int(T[i][1]+0.5),T[i][2],T[i][3] );
                   fprintf(fT,"%f %d %d %f %f\n",T[i][0],int(T[i][1]+0.5),int(T[i][4]+0.5),T[i][3],T[i][2] );
                   }





fclose(fT);

printf("\n\n");
getchar();
return 0;		

}

