#include <math.h>
#include <stdio.h>

#define PI 3.14159265358979

//tiltott adatok: (0 a mind, 0 az elso)
//i==0 || i==4
#define tiltott i==1
#define tilt 1





//kivon� f�ggv�ny (szin fugges mentes)(tiltott referencia csillagokat manu�lisan �llisd be) ELLEN�RIZD!
//M�k�d�s: adatokat megkapja, �s a megfelel� sz�r�t, majd pedig a k�l�nbs�gek �tlag�t veszi, �s ezt adja vissza. IF-es r�szben a NEM KIV�NT referencia csillagod adjuk meg.
float kivonas(float a[][4],float b[],int n){
	float e=0;
	int i;
	for(i=0;i<n;i++){
	  
	  //tiltott adatok:	  			 
	  if(        tiltott         ){} else{				 
	  e=e+( a[i][1]-b[i] );
      //printf("%f\n",a[i][1]-b[i]);
	  }}
	  
    e=e/(n-tilt);
	
	return e;
	}

//kivon�s szor�s�t hat�rozza meg	
float hiba(float a[][4],float b[],int n){
	float e=0;
	float sz=0;
	int i;
	for(i=0;i<n;i++){
	  	  			 
	  if(          tiltott            ){} else{				 
	  e=e+( a[i][1]-b[i] );
         
	  }}
    e=e/(n-tilt);
    
    printf("\n");
    for(i=0;i<n;i++){
	  		    			 
	  if(         tiltott          ){} else{				 
	  sz=sz+(e-a[i][1]+b[i])*(e-a[i][1]+b[i]);
	  printf("%f  ",a[i][1]-b[i]);
	  printf("%f\n",e-a[i][1]+b[i]);
   	  }}
	  
	  sz=sqrt(sz/(n-tilt));
	
	return sz;
	}
	







//kivon� f�ggv�ny (tiltott referencia csillagokat manu�lisan �llisd be) ELLEN�RIZD!
//M�k�d�s: adatokat megkapja, �s a megfelel� sz�r�t, majd pedig a k�l�nbs�gek �s szinfugges �tlag�t veszi, �s ezt adja vissza. IF-es r�szben a NEM KIV�NT referencia csillagod adjuk meg.
//mert adat, ref adat (amihez hasonlitunk), szin ref c-d, szin ref, mennyi az osszes, szintag
float kivonas2(float a[][4],float b[],float c[],float d[],int n,float Cx){
	float e=0;
	int i;
	for(i=0;i<n;i++){
	  
	  //tiltott adatok:	  			 
	  if(        tiltott         ){} else{				 
	  e=e+( a[i][1]-b[i] -Cx*(c[i]-d[i]) );
      //printf("%f\n",a[i][1]-b[i] +Cx*(c[i]-d[i]) );
	  }}
	  
    e=e/(n-tilt);
	
	return e;
	}

//kivon�s szor�s�t hat�rozza meg, adatok ugyan azok	
float hiba2(float a[][4],float b[],float c[],float d[],int n,float Cx){
	float e=0;
	float sz=0;
	int i;
	for(i=0;i<n;i++){
	  	  			 
	  if(          tiltott            ){} else{				 
	  e=e+( a[i][1]-b[i] -Cx*(c[i]-d[i]) );
         
	  }}
    e=e/(n-tilt);
    
    printf("\n");
    for(i=0;i<n;i++){
	  		    			 
	  if(         tiltott          ){} else{				 
	  sz=sz+(e-a[i][1]+b[i] +Cx*(c[i]-d[i]) )*(e-a[i][1]+b[i] +Cx*(c[i]-d[i]) );
	  printf("%f  ",a[i][1]-b[i] -Cx*(c[i]-d[i]) );
	  printf("%f\n",e-a[i][1]+b[i] +Cx*(c[i]-d[i]) );
   	  }}
	  
	  sz=sqrt(sz/(n-tilt));
	
	return sz;
	}
	
	
	

	



		// txdumpba: id,ifilter,otime,mag,merr, minden mehet egy f�jlba! ez lesz a bemenet
		// referencia csillagok UT�N legyen mindig a m�rend� objektum adatai

	//Eredmeny fajl a standard regiojahoz tartozo legyen
	//ELLORIZD!!!!!!!!!!!!!!!!!


int main ()
{
 
 
int n;   // referencia csillagok sz�ma
int m=0;   // k�pek sz�ma


       //referencia csillagok sz�ma (n), a szupernova szamisd bele, vagy ne legyen benne!
       n=5; 
 
 
 
//referencia csillagoknak a t�mbjei
float Tg[n];
float Tr[n];
float Ti[n];
float Tz[n];

float Adat[n+1][4];   //beolvasand� adatok
char szuro [100];   //sz�r�

int i;   // ciklus v�ltoz�k
int j;
int k;
float e=0;   //eredm�ny
float sz=0;  //szor�s
double dat;    //kezd� d�tum

float Cg;
float Cr;
float Ci;
float Cz;




FILE *f;
FILE *fg;
FILE *fr;
FILE *fi;
FILE *fz;

	 //bemenet:
     f=fopen("Eredmeny.txt","r");

//kimenet: sz�r�nk�nt 1-1
fg=fopen("g-korr.txt","wt");
fr=fopen("r-korr.txt","wt");
fi=fopen("i-korr.txt","wt");
fz=fopen("z-korr.txt","wt");

   // Referencia csillagok f�nyess�gei: �RD BE MANU�LISAN!! (g r i z)


//NGC6412 standard regio
//    1                      2                   3                   4                   5
   Tg[0]=15.32;           Tg[1]=14.98;        Tg[2]=15.47;        Tg[3]=15.12;        Tg[4]=15.31;
   Tr[0]=14.68;           Tr[1]=14.44;        Tr[2]=14.99;        Tr[3]=14.70;        Tr[4]=14.88;
   Ti[0]=14.44;           Ti[1]=14.85;        Ti[2]=14.84;        Ti[3]=14.55;        Ti[4]=14.72;
   Tz[0]=14.31;           Tz[1]=14.23;        Tz[2]=14.79;        Tz[3]=14.49;        Tz[4]=14.68;


//RC 2015
//szinfuggo lemez konstansok megadasa (ezt egy masik program szamolja)
   Cg=-0.125;
   Cr=-0.009;
   Ci=-0.095;
   Cz=0;








//megm�ri a f�jl hossz�t (menezheti mit olvas be)
printf("Beolvasva:\n");
while(!feof(f)){
  for(k=0;k<n;k++) fscanf(f,  "%f  %s  %f  %f  %f\n",&Adat[k][3],szuro,&Adat[k][0],&Adat[k][1],&Adat[k][2]);
  for(k=0;k<n;k++) printf(  "%d  %s  %f  %f  %f\n",int(Adat[k][3]),szuro,Adat[k][0],Adat[k][1],Adat[k][2]);      printf("\n");
  m++; }

printf("szamolt kepek: %d",m);
getchar();





dat=2400000;  // kezd� d�tum, hogy sz�p legyen a grafikon, MJD

rewind (f);

/*m�k�d�s: bels� ciklus beolvassa az adatokat, annyi sort ah�ny referencia csillag van +1,
a k�ls� ciklus pedig annyiszor csin�lja ezt amennyi m�rt �jszaka van *4.
sz�r�t is beolvassa, �s ennek megfelel�en k�l�nb�z�en j�r el.
j� sz�r�s f�nyess�g adatokat elk�ldi a f�ggv�nynek, referencia csillagok f�nyess�g�t kivonja az adatokb�l,
majd az �tlag�t kivonja az objektum f�yness�g�b�l, majd f�ljba �rja, sz�r�nk�nt m�sba*/




for(i=0;i<m;i++){

  for(k=0;k<n;k++){
  fscanf(f,  "%f  %s  %f  %f  %f\n",&Adat[k][3],szuro,&Adat[k][0],&Adat[k][1],&Adat[k][2]);
  }
  
  Adat[n][0]=Adat[0][0]; Adat[n][1]=0.0; Adat[n][2]=0.0;



  if(*szuro=='g'){ float e=kivonas2(Adat,Tg,Tg,Ti,n,Cg);  float sz=hiba2(Adat,Tg,Tg,Ti,n,Cg);
  printf("%f %f %s\n",e,sz,szuro); 
  fprintf(fg,"%f %f %f %f\n",Adat[n][0]-dat,0.0+e,0.0,sz); }
  
  if(*szuro=='r'){ float e=kivonas2(Adat,Tr,Tg,Ti,n,Cr);  float sz=hiba2(Adat,Tr,Tg,Ti,n,Cr);
  printf("%f %f %s\n",e,sz,szuro);   
  fprintf(fr,"%f %f %f %f\n",Adat[n][0]-dat,0.0+e,0.0,sz); }
  
  if(*szuro=='i'){ float e=kivonas2(Adat,Ti,Tg,Ti,n,Ci);   float sz=hiba2(Adat,Ti,Tg,Ti,n,Ci);
  printf("%f %f %s\n",e,sz,szuro); 
  fprintf(fi,"%f %f %f %f\n",Adat[n][0]-dat,0.0+e,0.0,sz); }
  
  if(*szuro=='z'){ float e=kivonas2(Adat,Tz,Tg,Ti,n,Cz);   float sz=hiba2(Adat,Tz,Tg,Ti,n,Cz);
  printf("%f %f %s\n",e,sz,szuro); 
  fprintf(fz,"%f %f %f %f\n",Adat[n][0]-dat,0.0+e,0.0,sz); }
  
  

}

printf("\nelteresek kulon-kulon, elteres az atlagtol\n");
printf("elteres atlag, szoras, szuro\n");

//amit ki�r: k�l�nbs�g, szor�sa, eredm�ny, sz�r� (ellen�rz�)

      //kimenet: d�tum, f�nyess�g, f�nyess�g hiba, kivon�s hib�ja 



fclose(f);

fclose(fg);
fclose(fr);
fclose(fi);
fclose(fz);

printf("\n\n");
getchar();
return 0;
		

}
