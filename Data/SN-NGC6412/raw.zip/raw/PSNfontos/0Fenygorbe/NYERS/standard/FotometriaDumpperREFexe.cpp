#include <math.h>
#include <stdio.h>

#define PI 3.14159265358979


//tiltott adatok: (0 a mind, 0 az elso)
//i==0 || i==4
//Itt nem hasznalt: mindegyik meghatarozott ref csillag ki lesz irva, fuggetlenek egymastol
#define tiltott 0
#define tilt 0




//Itt nem hasznalt
//kivon� f�ggv�ny (szin fugges mentes)(tiltott referencia csillagokat manu�lisan �llisd be) ELLEN�RIZD!
//M�k�d�s: adatokat megkapja, �s a megfelel� sz�r�t, majd pedig a k�l�nbs�gek �tlag�t veszi, �s ezt adja vissza. IF-es r�szben a NEM KIV�NT referencia csillagod adjuk meg.
float kivonas(float a[][4],float b[],int n){
	float e=0;
	int i;
	for(i=0;i<n;i++){
	  
	  //tiltott adatok:	  			 
	  if(        tiltott         ){} else{				 
	  e=e+( a[i][1]-b[i] );
      //printf("%f\n",a[i][1]-b[i]);
	  }}
	  
    e=e/(n-tilt);
	
	return e;
	}

//Itt nem hasznalt
//kivon�s szor�s�t hat�rozza meg	
float hiba(float a[][4],float b[],int n){
	float e=0;
	float sz=0;
	int i;
	for(i=0;i<n;i++){
	  	  			 
	  if(          tiltott            ){} else{				 
	  e=e+( a[i][1]-b[i] );
         
	  }}
    e=e/(n-tilt);
    
    printf("\n");
    for(i=0;i<n;i++){
	  		    			 
	  if(         tiltott          ){} else{				 
	  sz=sz+(e-a[i][1]+b[i])*(e-a[i][1]+b[i]);
	  printf("%f  ",a[i][1]-b[i]);
	  printf("%f\n",e-a[i][1]+b[i]);
   	  }}
	  
	  sz=sqrt(sz/(n-tilt));
	
	return sz;
	}
	






//Itt nem hasznalt
//kivon� f�ggv�ny (tiltott referencia csillagokat manu�lisan �llisd be) ELLEN�RIZD!
//M�k�d�s: adatokat megkapja, �s a megfelel� sz�r�t, majd pedig a k�l�nbs�gek �s szinfugges �tlag�t veszi, �s ezt adja vissza. IF-es r�szben a NEM KIV�NT referencia csillagod adjuk meg.
//mert adat, ref adat (amihez hasonlitunk), szin ref c-d, szin ref, mennyi az osszes, szintag
float kivonas2(float a[][4],float b[],float c[],float d[],int n,float Cx){
	float e=0;
	int i;
	for(i=0;i<n;i++){
	  
	  //tiltott adatok:	  			 
	  if(        tiltott         ){} else{				 
	  e=e+( a[i][1]-b[i] -Cx*(c[i]-d[i]) );
      //printf("%f\n",a[i][1]-b[i] +Cx*(c[i]-d[i]) );
	  }}
	  
    e=e/(n-tilt);
	
	return e;
	}

//Itt nem hasznalt
//kivon�s szor�s�t hat�rozza meg, adatok ugyan azok	
float hiba2(float a[][4],float b[],float c[],float d[],int n,float Cx){
	float e=0;
	float sz=0;
	int i;
	for(i=0;i<n;i++){
	  	  			 
	  if(          tiltott            ){} else{				 
	  e=e+( a[i][1]-b[i] -Cx*(c[i]-d[i]) );
         
	  }}
    e=e/(n-tilt);
    
    printf("\n");
    for(i=0;i<n;i++){
	  		    			 
	  if(         tiltott          ){} else{				 
	  sz=sz+(e-a[i][1]+b[i] +Cx*(c[i]-d[i]) )*(e-a[i][1]+b[i] +Cx*(c[i]-d[i]) );
	  printf("%f  ",a[i][1]-b[i] -Cx*(c[i]-d[i]) );
	  printf("%f\n",e-a[i][1]+b[i] +Cx*(c[i]-d[i]) );
   	  }}
	  
	  sz=sqrt(sz/(n-tilt));
	
	return sz;
	}
	
	

//Ez a hasznalt	
//varians, az alappal megegyezo, de beolvas egy masik sulyuzott mennyiseget is (b[]=0 most valszeg)
float kivonasv(float a[][4],float b[],int n, float m){
	float e=0;
	int i;
	for(i=0;i<n;i++){
	  
	  //tiltott adatok:	  			 
	  if(        0         ){} else{				 
	  e=e+( a[i][1]-b[i] );
      
	  }}
	  
    e=e/m;
	
	return e;
	}

//varians, elozo
float hibav(float a[][4],float b[],int n, float m){
	float e=0;
	float sz=0;
	int i;
	for(i=0;i<n;i++){
	  	  			 
	  if(          0            ){} else{				 
	  e=e+( a[i][1]-b[i] );
         
	  }}
	  
    e=e/m;
    
    
    for(i=0;i<n;i++){
	  		    			 
	  if(         0          ){} else{				 
	  sz=sz+(a[i][1]/a[i][0])*(e-a[i][0]+b[i])*(e-a[i][0]+b[i]);
      
   	  }}
	  
	  sz=sqrt(sz/m);
	
	return sz;
	}
	
	
	
	
	
	
	
	
	
	
	/*3 reszes: 1. Kulso korrekciot beolvassa, azzal korigalja az adatokat, 
    ebben nincs szin (mert szin mentes a beolvasott korrekcio
    2. Ebben megkeresi az azonod ID-ju csillagok, es ezen ertekeket sulyozttan atlagolja
    3. korrigal a szinre
	*/
	
	
	//Eredmeny fajl a Supernova regiojahoz tartozo legyen, de az x-korrba a standard�!
	//ELLORIZD!!!!!!!!!!!!!!!!!



		// txdumpba: id,ifilter,otime,mag,merr, minden mehet egy f�jlba! ez lesz a bemenet
		// referencia csillagok UT�N legyen mindig a m�rend� objektum adatai

int main ()
{
 
 
int n;   // referencia csillagok sz�ma
int m=0;   // k�pek sz�ma
int l;   // standardok szama, (mennyi ejszaka)






              //referencia csillagok sz�ma, legyen benne az SN is (benne lehet)(n) �s standardok sz�ma (l)
              n=6; 
              l=4;
 
 
 
 
 
 
 
 
//referencia csillagoknak a t�mbjei
float Tg[n];
float Tr[n];
float Ti[n];
float Tz[n];

float Adat[n+1][4];   //beolvasand� adatok
float Adatk[255][5];  //2. reszhez, beolvasando adatok 2
char szuro [100];   //sz�r�

float Asg[l][3];   //beolvasand� standard adatok g
float Asr[l][3];   //beolvasand� standard adatok r
float Asi[l][3];   //beolvasand� standard adatok i
float Asz[l][3];   //beolvasand� standard adatok z

int i;   // ciklus v�ltoz�k
int j;
int k;
float e=0;   //eredm�ny
float sz=0;  //szor�s
double dat;    //kezd� d�tum

float Cg;   //szini konstansok
float Cr;
float Ci;
float Cz;


float eg=0;   //eredmeny seged
float er=0;
float ei=0;
float ez=0;

float szg=0;  //szoras seged
float szr=0;
float szi=0;
float szz=0;





FILE *f;
FILE *fgbe;
FILE *frbe;
FILE *fibe;
FILE *fzbe;
FILE *fg;
FILE *fr;
FILE *fi;
FILE *fz;
FILE *fgk;
FILE *frk;
FILE *fik;
FILE *fzk;


	 //bemenet: photbol (be:1)
     f=fopen("Eredmeny.txt","r");

//bemenet: sz�r�nk�nt 1-1, kulso szinmentes korrekcio (be:1)
fgbe=fopen("g-korr.txt","r");
frbe=fopen("r-korr.txt","r");
fibe=fopen("i-korr.txt","r");
fzbe=fopen("z-korr.txt","r");

//kimenet: sz�r�nk�nt 1-1, szokasos korrigalt fenyessegek (ki:1 be:2)
//felso: ir is bele, also: csak beolvass, ez akkor jo modositunk rajta manualisan, CSAK 1 LEGYEN, MASIK KIKOMMENTELVE!
//fg=fopen("g-gorbe.txt","wt+r");
//fr=fopen("r-gorbe.txt","wt+r");
//fi=fopen("i-gorbe.txt","wt+r");
//fz=fopen("z-gorbe.txt","wt+r");
fg=fopen("g-gorbe.txt","r");
fr=fopen("r-gorbe.txt","r");
fi=fopen("i-gorbe.txt","r");
fz=fopen("z-gorbe.txt","r");

//kimenet: sz�r�nk�nt 1-1 referencia csillagok (ki:2 be:2+3)
fgk=fopen("g-ref.txt","wt+r");
frk=fopen("r-ref.txt","wt+r");
fik=fopen("i-ref.txt","wt+r");
fzk=fopen("z-ref.txt","wt+r");



   // Referencia csillagok f�nyess�gei: �RD BE MANU�LISAN!! (g r i z)

/*
//Ebben a programban nincs szukseg (es nincsenek is) referencia csillagok
//    1                      2                   3                   4                   5
   Tg[0]=15.17;           Tg[1]=15.71;        Tg[2]=14.71;        Tg[3]=14.49;        Tg[4]=15.29;
   Tr[0]=14.57;           Tr[1]=15.32;        Tr[2]=14.24;        Tr[3]=14.10;        Tr[4]=14.99;
   Ti[0]=15.13;           Ti[1]=15.18;        Ti[2]=14.56;        Ti[3]=14.47;        Ti[4]=14.86;
   Tz[0]=14.39;           Tz[1]=15.16;        Tz[2]=14.03;        Tz[3]=13.98;        Tz[4]=14.83;
*/
for(i=0;i<n;i++) Tg[i]=0;
for(i=0;i<n;i++) Tr[i]=0;
for(i=0;i<n;i++) Ti[i]=0;
for(i=0;i<n;i++) Tz[i]=0;








//RC 2015
//szinfuggo lemez konstansok megadasa (ezt egy masik program szamolja)
   Cg=-0.125;
   Cr=-0.009;
   Ci=-0.095;
   Cz=0;








//1. resz: a kulso korrekcio beolvasa es elvegzese ================================
//standard napok kivetele: x-gorbeben manualisan! Majd ezt a szekciot kivenni
//ES x-gorbe IRASAT KIVENNI!!!!

//korrekciok beolvasasa, x-korr
for(i=0;i<l;i++){
                 fscanf(fgbe,"%f %f %f %f\n",&Asg[i][0],&Asg[i][1],&sz,&Asg[i][2]);
                 fscanf(frbe,"%f %f %f %f\n",&Asr[i][0],&Asr[i][1],&sz,&Asr[i][2]);
                 fscanf(fibe,"%f %f %f %f\n",&Asi[i][0],&Asi[i][1],&sz,&Asi[i][2]);
                 fscanf(fzbe,"%f %f %f %f\n",&Asz[i][0],&Asz[i][1],&sz,&Asz[i][2]);
                 }




printf("Beolvasva:\n");
//megm�ri a f�jl hossz�t, ki is tudja irni mit olvas be
while(!feof(f)){
  for(k=0;k<n;k++) fscanf(f,  "%f  %s  %f  %f  %f\n",&Adat[k][3],szuro,&Adat[k][0],&Adat[k][1],&Adat[k][2]);
  for(k=0;k<n;k++) printf(  "%d  %s  %f  %f  %f\n",int(Adat[k][3]),szuro,Adat[k][0],Adat[k][1],Adat[k][2]);       printf("\n");
  m++; }

printf("szamolt kepek: %d\n",m);
getchar();






rewind (f);



dat=2400000;  // kezd� d�tum, hogy sz�p legyen a grafikon, MJD

/*m�k�d�s: bels� ciklus beolvassa az adatokat, annyi sort ah�ny referencia csillag van,
a k�ls� ciklus pedig annyiszor csin�lja ezt amennyi m�rt �jszaka van *4.
sz�r�t is beolvassa, �s ennek megfelel�en k�l�nb�z�en j�r el.
j� sz�r�s f�nyess�g adatokat elk�ldi a f�ggv�nynek, referencia csillagok f�nyess�g�t kivonja az adatokb�l,
majd az �tlag�t kivonja az objektum f�yness�g�b�l, majd f�ljba �rja, sz�r�nk�nt m�sba*/



for(i=0;i<m;i++){

  for(k=0;k<n;k++){
  fscanf(f,  "%f  %s  %f  %f  %f\n",&Adat[k][3],szuro,&Adat[k][0],&Adat[k][1],&Adat[k][2]);
  }
  
  eg=0; er=0; ei=0; ez=0; //null�zza a k�l�nbs�get. Ha 0 marad, nem �rja ki
  for(k=0;k<l;k++){
                   if( int(Asg[k][0]+dat)==int(Adat[0][0]) ){eg=Asg[k][1]; szg=Asg[k][2];}
                   if( int(Asr[k][0]+dat)==int(Adat[0][0]) ){er=Asr[k][1]; szr=Asr[k][2];}
                   if( int(Asi[k][0]+dat)==int(Adat[0][0]) ){ei=Asi[k][1]; szi=Asi[k][2];}
                   if( int(Asz[k][0]+dat)==int(Adat[0][0]) ){ez=Asz[k][1]; szz=Asz[k][2];}
                   }



    for(k=0;k<n;k++){
  if(*szuro=='g'){ e=eg;  sz=szg;
  if(e!=0) printf("%d %f %f %f %f %s\n",int(Adat[k][3]),Adat[k][0],Adat[k][1]-e,e,sz,szuro); 
  if(e!=0) fprintf(fg,"%d %f %f %f %f\n",int(Adat[k][3]),Adat[k][0]-dat,Adat[k][1]-e,Adat[k][2],sz); }
  
  if(*szuro=='r'){ e=er;  sz=szr;
  if(e!=0) printf("%d %f %f %f %f %s\n",int(Adat[k][3]),Adat[k][0],Adat[k][1]-e,e,sz,szuro);   
  if(e!=0) fprintf(fr,"%d %f %f %f %f\n",int(Adat[k][3]),Adat[k][0]-dat,Adat[k][1]-e,Adat[k][2],sz); }
  
  if(*szuro=='i'){ e=ei;   sz=szi;
  if(e!=0) printf("%d %f %f %f %f %s\n",int(Adat[k][3]),Adat[k][0],Adat[k][1]-e,e,sz,szuro);
  if(e!=0) fprintf(fi,"%d %f %f %f %f\n",int(Adat[k][3]),Adat[k][0]-dat,Adat[k][1]-e,Adat[k][2],sz); }
  
  if(*szuro=='z'){ e=ez;   sz=szz;
  if(e!=0) printf("%d %f %f %f %f %s\n",int(Adat[k][3]),Adat[k][0],Adat[k][1]-e,e,sz,szuro);
  if(e!=0) fprintf(fz,"%d %f %f %f %f\n",int(Adat[k][3]),Adat[k][0]-dat,Adat[k][1]-e,Adat[k][2],sz); }
    }
  
 if(e!=0) printf("\n");


}

printf("ID, JD, eredmeny, kulonbseg, szoras, szuro\n");



//amit ki�r: id, k�l�nbs�g, szor�sa, eredm�ny, sz�r� (ellen�rz�)

      //kimenet: d�tum, f�nyess�g, f�nyess�g hiba, kivon�s hib�ja 
      //x-gorbe-be,   p x-gorbe u 2:($3-2*$1) (x szuro) �brazolhato sz�r�nk�nt az �sszes ref csillag f�nyess�ge az id�ben


fclose(f);



fclose(fgbe);
fclose(frbe);
fclose(fibe);
fclose(fzbe);

getchar();








//2. resz: a kapottak analizise =================================================
rewind (fg);
rewind (fr);
rewind (fi);
rewind (fz);

//hibas a szoras jelenleg
//atlag= szum(n) ertek_n*f(hiba)_n / f(hiba)_n , f(hiba)=0.1/hiba^2 , gnuplotbol illesztve



//proba beolvasas, a fajl hossz meresere
m=0;
while(!feof(fg)){
  fscanf(fg,  "%f  %f  %f  %f %f\n",&Adatk[k][4],&Adatk[k][0],&Adatk[k][1],&Adatk[k][2],&Adatk[k][3]);
  m++; }
rewind (fg);

printf("Beolvasott sorok:%d\n",m);



//g amit kiirtunk, be is olvassuk (id datum ertek hibak)
printf("Beolvasva: (g)\n\n");
for(k=0;k<m;k++){
  fscanf(fg,  "%f  %f  %f  %f %f\n",&Adatk[k][4],&Adatk[k][0],&Adatk[k][1],&Adatk[k][2],&Adatk[k][3]);
  printf("%d  %f  %f  %f  %f\n",int(Adatk[k][4]),Adatk[k][0],Adatk[k][1],Adatk[k][2],Adatk[k][3]);
  }

  
printf("\n");

  
for(i=1;i<n+1;i++){  
// megfelelo fajltombbe rakas
 j=0; szg=0;
 for(k=0;k<m;k++){
                           if(int(Adatk[k][4])==i){ Adat[j][0]=Adatk[k][1]; 
                           Adat[j][2]=sqrt(Adatk[k][2]*Adatk[k][2]+Adatk[k][3]*Adatk[k][3]); //printf("wut\n");
                           j++;}
                           }
                         
 for(k=0;k<j;k++){
                           
                           Adat[k][1]=Adat[k][0]*(0.1/pow(Adat[k][2],2));
                           szg=szg+(0.1/pow(Adat[k][2],2));}
                           
 //for(k=0;k<j;k++) printf("%d %f %f\n",i,Adat[k][0],Adat[k][2]);
 //printf("\n");
                           
                           
 e=kivonasv(Adat,Tg,j,szg);
 sz=hibav(Adat,Tg,j,szg);
                           
 fprintf(fgk,"%d %f %f\n",i,e,sz);
 }




//r
for(k=0;k<m;k++){
  fscanf(fr,  "%f  %f  %f  %f %f\n",&Adatk[k][4],&Adatk[k][0],&Adatk[k][1],&Adatk[k][2],&Adatk[k][3]);
  }
  
for(i=1;i<n+1;i++){  
// megfelelo fajltombbe rakas
 j=0; szr=0;
 for(k=0;k<m;k++){
                           if(Adatk[k][4]==i){ Adat[j][0]=Adatk[k][1]; 
                           Adat[j][2]=sqrt(Adatk[k][2]*Adatk[k][2]+Adatk[k][3]*Adatk[k][3]);
                           j++;}
                           }

                       
 for(k=0;k<j;k++){
                           
                           Adat[k][1]=Adat[k][0]*(0.1/pow(Adat[k][2],2));
                           szr=szr+(0.1/pow(Adat[k][2],2));}
                           
                           
 e=kivonasv(Adat,Tr,j,szr);
 sz=hibav(Adat,Tr,j,szr);
                           
 fprintf(frk,"%d %f %f\n",i,e,sz);
 }
 
 


//i
for(k=0;k<m;k++){
  fscanf(fi,  "%f  %f  %f  %f %f\n",&Adatk[k][4],&Adatk[k][0],&Adatk[k][1],&Adatk[k][2],&Adatk[k][3]);
  }
  
for(i=1;i<n+1;i++){  
// megfelelo fajltombbe rakas
 j=0; szi=0;
 for(k=0;k<m;k++){
                           if(Adatk[k][4]==i){ Adat[j][0]=Adatk[k][1]; 
                           Adat[j][2]=sqrt(Adatk[k][2]*Adatk[k][2]+Adatk[k][3]*Adatk[k][3]);
                           j++;}
                           }

                         
 for(k=0;k<j;k++){
                           
                           Adat[k][1]=Adat[k][0]*(0.1/pow(Adat[k][2],2));
                           szi=szi+(0.1/pow(Adat[k][2],2));}
                           
                           
 e=kivonasv(Adat,Ti,j,szi);
 sz=hibav(Adat,Ti,j,szi);
                           
 fprintf(fik,"%d %f %f\n",i,e,sz);
 }
 
 


//z
for(k=0;k<m;k++){
  fscanf(fz,  "%f  %f  %f  %f %f\n",&Adatk[k][4],&Adatk[k][0],&Adatk[k][1],&Adatk[k][2],&Adatk[k][3]);
  }
  
for(i=1;i<n+1;i++){  
// megfelelo fajltombbe rakas
 j=0; szz=0;
 for(k=0;k<m;k++){
                           if(Adatk[k][4]==i){ Adat[j][0]=Adatk[k][1]; 
                           Adat[j][2]=sqrt(Adatk[k][2]*Adatk[k][2]+Adatk[k][3]*Adatk[k][3]);
                           j++;}
                           }

                         
 for(k=0;k<j;k++){
                           
                           Adat[k][1]=Adat[k][0]*(0.1/pow(Adat[k][2],2));
                           szz=szz+(0.1/pow(Adat[k][2],2));}
                           
                           
 e=kivonasv(Adat,Tz,j,szz);
 sz=hibav(Adat,Tz,j,szz);
                           
 fprintf(fzk,"%d %f %f\n",i,e,sz);
 }

                           
// x-ref-be megy ez a r�sz




fclose(fg);
fclose(fr);
fclose(fi);
fclose(fz);

getchar();









//3. resz: a szini iteracio =================================================
rewind (fgk);
rewind (frk);
rewind (fik);
rewind (fzk);

//beolvasas
for(i=0;i<n;i++){
      
      fscanf(fgk,"%f %f %f\n",&eg,&Adat[i][0],&Adatk[i][1]);
      fscanf(frk,"%f %f %f\n",&er,&Adat[i][1],&Adatk[i][2]);
      fscanf(fik,"%f %f %f\n",&ei,&Adat[i][2],&Adatk[i][3]);
      fscanf(fzk,"%f %f %f\n",&ez,&Adat[i][3],&Adatk[i][4]);
      
      }


fprintf(fgk,"\n\nSzinkorrigalt:\n");
fprintf(frk,"\n\nSzinkorrigalt:\n");
fprintf(fik,"\n\nSzinkorrigalt:\n");
fprintf(fzk,"\n\nSzinkorrigalt:\n");

//kiiras
for(i=0;i<n;i++){
      
      fprintf(fgk,"%d %f %f\n",i+1,Adat[i][0]-Cg*(Adat[i][0]-Adat[i][2]),Adatk[i][1]);
      fprintf(frk,"%d %f %f\n",i+1,Adat[i][1]-Cr*(Adat[i][0]-Adat[i][2]),Adatk[i][2]);
      fprintf(fik,"%d %f %f\n",i+1,Adat[i][2]-Ci*(Adat[i][0]-Adat[i][2]),Adatk[i][3]);
      fprintf(fzk,"%d %f %f\n",i+1,Adat[i][3]-Cz*(Adat[i][0]-Adat[i][2]),Adatk[i][4]);
      
      }


//kepernyore iras
printf("Vegso kimenet:\nID szuro ertek hiba\n\n");
for(i=0;i<n;i++){
      
      printf("%d g %f %f\n",i+1,Adat[i][0]-Cg*(Adat[i][0]-Adat[i][2]),Adatk[i][1]);
      printf("%d r %f %f\n",i+1,Adat[i][1]-Cr*(Adat[i][0]-Adat[i][2]),Adatk[i][2]);
      printf("%d i %f %f\n",i+1,Adat[i][2]-Ci*(Adat[i][0]-Adat[i][2]),Adatk[i][3]);
      printf("%d z %f %f\n",i+1,Adat[i][3]-Cz*(Adat[i][0]-Adat[i][2]),Adatk[i][4]);
      printf("\n");
      
      }








fclose(fgk);
fclose(frk);
fclose(fik);
fclose(fzk);

printf("\nVege\n");
getchar();
return 0;

//kimenet: x-ref a csillagok vegso standard f�nyess�ge
//p "x-gorbe u 2:($3-2*$1)"		

}
