#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>

#define PI 3.14159265358979

using namespace std;


/*
Ez a program a beviteli magnitudokat integralja ki, hogy bolometrikus fenygorbe legyen belole.
Supported:
sdss: g r i z u
johnson: V R I B U
Swift: w2 m2 w1 u b v
johnson: J H K
sdss es johnson kozott a mod-dal kell valtani. johnson JHK-ra nem vonatkozik
U u kesobb lett belerakva, ezert kezeli a program utolsokent

- johnson/sdss l-gorbe.txt a bevitel, JD mag magerr magerr formaban! l helyere a szuro neve (g-gorbe.txt pl)
A 2. mag err a valodi hiba!   kulso==0!
Ha kulso==1 akkor all-gorbe.txt es ebben legyenek egymas mellett a johnson/sdss szurok
JD u g r i z , JD U B V R I !   es ertelem szeruen szuro mellett a hiba
- Swift swiftbe.txt a bevitel, JD w2 w2err m2 m2err w1 w1err u uerr b berr v verr
formatumban kell szerepelnie. Ha valamelyik nincs, akkor oda irj 0/-1 eket!
Ha nincs Swift meres/adat, akkor egyszeruen kihagyja
- JHK JHK-gorbe.txt a bevitel, JD J Jerr H Herr K Kerr 
formatumban kell szerepelnie. Ha valamelyik nincs, akkor oda irj 0/-1 eket!
- 1 sdss/johnson-ra is lefut, a tobbit kihagyja. 
0-val bar lefut, de HIBAS LESZ!!! mert a JD-t innen szamitja

JD-ket sorba rendezi mindegyiknel.
Elobb a johnson/sdss -el dolgozik, rendezi, egy adat tombe rakja
TILTAS-sal kiveheto az ami nem kell
Ennek a JD-je lesz az etalon, ezt fogja a tobbinel hasznalni JD[] !!!
Interpolal azokra az adatok, ahol van szomszedos adat, de nincs adat (interpol() )
Interpol: y=ym+ (x-xm) * (yp-ym) / (xp-xm)
Fluxust szamol: 
johnson: flux_l=10.0^(-0.4*(mag+48.60-nedl))*300.0/( (l*1e-8)*(l*1e-8) )   (JHK is)
sdss   : flux_l=10.0^(-0.4*(mag+K_l  -nedl))
l hullamhossz, nedl ehhez a hullamhosszhoz tartozo hullamhossz, K l fuggo konstants (Vega mag)
Berakja adatflux adat tipusba

Swift JD rendezes
Etalon JD[]-re interpolalja az adatokat!
+2 napot meg extrapolal, a tobbi napot ervenyteleniti
Fluxust szamol:
flux=texp( -0.4* (mag+ZP-(C*EBV) ) );   ZP pozitiv, C pozitiv, texp 10^()
Berakja adatflux adat tipusba

JHK is van rendezes
interpolal==1-nal etalon JD[]-re interpolal
interpolal==0-nal etalon JD[]-vel megegegyezo napokat rak bele
flux szamol (fenti keplet), es berakja az adatfluxba

Integralas, bolint(), bolhib()
Elotte l szerint rendezi az adatokat
Csak akkor csinalja ha van legalabb 3 szuro
A fuggveny trapezoid modszerrel integral a szurok kozott.
IR:
- Rayleigh-Jeans kozelitessel
- Fekete test integral
UV: pedig empirikus kozelitessel veszi figyelembe:
- Legrovidebb l es lecsap kozott derkszogu 3szog terulete
- lecsapig extrapolalja a fluxust (2 legrovidebbol), aztan 0, ennek a terulete
- Fekete test integral
Hiba hibaterjedessel, FTS numerikusan
Ez utan bolometrikus magniba konvertal
EZT A SZEKCIONAL LEHET ALLITANI, KICSIT LEJEBB!!!!

Mindig a letezo szuroket integralja ki, ha 3 van akkor csak annyit, ha 10 akkor annyit!
Masik adat: kiirja a BC egy szint es azok hibajat is, hogy a szinbol valo szamitassal osszevetheto legyen
sdss:     BC=bol-g    szin=g-r
johnson:  BC=bol-B    szin=B-I
Az ebbol szamitja a bolt:
BC_g = 0.053 - 0.089 � (g - r) - 0.736 � (g - r)^2
BC_B = 0.004 - 0.297 � (B - I) - 0.149 � (B - I)^2
Lymann et al.


Extinkcio: (nedx) R=
U:4.9
B:4.1
V:3.1
R:2.4
I:1.7
J:0.8
H:0.5
K:0.3
*E(B-V) = EBV
*/



//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// swift JD-hez hozza adja ezt a szamot (mert elterhet a masikhoz kepest)
float datenull=-2400000;



int tiltas(float JD){
int e=1;	

			// tilt�s megad�sa: (nincs tilt�s eset�n 1)
	      	// if(JD=="") e=0;    "" <- ide jon a tiltott JD
			if(JD==56701.500000) e=0;
			if(JD==56784.000000) e=0;

return e;			
}




	  		// sdss griz :0 vagy Johson BVRI :1 bolometrikus integralas
	    	int mod=1;
	    	// kulso forras fajl legyen?
	    	int kulso=0;
	    	// legyen interpolacio?
	    	int interpolal=1;
	  
	  
	        // NED korrekci�k megad�sa: g/V r/R i/I z/B
	        
	        // NGC 3448
	        // g r i z
	        //float nedu=0.;
            //float nedg=0.113;
            //float nedr=0.092;
            //float nedi=0.068;
            //float nedz=0.051;
            
            // NGC 6412
	        // V R I B
	        float nedu=0.;
            float nedg=0.111;
            float nedr=0.087;
            float nedi=0.061;
            float nedz=0.146;
            
            // M51
	        // V R I B
	        //float nedu=0.152;
            //float nedg=0.096;
            //float nedr=0.076;
            //float nedi=0.053;
            //float nedz=0.127;
            
            // JHK extinkciok, azonos modon
            // M51
            float nedj=0.025;
            float nedh=0.016;
            float nedk=0.011;
            
            // swift-hez az extinkcio, B-V extinkcioja az EBV, johnson modban tulajdonkeppen nedz-nedg
            //float EBV=0.011;    // NGC 3448
            float EBV=nedz-nedg;
            
            // tavolsag megadasa:
			// NGC 6412, NGC 3448
            float tav=23.5  * 3.086*pow(10,22);   // Mpc --> m
            
            // M51
            //float tav=8.7  * 3.086*pow(10,22);   // Mpc --> m
   
            
            

            
            
			
            
//Dessart, Hillier 2005
//BVI
float ad=0.63241;
float bd=-0.38375;
float cd=0.28425;            








FILE *Trki;

float lsu=0.;
float lsg=0.; // g r i z hullamhossz valtozo
float lsr=0.;
float lsi=0.;
float lsz=0.;

float lju=0.;
float ljv=0.; // V R I B hullamhossz valtozo
float ljr=0.;
float lji=0.;
float ljb=0.;

float Thib=0; // T FTS hibaja



// abszolet ertek
float absz(float x){
	  if(x<0) x=-x;
	  
	  return x;	  
	  }

// negyzet	  
float h(float x){
	  return x*x;
	  }
	
// negyzet osszeg gyoke (a hibahoz)  
float h(float x, float y){
	  return sqrt(x*x+y*y);
	  }



// linearis interpolacio
float interpol(float x, float xm, float ym, float xp, float yp){
	  float y;
	  
	  y=ym+ (x-xm) * (yp-ym) / (xp-xm);
	  
	  return y;
	  }
	  

// reverz interpolacio
float revinterpol(float y, float xm, float ym, float xp, float yp){
	  float x;
	  
	  x=xm+ (y-ym) * (xp-xm) / (yp-ym);
	  
	  return x;
	  }
	  
	  
	  
// linearis interpolacio
float interpolhib(float x, float xm, float yme, float xp, float ype){
	  float yh;
	  
	  yh=h( (1 -(x-xm)  / (xp-xm))*yme  )
	  +  h( (   (x-xm)  / (xp-xm))*ype  );
	  
	  return sqrt(yh);
	  }
	  
	  
void interpolszol(float x, float xm, float yme, float xp, float ype, string c){
	 
	 if(xp-xm>30) cout << "I.pol.: 30nap+ lyuk!  " << c << ":  @: " << x << "      " << xm << "  " << xp << " kozt\n";
	 
	 }
	  
	  
	  
	  
// Fekete Test Sugarzas, F_f es F_l is   W/m^2/m --> erg/s/cm^2/A   es  erg/s/cm^2/Hz
float FTS(float l, float T){
	  float B;
	  l=l/1e10;
	  
	  if(mod==0) B= 1000*      PI* 2*3e8*3e8*6.626e-34* pow(l,-5) /(exp(3e8*6.626e-34/l/T/1.38e-23)-1) * l*l/3e8;
	  if(mod==1) B= 1000/1e10* PI* 2*3e8*3e8*6.626e-34* pow(l,-5) /(exp(3e8*6.626e-34/l/T/1.38e-23)-1) ;
	  
	  return B;
	  }
	  
// Fekete Test Sugarzas, F_f es F_l is   W/m^2/m --> erg/s/cm^2/A   es  erg/s/cm^2/Hz    
// DOUBLE-val!!! Integralas-ra hasznalt!
double FTSd(double l, float T){
	  double B;
	  
	  if(mod==0) B= 1000*      PI* 2*3e8*3e8*6.626e-34* pow(l,-5) /(exp(3e8*6.626e-34/l/T/1.38e-23)-1) * l*l/3e8;
	  if(mod==1) B= 1000/1e10* PI* 2*3e8*3e8*6.626e-34* pow(l,-5) /(exp(3e8*6.626e-34/l/T/1.38e-23)-1) ;
	  
	  return B;
	  }
	  

// FTS integralja 
float FTSint(float s, float tig, float T){	  
	  double v=0;
	  double a;
	  double ce;
	  double ck;
	  double ch;
	  double cn;
	  double i;

	double dt=0.01e-9;
	
	tig=tig/dt/1e10;
	s=s/dt/1e10;

	//RK ciklus
	for(i=s;i<tig;i++){

	   a=FTSd(i*dt,T);
	   ce=dt*a;

	   a=FTSd((i+0.5)*dt,T);
	   ck=dt*a;

   	   a=FTSd((i+0.5)*dt,T);
   	   ch=dt*a;

  	   a=FTSd((i+1.0)*dt,T);
  	   cn=dt*a;

  	   v=v+(1.0/6.0)*ce+(1.0/3.0)*ck+(1.0/3.0)*ch+(1.0/6.0)*cn;  // RungeKutta modszer
  	   
       }

return float(1e10*v);  // mertek egyseg!
}













// flux adat
struct adatflux{
	float l;
	float flux;
	float err;
	
};


//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// mely hullamhosszakra engedelyezze a FTS illesztest? (e=1 mind)
int szabadl(float l){
	int e=0;
	
	//if(l==ljv) e=1;
	//if(l==ljr) e=1;
	//if(l==lji) e=1;
	//if(l==ljb) e=1;
	//if(l==12600) e=1;
	//if(l==16000) e=1;
	//if(l==22200) e=1;
	e=1;
	
	return e;
	}

/*
Fluxus integralas, ha nincs valahol eleg adat kilep es 0 (3 kell legalabb)
adatflux-t hasznal, ez tartalmazza a hullamhosszat, fluxust, es hibat is
a program ugy csinalja, hogy a bemenetben csak a jo adatok legyenek es azok is sorban
kikommentelhetoek egyes sorok, hogy azokat ne vegye szamitsba

trapezoid modszer: ismert adatokra. 2 szuro kozti reszt integralja
nem ismert tartomanyok a trukkosek. ezekbol lehet ki kommentelgetni
Illeszt egy fekete test-t is a vegen (ez kikapcsolhato)
IR:
Rayleigh-Jeans kozelites     gyors mert analitikus, de kevesbe pontos, de elfogadhato lehet
feteke test valodi integralja    lassu, mert illeszt, de pontos, es jo felteves
UV:
levagas: legrovidebb szuro, es a lecsap kozotti terulet fele      gyors, egyszeru
extrapolacio: extrapolalja a fluxust (2 legrovidebbol) lecsapig, majd lecsaptol 0, es ennek az integralja
  gyors, valamivel eszszerubb model
fekete test integralja UV-ra      lassu, csak nagyon korai fazisban igaz, utana nem az (sok fem vonal)

fekete test illesztes: racs modszer, vegig nezi az osszeset, adaptiv lepeskozokkel
valtokozo lepeskozokkel szorastol fuggoen
T es a szorzot is illeszti (Tallgyarto.cpp analog modon)
stefan boltzmann torveny (szigma*T^4)-el szamolja ki a teljes integralt
utana Runge-Kutta modszerrel integralja l1-tol l2-ig
l2 a leghosszabb hullamhosszu szuro
l1 vagy a legrovidebb, vagy 1A, attol fuggoen UV fekete testet is akarunk, vagy valami mas modszert alkalmazunk
az integralt utana kivonjuk a teljes fekete testbol (amit a stefan boltzmannbol kaptunk)
majd utana hozza adjuk a trapezoiddal kapott erteket

szabadl megadja mely l-ekre illesszen
*/
// hol vagja le a spektrumot, ahol mar 0
float lecsap=2800.;

//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
float bolint(adatflux flux[], int n){
	  if(n<3) return 0;
	  
	  float bol=0;
	  float extra=0;
	  float lecsapc=0;
	  int i;
	  
	  extra=interpol(lecsap , flux[0].l, flux[0].flux, flux[1].l, flux[1].flux);
	  lecsapc=revinterpol(0., flux[0].l, flux[0].flux, flux[1].l, flux[1].flux);
	  if(extra>0) lecsapc=lecsap; else extra=0;
	  
	  // 2 szuro kozotti trapezoid integral
	  for(i=0;i<n-1;i++) bol=bol+( flux[i].flux+0.5*(flux[i+1].flux-flux[i].flux) )*( flux[i+1].l-flux[i].l );
	  
	  // Rayleigh-Jeans kozelito farok int
	  bol=bol+(flux[n-1].l*flux[n-1].flux)/3.0;    // RJ
	  
	  // Empirikus kozeleites az UV-ra, ha nagy a lecsap, akkor nem szamolja
      //if(lecsap<flux[0].l) bol=bol+0.5*( flux[0].l-lecsap )*flux[0].flux;                   // levagas
	  if(lecsapc<flux[0].l) bol=bol+( extra+0.5*(flux[0].flux-extra) )*( flux[0].l-lecsapc );   // extrapolacio


	  if(0){ // kikapcsolo
	  int j=0;
	  float e;     // C(R)
	  float s;     // szoras
	  float sz;    // szoras tarolo
	  float szz;   // seged
	  float Ttemp; // T futo
	  float T;     // T
	  float Terr;  // T hiba
	  float Tsz;   // T szoras
	  float Te;    // T hiba
	  float en;    // e-nek a kezdetije
	  float R;	   // sugar	
	  float Re;	   // sugar	hiba


	  // engedelyezett l, ha keves, kilep
	  for(i=0;i<n;i++) if( szabadl(flux[i].l) ) j++; ;
	  if(j<3){ Thib=0; return bol; }
	  
	  szz=0;
	  for(i=0;i<n;i++) if( szabadl(flux[i].l) ) szz=szz+1/h(log(flux[i].err));
	  
	  en=-2.5*log10(flux[1].flux)+2.5*log10(FTS(flux[1].l,8000));

	  Tsz=10000;
	  Ttemp=1500;
	  j=0;
				 
	  while(Ttemp<20100){
				  sz=10000;					
				  e=en-18;				 
				  while(e<en+12){
 			 	 			 
							 s=0;
							 // hiba negyzettel sulyozott szoras, legkisebb negyzetek
							 for(i=0;i<n;i++)	if( szabadl(flux[i].l) )		 
 			 	 			 s=s+h( 2.5*log10(flux[i].flux)-2.5*log10(FTS(flux[i].l,Ttemp))+e )  /h(2.5*log10(flux[i].err)) ; 
							 //s=sqrt(s/n);
						     s=sqrt( s/szz );
 			 	 			 
 			 	 			 
				 			 if( s<Tsz ){ T=Ttemp; Tsz=s;  Te=e; }
				 			 if( s<sz ){ sz=s; } // adott T-n a legjobb erteket tarolja
				 			 
				 			 
				 			 e=e+s/10;
				 			 //if(s<1)  e=e+0.01; 
				 			 //if(s>=1) e=e+0.1;
				 			 //if(s>=8) e=e+0.9;
				 			 
							 }
							 
				 //if(sz>1.1*Tsz)  j++;
				 if(sz<=1.1*Tsz){ j=0; Terr=Ttemp-T; }
				 Ttemp=Ttemp+500*sz;	 
				 //if(j<11)  Ttemp=Ttemp+50; 
				 //if(j>=11) Ttemp=Ttemp+300; 
				 //printf("%f %f   \n",s,Ttemp);
				 }
				 
	
	  // sugar szamolas			 
	  R=pow(10,-0.2*Te) / (ad+bd*1e4/T+cd*1e8/T/T) *tav;
      Re=h( -0.2*log(10)*pow(10,-0.2*Te)*Tsz / (ad+bd*1e4/T+cd*1e8/T/T) ) ;
      Re=sqrt(Re)*tav;
	  			 
      printf("T:%d  \terr:%d   \tC(R):%f       szoras:%f    R:%d\n",int(T+0.5),int(Terr+0.5),Te,Tsz,int(R/150e9+0.5));
      fprintf(Trki,"%d  %d  %f  %f  %f  %f\n",int(T+0.5),int(Terr+0.5),Te,Tsz,R/150e9,Re/150e9);
      Te=pow(10,-0.4*Te);
      
	
	  // FTS-ek hozzadasa			 
	  //Ttemp=Te*5.67e-8*T*T*T*T*1000-Te*FTSint(flux[0].l,flux[n-1].l,T);     // FTS mindenre ami nincs merve
	  Ttemp=Te*5.67e-8*T*T*T*T*1000-Te*FTSint(1,flux[n-1].l,T);               // FTS csak az utolso szuro utan
	  bol=bol+Ttemp;
	  
	  // FTS hiba szamitasa
	  T=T+Terr;
	  //Thib=Te*5.67e-8*T*T*T*T*1000-Te*FTSint(flux[0].l,flux[n-1].l,T)-Ttemp;     // FTS mindenre ami nincs merve
	  Thib=Te*5.67e-8*T*T*T*T*1000-Te*FTSint(1,flux[n-1].l,T)-Ttemp;             // FTS csak az utolso szuro utan
	  
	  
	  }
	  
	  
	  return bol;
	  }


// hiba: hibaterjedes: ha nincs valahol eleg adat kilep es 0 (itt is 3 kell)
// ahol nincs adat, ott 0 a hiba, igy az nincs figyelembe veve: nem okoz problemat
// adatflux-t hasznal, ez tartalmazza a hullamhosszat, fluxust, es hibat is
// a program ugy csinalja, hogy a bemenetben csak a jo adatok legyenek es azok is sorban
// kikommentelhetoek egyes sorok, hogy azokat ne vegye szamitsba
// FTS T illesztest is figyelembe veszi, de azt maga az integral szamolja, es adja at ennek
// Vigyazat, csak akkor mukodik ha a main-ban egy for cikluson bellul van a ketto, sorrendben!!!
// trapezoid integrlasasok hibaterjedesel, magyarul a hiba
float bolhib(adatflux flux[], int n){
	  if(n<3) return 0;
	  
	  float hib=0;
	  float extrah=0;
	  float lecsapc;
	  int i;
	  
	  lecsapc=revinterpol(0., flux[0].l, flux[0].flux, flux[1].l, flux[1].flux);
	  if( interpol(lecsap , flux[0].l, flux[0].flux, flux[1].l, flux[1].flux) >0) lecsapc=lecsap;
	  extrah=interpolhib(lecsapc, flux[0].l, flux[0].err, flux[1].l, flux[1].err);
	  
	  
	  //2. es utolso elottit rakja ossze
	  for(i=1;i<n-1;i++) hib=hib+ h( 0.5*flux[i].err *( flux[i].l-flux[i-1].l )   + 0.5*flux[i].err *( flux[i+1].l-flux[i].l ) );
	  
	  //Utolso kulon + Rayleigh-Jeans (2. sort usd ki ha nem kell)
	  hib=hib+ h(  0.5*flux[n-1].err *( flux[n-1].l-flux[n-2].l )   
	  
	  + (flux[n-1].l*flux[n-1].err)/3.0     // RJ
	  
	  );
	  //Elsot kulon + empirikus (2. sort usd ki ha nem kell)
	  hib=hib+ h(  0.5*flux[0].err *( flux[1].l-flux[0].l )
	  
	  //+ 0.5*flux[0].err *(flux[0].l-lecsap)   *(lecsap<flux[0].l)      // levagas
	  + 0.5*flux[0].err *(flux[0].l-lecsapc)   *(lecsapc<flux[0].l)    // extrapolacio
	  
	  );
	  //UV flux extrapolalas hibaja
	  hib=hib+ h(  0.5*extrah*( flux[0].l-lecsapc )  )     *(lecsapc<flux[0].l);    // extrapolacio
	  
	  
	  //printf("T_hiba:%e alap_hiba:%e\n",h(Thib),hib);
	  // T FTS hiba
	  hib=hib+h(Thib);
	  
	  
	   
	  return sqrt(hib);
	  }











//swift adat
struct adatswift{
	float JD;
	float w2;
	float m2;
	float w1;
	float u;
	float b;
	float v;
	
};

//+
adatswift operator+(adatswift a,adatswift b){
	adatswift c;
	
	 c.JD=a.JD;//+b.JD;
	 c.w2=a.w2+b.w2;
	 c.m2=a.m2+b.m2;
	 c.w1=a.w1+b.w1;
	 c.u=a.u+b.u;
	 c.b=a.b+b.b;
	 c.v=a.v+b.v;
	
	return c;
}

//*
adatswift operator*(adatswift a,adatswift b){
	adatswift c;
	
	 c.JD=a.JD;
	 c.w2=a.w2*b.w2;
	 c.m2=a.m2*b.m2;
	 c.w1=a.w1*b.w1;
	 c.u=a.u*b.u;
	 c.b=a.b*b.b;
	 c.v=a.v*b.v;
	
	return c;
}

//*
adatswift operator*(adatswift a,float b){
	adatswift c;
	
	 c.JD=a.JD;
	 c.w2=a.w2*b;
	 c.m2=a.m2*b;
	 c.w1=a.w1*b;
	 c.u=a.u*b;
	 c.b=a.b*b;
	 c.v=a.v*b;
	
	return c;
}

//*
adatswift operator*(float b, adatswift a){
	adatswift c;
	
    c=a*b;

    return c;	
}

//-
adatswift operator-(adatswift a,adatswift b){
	adatswift c;
	
	c=a+(-1*b);
	
	return c;
}

//10^()
// -0.4 * -1 = 0.4 esetben az ertek nem jo, tehat 0
// ez a fajta megoldas azert kell, mert kulonben nem igaz, a 9. szamjegyben elteres van
adatswift texp(adatswift a){
	adatswift c;
	
	 c.JD=a.JD;
	 
	 if(int(a.w2*10000+0.5)!=4000) c.w2=pow(10,a.w2);
	 if(int(a.m2*10000+0.5)!=4000) c.m2=pow(10,a.m2);
	 if(int(a.w1*10000+0.5)!=4000) c.w1=pow(10,a.w1);
	 if(int(a.u *10000+0.5)!=4000) c.u=pow(10,a.u);
	 if(int(a.b *10000+0.5)!=4000) c.b=pow(10,a.b);
	 if(int(a.v *10000+0.5)!=4000) c.v=pow(10,a.v);
	 
	 if(int(a.w2*10000+0.5)==4000) c.w2=0;
	 if(int(a.m2*10000+0.5)==4000) c.m2=0;
	 if(int(a.w1*10000+0.5)==4000) c.w1=0;
	 if(int(a.u *10000+0.5)==4000) c.u=0;
	 if(int(a.b *10000+0.5)==4000) c.b=0;
	 if(int(a.v *10000+0.5)==4000) c.v=0;
	
	return c;
}

//csak a legnagyobb marad meg, a tobbi 0 lesz
adatswift errormax(adatswift b){
		  adatswift a;
		  a=b;
		  float max=a.w2;
		  int s=1;
		  
		  if(max<a.m2){ max=a.m2; s=2; }
		  if(max<a.w1){ max=a.w1; s=3; }
		  if(max<a.u ){ max=a.u ; s=4; }
		  if(max<a.b ){ max=a.b ; s=5; }
		  if(max<a.v ){ max=a.v ; s=6; }
		  
		  if(s!=1) a.m2=0;
		  if(s!=2) a.m2=0;
		  if(s!=3) a.w1=0;
		  if(s!=4) a.u =0;
		  if(s!=5) a.b =0;
		  if(s!=6) a.v =0;
		  
		  
		  return a;
		  }











			        







main ()
{

// ciklus v�lt
int i;
int j;
int k;

// param�terek
int n;  // nem haszn�lt
int m;

// seg�d sz�mok
int szum;  // JD t�bl�zat adatainak sz�m�t adja meg
int szumk; // fluxus t�bl�zat adatainak sz�ma
int csekk;
int csekkb;

// adatok sz�ma. EOFn�l megsz�molja
int uszam=0;
int gszam=0;
int rszam=0;
int iszam=0;
int zszam=0;

float csere; // csere seged


//els�k�nt k�zelit�leg az �jszak�k sz�ma, biztons�gi (nagy) sz�m, hogy biztosan benne legyen
m=200;


// ide olvas be
float Tu[m][4];
float Tg[m][4];
float Tr[m][4];
float Ti[m][4];
float Tz[m][4];
for(i=0;i<m;i++) for(j=0;j<4;j++) {Tu[i][j]=0; Tg[i][j]=0; Tr[i][j]=0; Ti[i][j]=0; Tz[i][j]=0;}

// �sszes JD
float JD[m];
// adatflux elem taroloja
int Tn[m];
for(i=0;i<m;i++) Tn[i]=0;

// osszeset tartalmazo adat t�mb
float Adat[m][11];	
float cserea[11];






// NED korrekci�k, es tav helyben, de globalisan vannak megadva!!!
//float nedg;
//float nedr;
//float nedi;
//float nedz;
//float tav;


//lejebb vannak deklaralva:
//float flux[szum][9];
//adatflux fluxusok[szumk][20];
//adatflux cseref;



FILE *usz;
FILE *gsz;
FILE *rsz;
FILE *isz;
FILE *zsz;
FILE *f;
FILE *bol;
FILE *bc;


//bemenet: 4 sz�r� f�nyess�g adatai
if(mod==0){
// ssds griz szurok hullamhosszai (A)
lju=lsu=3543.;
ljv=lsg=4770.;
ljr=lsr=6230.;
lji=lsi=7630.;
ljb=lsz=9130.;
usz=fopen("u-gorbeA.txt","rb");
gsz=fopen("g-gorbeA.txt","rb");
rsz=fopen("r-gorbeA.txt","rb");
isz=fopen("i-gorbeA.txt","rb");
zsz=fopen("z-gorbeA.txt","rb");
}

if(mod==1){
// johnson VRIB szurok hullamhosszai (A)
lju=lsu=3600.;
ljv=lsg=5450.;
ljr=lsr=6410.;
lji=lsi=7980.;
ljb=lsz=4380.;
usz=fopen("U-gorbeA.txt","rb");
gsz=fopen("V-gorbeA.txt","rb");
rsz=fopen("R-gorbeA.txt","rb");
isz=fopen("I-gorbeA.txt","rb");
zsz=fopen("B-gorbeA.txt","rb");
}


if(mod!=0 && mod!=1){ printf("Rosz paramter!\n"); getchar(); return 0; }

if(mod==0) printf("sdss griz mod\n\n");
if(mod==1) printf("Johnson BVRI mod\n\n");



if(usz == NULL) printf("u/U file nincs\n");
if(gsz == NULL) printf("g/V file nincs\n");
if(rsz == NULL) printf("r/R file nincs\n");
if(isz == NULL) printf("i/I file nincs\n");
if(zsz == NULL) printf("z/B file nincs\n");


//kimenet
f=fopen("AdatSor.txt","wt");
bol=fopen("bol-gorbe.txt","wt");
bc=fopen("BC-gorbe.txt","wt");
Trki=fopen("Tr-gorbe.txt","wt"); // Trki globalisan deklaralva, kiirja a T R ertekeket is kulon ( bolint() irja ki)


if(kulso==1){ usz = NULL; gsz = NULL; rsz = NULL; isz = NULL; zsz = NULL; }


// beolvas�s

i=0;
if(usz!=NULL) while (!feof(usz)){    fscanf(usz,"%f %f %f %f\n",&Tu[i][0],&Tu[i][1],&Tu[i][2],&Tu[i][3]); 
                              uszam++; i++;}
i=0;
if(gsz!=NULL) while (!feof(gsz)){    fscanf(gsz,"%f %f %f %f\n",&Tg[i][0],&Tg[i][1],&Tg[i][2],&Tg[i][3]); 
                              gszam++; i++;}
i=0;
if(rsz!=NULL) while (!feof(rsz)){	  fscanf(rsz,"%f %f %f %f\n",&Tr[i][0],&Tr[i][1],&Tr[i][2],&Tr[i][3]);  
                              rszam++; i++;}
i=0;
if(isz!=NULL) while (!feof(isz)){	  fscanf(isz,"%f %f %f %f\n",&Ti[i][0],&Ti[i][1],&Ti[i][2],&Ti[i][3]);  
                              iszam++; i++;}
i=0;
if(zsz!=NULL) while (!feof(zsz)){	  fscanf(zsz,"%f %f %f %f\n",&Tz[i][0],&Tz[i][1],&Tz[i][2],&Tz[i][3]);  
                              zszam++; i++;}

printf("\nBeolvasott r:\n");                              
for(i=0;i<rszam;i++) printf("%f %f %f %f\n",Tr[i][0],Tr[i][1],Tr[i][2],Tr[i][3]);
printf("\n"); 

//gszam++; rszam++; iszam++; zszam++; 
// Nem kell mert a beolvas�s m�g egy nem l�tez� sort is kiolvas. (eof file failorrel z�rul)
// A SZ�M�T adja meg! Nem az utols� elem t�mb sz�m�t (1 a k�l�nbs�g)                           

printf("beolvasott u/U=%d\n",uszam);
printf("beolvasott g/V=%d\n",gszam);
printf("beolvasott r/R=%d\n",rszam);
printf("beolvasott i/I=%d\n",iszam);
printf("beolvasott z/Z=%d\n",zszam);


if(usz!=NULL) fclose(usz);	  
if(gsz!=NULL) fclose(gsz);	
if(rsz!=NULL) fclose(rsz);
if(isz!=NULL) fclose(isz);
if(zsz!=NULL) fclose(zsz);




// itt fordul az U, es a vegere kerul, ott kezeli!


   
// JD-be �rat�s. Megkeresi milyen JD-k vannak 
// r/R, kezd�
for(i=0;i<rszam;i++){
    
    JD[i]=Tr[i][0];
    
    }
szum=rszam;
  
   
printf("szum r/R-nel=%d\n",szum);



// g/V
for(i=0;i<gszam;i++){
				 
     csekk=0;
     for(j=0;j<szum;j++){
	 					 if( JD[j]-Tg[i][0]<0.26 && JD[j]-Tg[i][0]>-0.26 ){ csekk=1; break; }
	 					 }
						 
	if(csekk==0 && Tg[i][0]!=0){
				 szum=szum+1;
				 JD[szum-1]=Tg[i][0];
				 }					 				 
    }
    
printf("szum g/V-nel=%d\n",szum);
    

// i/I    
for(i=0;i<iszam;i++){
				 
     csekk=0;
     for(j=0;j<szum;j++){
	 					 if( JD[j]-Ti[i][0]<0.26 && JD[j]-Ti[i][0]>-0.26 ){ csekk=1; break; }
						 }
						 
	if(csekk==0 && Ti[i][0]!=0){
				 szum=szum+1;
				 JD[szum-1]=Ti[i][0];
				 }					 						 
    }
    
printf("szum i/I-nel=%d\n",szum);


// z/B    
for(i=0;i<zszam;i++){
				 
     csekk=0;
     for(j=0;j<szum;j++){
	 					 if( JD[j]-Tz[i][0]<0.26 && JD[j]-Tz[i][0]>-0.26 ){ csekk=1; break; }
						 }
						 
	if(csekk==0 && Tz[i][0]!=0){
				 szum=szum+1;
				 JD[szum-1]=Tz[i][0];
				 }					 						 
    }

printf("szum z/B-nel=%d\n\n",szum);


// u/U   
for(i=0;i<uszam;i++){
				 
     csekk=0;
     for(j=0;j<szum;j++){
	 					 if( JD[j]-Tu[i][0]<0.26 && JD[j]-Tu[i][0]>-0.26 ){ csekk=1; break; }
						 }
						 
	if(csekk==0 && Tu[i][0]!=0){
				 szum=szum+1;
				 JD[szum-1]=Tu[i][0];
				 }					 						 
    }

printf("szum u/U-nel=%d\n\n",szum);



// sorba rendezi a JD-t
for(i=0;i<szum;i++){
					 
					 for(j=0;j<szum-1;j++)					  
                    	if(JD[j]>JD[j+1]){ csere=JD[j]; JD[j]=JD[j+1]; JD[j+1]=csere; }
					
					}


// kiiras
/*
printf("rendezett JD:\n");
for(i=0;i<szum;i++){
					printf("%f\n",JD[i]);
					}
*/					
					

		
					
// Egys�gesit�s, Adatba vitel					
for(i=0;i<szum;i++){
					Adat[i][0]=JD[i];
					
					csekk=0;
					for(j=0;j<gszam;j++){
										 if(JD[i]==Tg[j][0]){ csekk++; Adat[i][1]=Tg[j][1];
										 Adat[i][2]=Tg[j][3]; }
										 }
				    if(csekk==0){ Adat[i][1]=-1.0;  Adat[i][2]=0.0;  }
				    if(csekk>1) printf("Hiba: tobb adat (%d) g-ben JD=%f-nel",csekk,JD[i]);
					
					
					csekk=0;
					for(j=0;j<rszam;j++){
										 if(JD[i]==Tr[j][0]){ csekk++; Adat[i][3]=Tr[j][1];
										 Adat[i][4]=Tr[j][3]; }
										 }
				    if(csekk==0){ Adat[i][3]=-1.0;  Adat[i][4]=0.0;  }
				    if(csekk>1) printf("Hiba: tobb adat (%d) r-ben JD=%f-nel",csekk,JD[i]);
					
					
					csekk=0;
					for(j=0;j<iszam;j++){
										 if(JD[i]==Ti[j][0]){ csekk++; Adat[i][5]=Ti[j][1];
										 Adat[i][6]=Ti[j][3]; }
										 }
				    if(csekk==0){ Adat[i][5]=-1.0;  Adat[i][6]=0.0;  }
				    if(csekk>1) printf("Hiba: tobb adat (%d) i-ben JD=%f-nel",csekk,JD[i]);
				    
				    
   					csekk=0;
					for(j=0;j<zszam;j++){
										 if(JD[i]==Tz[j][0]){ csekk++; Adat[i][7]=Tz[j][1];
										 Adat[i][8]=Tz[j][3]; }
										 }
				    if(csekk==0){ Adat[i][7]=-1.0;  Adat[i][8]=0.0;  }
				    if(csekk>1) printf("Hiba: tobb adat (%d) z-ben JD=%f-nel",csekk,JD[i]);
				    
				    
				    csekk=0;
					for(j=0;j<uszam;j++){
										 if(JD[i]==Tu[j][0]){ csekk++; Adat[i][9]=Tu[j][1];
										 Adat[i][10]=Tu[j][3]; }
										 }
				    if(csekk==0){ Adat[i][9]=-1.0;  Adat[i][10]=0.0;  }
				    if(csekk>1) printf("Hiba: tobb adat (%d) u-ben JD=%f-nel",csekk,JD[i]);
				    
				    
					}

				
// Alternativ bevitel +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
FILE *fall;
fall=fopen("all-gorbe.txt","rb");

if(fall!=NULL && kulso==1){
i=0; 
szum=0;

while (!feof(fall)){  
			   //if(mod==0) fscanf(fall,"%f   %f   %f   %f   %f   %f   %f   %f   %f   %f   %f\n",&Adat[i][0],&Adat[i][9],&Adat[i][10],&Adat[i][1],&Adat[i][2],&Adat[i][3],&Adat[i][4],&Adat[i][5],&Adat[i][6],&Adat[i][7],&Adat[i][8]);
			   //if(mod==1) fscanf(fall,"%f   %f   %f   %f   %f   %f   %f   %f   %f   %f   %f\n",&Adat[i][0],&Adat[i][9],&Adat[i][10],&Adat[i][7],&Adat[i][8],&Adat[i][1],&Adat[i][2],&Adat[i][3],&Adat[i][4],&Adat[i][5],&Adat[i][6]);
			   
			   fscanf(fall,"%f   %f  %f  %f   %f   %f   %f   %f   %f   %f   %f\n",&Adat[i][0],&Adat[i][9],&Adat[i][10],&Adat[i][7],&Adat[i][8],&Adat[i][1],&Adat[i][2],&Adat[i][3],&Adat[i][4],&Adat[i][5],&Adat[i][6]);
			   
			   szum++; i++;}
	

for(i=0;i<szum;i++){
					if(Adat[i][1]==0) Adat[i][1]=-1; 
					if(Adat[i][3]==0) Adat[i][3]=-1;
					if(Adat[i][5]==0) Adat[i][5]=-1;
					if(Adat[i][7]==0) Adat[i][7]=-1;
					if(Adat[i][9]==0) Adat[i][9]=-1;
					}

printf("All szam:%d\n\n",szum);


//rendezes
//sorba rendezi a JD-t			 
for(i=0;i<szum;i++){
					 for(j=0;j<szum-1;j++)					  
                    	if(Adat[j][0]>Adat[j+1][0]) for(k=0;k<11;k++){ cserea[k]=Adat[j][k]; Adat[j][k]=Adat[j+1][k]; Adat[j+1][k]=cserea[k]; }
					
					 }
					 
					 


}
// alternativ bevitel ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++				
				
			
					
// f�jlba �rat�s
if(mod==0) fprintf(f,"JD             g mag       g err       r mag       r err       i mag       i err       z mag       z err       u mag      u err\n");				
if(mod==1) fprintf(f,"JD             V mag       V err       R mag       R err       I mag       I err       B mag       B err       U mag      U err\n");				

for(i=0;i<szum;i++){
					fprintf(f,"%f   %f   %f   %f   %f   %f   %f   %f   %f   %f   %f\n",Adat[i][0],Adat[i][1],Adat[i][2],Adat[i][3],Adat[i][4],Adat[i][5],Adat[i][6],Adat[i][7],Adat[i][8],Adat[i][9],Adat[i][10]);
										
					
					}				


// felszabaditja a beolvasott adatokat, mert ezek m�r a Adat-ban vannak					
//free(Tg);
//free(Tr);
//free(Ti);
//free(Tz);



		   		   	
				
// interpol(float x, float xm, float ym, float xp, float yp)					
// lin�ris interpol�ci�, N�ZD MEG!!!  Elso es utolsot nem csinalja
// Ha elso vagy utolsoknal nincs adat, azt nem interpolalja, az ugy marad
if(interpolal==1) for(i=1;i<szum-1;i++){
					
            //tilt�s:
			if(  tiltas(Adat[i][0])  )
			
					
					//g/V
					csekk=0; csekkb=0;
					if(Adat[i][1]==-1.0){  
										   while(Adat[i-1-csekk][1]==-1.0 && i-1-csekk>0) csekk++;
					                       while(Adat[i+1+csekkb][1]==-1.0 && i+1+csekkb<szum-1) csekkb++;
					                       
										   if( Adat[i-1-csekk][1]!=-1.0 && Adat[i+1+csekkb][1]!=-1.0 ){
						   	   			   interpolszol(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][1],Adat[i+1+csekkb][0],Adat[i+1+csekkb][1],"g/V");
										   Adat[i][1]=interpol(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][1],Adat[i+1+csekkb][0],Adat[i+1+csekkb][1]);
										   Adat[i][2]=interpolhib(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][2],Adat[i+1+csekkb][0],Adat[i+1+csekkb][2]);                                          
										   //Adat[i][2]=h(Adat[i-1-csekk][2],Adat[i+1+csekkb][2]);	
										   															}
										   }
					
					//r/R
					csekk=0; csekkb=0;
					if(Adat[i][3]==-1.0){  
                                           while(Adat[i-1-csekk][3]==-1.0 && i-1-csekk>0) csekk++;
					                       while(Adat[i+1+csekkb][3]==-1.0 && i+1+csekkb<szum-1) csekkb++;
					                       
					                       if( Adat[i-1-csekk][3]!=-1.0 && Adat[i+1+csekkb][3]!=-1.0 ){
										   interpolszol(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][3],Adat[i+1+csekkb][0],Adat[i+1+csekkb][3],"r/R");
										   Adat[i][3]=interpol(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][3],Adat[i+1+csekkb][0],Adat[i+1+csekkb][3]);
										   Adat[i][4]=interpolhib(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][4],Adat[i+1+csekkb][0],Adat[i+1+csekkb][4]);					                       
										   //Adat[i][4]=h(Adat[i-1-csekk][4],Adat[i+1+csekkb][4]);	
										   															}
										   }

                    //i/I
                    csekk=0; csekkb=0;
					if(Adat[i][5]==-1.0){  
										   while(Adat[i-1-csekk][5]==-1.0 && i-1-csekk>0) csekk++;
					                       while(Adat[i+1+csekkb][5]==-1.0 && i+1+csekkb<szum-1) csekkb++;
					                       
					                       if( Adat[i-1-csekk][5]!=-1.0 && Adat[i+1+csekkb][5]!=-1.0 ){
										   interpolszol(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][5],Adat[i+1+csekkb][0],Adat[i+1+csekkb][5],"i/I");
										   Adat[i][5]=interpol(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][5],Adat[i+1+csekkb][0],Adat[i+1+csekkb][5]);
										   Adat[i][6]=interpolhib(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][6],Adat[i+1+csekkb][0],Adat[i+1+csekkb][6]);
										   //Adat[i][6]=h(Adat[i-1-csekk][6],Adat[i+1+csekkb][6]);    
										   															}
										   }

					//z/B
					csekk=0; csekkb=0;
					if(Adat[i][7]==-1.0){  
										   while(Adat[i-1-csekk][7]==-1.0 && i-1-csekk>0) csekk++;
					                       while(Adat[i+1+csekkb][7]==-1.0 && i+1+csekkb<szum-1) csekkb++;
					                       
					                       if( Adat[i-1-csekk][7]!=-1.0 && Adat[i+1+csekkb][7]!=-1.0 ){
										   interpolszol(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][7],Adat[i+1+csekkb][0],Adat[i+1+csekkb][7],"z/B");
										   Adat[i][7]=interpol(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][7],Adat[i+1+csekkb][0],Adat[i+1+csekkb][7]);
										   Adat[i][8]=interpolhib(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][8],Adat[i+1+csekkb][0],Adat[i+1+csekkb][8]);
										   //Adat[i][8]=h(Adat[i-1-csekk][8],Adat[i+1+csekkb][8]);    
										   															}
										   }
										   
		            //u/U
					csekk=0; csekkb=0;
					if(Adat[i][9]==-1.0){  
										   while(Adat[i-1-csekk][9]==-1.0 && i-1-csekk>0) csekk++;
					                       while(Adat[i+1+csekkb][9]==-1.0 && i+1+csekkb<szum-1) csekkb++;
					                       
					                       if( Adat[i-1-csekk][9]!=-1.0 && Adat[i+1+csekkb][9]!=-1.0 ){
										   interpolszol(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][9],Adat[i+1+csekkb][0],Adat[i+1+csekkb][9],"u/U");
										   Adat[i][9]=interpol(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][9],Adat[i+1+csekkb][0],Adat[i+1+csekkb][9]);
										   Adat[i][10]=interpolhib(Adat[i][0],Adat[i-1-csekk][0],Adat[i-1-csekk][10],Adat[i+1+csekkb][0],Adat[i+1+csekkb][10]);
										   //Adat[i][8]=h(Adat[i-1-csekk][8],Adat[i+1+csekkb][8]);    
										   															}
										   }

					
	
					
		}

	
// line�ris extrapol�ci�, ide csinald majd meg ha kell megint!
//(extra hiba: meredeks�g hib�j�val sz�mitott �rt�k 56700t�l: ah*(JD-56700) )
//if( Adat[i][0]<56784.000000 )     // meddig inter !!!				

/*		line�ris extrapol�ci� elemei:		
a=0.037349 +- 0.000829 (2.22%)
b=15.1459  +- 0.12     (0.08%)
-56700-el eltolva
eltol�s n�lk�l:
b=-2102.5424
*/



// f�jlba �rat�s
if(interpolal==0) fprintf(f,"\nNincs Interpolalas!");
if(mod==0) fprintf(f,"\nInterpolalas utan:\nJD             g mag       g err       r mag       r err       i mag       i err       z mag       z err       u mag      u err\n");				
if(mod==1) fprintf(f,"\nInterpolalas utan:\nJD             V mag       V err       R mag       R err       I mag       I err       B mag       B err       U mag      U err\n");				

for(i=0;i<szum;i++){
					if(  tiltas(Adat[i][0])  )
					fprintf(f,"%f   %f   %f   %f   %f   %f   %f   %f   %f   %f   %f\n",Adat[i][0],Adat[i][1],Adat[i][2],Adat[i][3],Adat[i][4],Adat[i][5],Adat[i][6],Adat[i][7],Adat[i][8],Adat[i][9],Adat[i][10]);
										
					
					}
					
					

// fluxusok
float flux[szum][11];
for(i=0;i<szum;i++) for(j=0;j<11;j++) flux[i][j]=0; // nullazza



					
            



// F [w/m*m] = 10^( -0.4*(m+19.26) )
// 1 w/m*m = 10000 erg/s*cm*cm



// fluxus trafo (griz:AB magni --> erg/cm/cm/s/A), hiba: hibaterjedessel
// a *c/l/l (fenysebesseg/hullahossz^2) szorzo az atvaltas: erg/cm/cm/s/Hz -> erg/cm/cm/s/A
if(mod==0){ // szekcio sdss
csekk=0;
for(i=0;i<szum;i++){
										
					if(  tiltas(Adat[i][0])  ){
					
					flux[i-csekk][0]=Adat[i][0];
					
					
					if(Adat[i][1]!=-1.0){
					Adat[i][1]=Adat[i][1]-nedg;
					flux[i-csekk][1]= pow(10.0,-0.4*(Adat[i][1]+48.60))*300.0/( (lsg*pow(10,-8))*(lsg*pow(10,-8)) );
					flux[i-csekk][2]= pow(10.0,-0.4*(Adat[i][1]+48.60))*300.0/( (lsg*pow(10,-8))*(lsg*pow(10,-8)) ) * -0.4*log(10)*Adat[i][2];	 
					}
					
					
					if(Adat[i][3]!=-1.0){
					Adat[i][3]=Adat[i][3]-nedr;
					flux[i-csekk][3]= pow(10.0,-0.4*(Adat[i][3]+48.60))*300.0/( (lsr*pow(10,-8))*(lsr*pow(10,-8)) );	 
					flux[i-csekk][4]= pow(10.0,-0.4*(Adat[i][3]+48.60))*300.0/( (lsr*pow(10,-8))*(lsr*pow(10,-8)) ) * -0.4*log(10)*Adat[i][4];
					}
					
					
					if(Adat[i][5]!=-1.0){
					Adat[i][5]=Adat[i][5]-nedi;
					flux[i-csekk][5]= pow(10.0,-0.4*(Adat[i][5]+48.60))*300.0/( (lsi*pow(10,-8))*(lsi*pow(10,-8)) );	 
	    			flux[i-csekk][6]= pow(10.0,-0.4*(Adat[i][5]+48.60))*300.0/( (lsi*pow(10,-8))*(lsi*pow(10,-8)) ) * -0.4*log(10)*Adat[i][6];
					}
					
					
					if(Adat[i][7]!=-1.0){
					Adat[i][7]=Adat[i][7]-nedz+0.02;
					flux[i-csekk][7]= pow(10.0,-0.4*(Adat[i][7]+48.60))*300.0/( (lsz*pow(10,-8))*(lsz*pow(10,-8)) );	 
				    flux[i-csekk][8]= pow(10.0,-0.4*(Adat[i][7]+48.60))*300.0/( (lsz*pow(10,-8))*(lsz*pow(10,-8)) ) * -0.4*log(10)*Adat[i][8];
					}
					
					if(Adat[i][9]!=-1.0){
					Adat[i][9]=Adat[i][9]-nedu;
					flux[i-csekk][9]= pow(10.0,-0.4*(Adat[i][9]+48.60))*300.0/( (lsu*pow(10,-8))*(lsu*pow(10,-8)) );	 
				    flux[i-csekk][10]= pow(10.0,-0.4*(Adat[i][9]+48.60))*300.0/( (lsu*pow(10,-8))*(lsu*pow(10,-8)) ) * -0.4*log(10)*Adat[i][10];
					}
					
										
					}
					else csekk++;
             
			 }
			 
szumk=szum-csekk;
} // szekcio veg


// fluxus trafo (Johnson:Vega magni --> erg/cm/cm/s/A), hiba: hibaterjedessel
// m=0 a flux= 	U:417.5 	B:632 	V:363.1 	R:217.7 	I:112.6 	J:31.47 	H:11.38 	K:3.961   x 1e-11 erg/cm/cm/s/A
//http://www.astronomy.ohio-state.edu/~martini/usefuldata.html & https://en.wikipedia.org/wiki/Apparent_magnitude
if(mod==1){ // szekcio Johnson
csekk=0;
for(i=0;i<szum;i++){
										
					if(  tiltas(Adat[i][0])  ){
					
					flux[i-csekk][0]=Adat[i][0];
					
					
					if(Adat[i][1]!=-1.0){
					Adat[i][1]=Adat[i][1]-nedg;
					flux[i-csekk][1]= pow(10.0,-0.4*(Adat[i][1]+21.10));	 
					flux[i-csekk][2]= pow(10.0,-0.4*(Adat[i][1]+21.10)) * 0.4*log(10)*Adat[i][2];
					}
					
					
					if(Adat[i][3]!=-1.0){
					Adat[i][3]=Adat[i][3]-nedr;
					flux[i-csekk][3]= pow(10.0,-0.4*(Adat[i][3]+21.65));	
					flux[i-csekk][4]= pow(10.0,-0.4*(Adat[i][3]+21.65)) * 0.4*log(10)*Adat[i][4];
					}
					
					
					if(Adat[i][5]!=-1.0){
					Adat[i][5]=Adat[i][5]-nedi;
					flux[i-csekk][5]= pow(10.0,-0.4*(Adat[i][5]+22.37));	 
					flux[i-csekk][6]= pow(10.0,-0.4*(Adat[i][5]+22.37)) * 0.4*log(10)*Adat[i][6];
					}
					
					
					if(Adat[i][7]!=-1.0){
					Adat[i][7]=Adat[i][7]-nedz;
					flux[i-csekk][7]= pow(10.0,-0.4*(Adat[i][7]+20.50));	 
					flux[i-csekk][8]= pow(10.0,-0.4*(Adat[i][7]+20.50)) * 0.4*log(10)*Adat[i][8];
					}
					
					
					if(Adat[i][9]!=-1.0){
					Adat[i][9]=Adat[i][9]-nedu;
					flux[i-csekk][9]= pow(10.0,-0.4*(Adat[i][9]+20.95));	 
					flux[i-csekk][10]= pow(10.0,-0.4*(Adat[i][9]+20.95)) * 0.4*log(10)*Adat[i][10];
					}
					
										
					}
					else csekk++;
             
			 }
			 
szumk=szum-csekk;
} // szekcio veg

// ahol nincs adat ott 0 a fluxus es a hibaja


// f�jlba �rat�s
if(mod==0) fprintf(f,"\nFluxusok: JD g r i z u es hibaik [erg/cm/cm/s/A]\n");				
if(mod==1) fprintf(f,"\nFluxusok: JD V R I B U es hibaik [erg/cm/cm/s/A]\n");	

for(i=0;i<szumk;i++){
					fprintf(f,"%4.3f   %4.3e   %4.3e   %4.3e   %4.3e   %4.3e   %4.3e   %4.3e   %4.3e   %4.3e   %4.3e\n",flux[i][0],flux[i][1],flux[i][2],flux[i][3],flux[i][4],flux[i][5],flux[i][6],flux[i][7],flux[i][8],flux[i][9],flux[i][10]);
										
					
					}
					

//bolomnak atadott fluxusok
adatflux fluxusok[szumk][25];
adatflux cseref;
			

// adatflux tipusba taroljuk tovabb, + JD-ben az idot
// JD es Tn is itt kezdodik
//lsx formatum van, de lsx=ljx, igy van megadva
n=0;
for(i=0;i<szumk;i++){
					 JD[i]=flux[i][0];
					 
					 if(flux[i][1]!=0){ 
					 fluxusok[i][Tn[i]].l=lsg;
					 fluxusok[i][Tn[i]].flux=flux[i][1];
					 fluxusok[i][Tn[i]].err=flux[i][2];
					 Tn[i]++;}
					 
					 if(flux[i][3]!=0){ 
					 fluxusok[i][Tn[i]].l=lsr;
					 fluxusok[i][Tn[i]].flux=flux[i][3];
					 fluxusok[i][Tn[i]].err=flux[i][4];
					 Tn[i]++;}
					 
					 if(flux[i][5]!=0){ 
					 fluxusok[i][Tn[i]].l=lsi;
					 fluxusok[i][Tn[i]].flux=flux[i][5];
					 fluxusok[i][Tn[i]].err=flux[i][6];
					 Tn[i]++;}
					 
					 if(flux[i][7]!=0){ 
					 fluxusok[i][Tn[i]].l=lsz;
					 fluxusok[i][Tn[i]].flux=flux[i][7];
					 fluxusok[i][Tn[i]].err=flux[i][8];
					 Tn[i]++;}
					 
					 if(flux[i][9]!=0){ 
					 fluxusok[i][Tn[i]].l=lsu;
					 fluxusok[i][Tn[i]].flux=flux[i][9];
					 fluxusok[i][Tn[i]].err=flux[i][10];
					 Tn[i]++;}
					 
					 }
					
					

// Swift+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
FILE *fsw;
fsw=fopen("swiftbe.txt","rb");
if(fsw==NULL) printf("\nNincs Swift file!\n\n");

if(fsw!=NULL){
   
   
int swszam=0;

   //swift adat tomb
adatswift swbe[100];    // beolvasasi tomb, MAG!!!
adatswift swbeerr[100]; // hibat beolvasva, mag
adatswift sw[100];      // konvertalo, FLUXUS!!!
adatswift swerr[100];  //e felettinek a hibaja, fluxus
adatswift sws[100];  // fluxus
adatswift swse[100]; // fluxus hiba
adatswift swcsere; //cserek
adatswift swcsereb;
adatswift ZP;   // swift zeruspontok
adatswift hh;   // swift hullamhosszak
adatswift null; // null "vektor"
adatswift nullm; // -1 "vektor"
adatswift Sned; // extinkcio

   nullm.JD=0;
   nullm.w2=-1.0;
   nullm.m2=-1.0;
   nullm.w1=-1.0;
   nullm.u =-1.0;
   nullm.b =-1.0;
   nullm.v =-1.0;
   null.JD=0;
   null.w2=0;
   null.m2=0;
   null.w1=0;
   null.u =0;
   null.b =0;
   null.v =0;

for(i=0;i<100;i++){
	swbe[i]=nullm;
	swbeerr[i]=null;
	sw[i]=nullm;
	swerr[i]=null;
	sws[i]=null;
	swse[i]=null;
}
      
   
   
   //zeruspontok (2. az extinkcio, NED)
   ZP.JD=0;
   ZP.w2=20.66;
   ZP.m2=20.85;
   ZP.w1=21.01;
   ZP.u =21.13;
   ZP.b =20.47;
   ZP.v =21.06;
   
   //zeruspontok (A)
   hh.JD=0;
   hh.w2=2030.0;
   hh.m2=2231.0;
   hh.w1=2634.0;
   hh.u =3465.0;
   hh.b =4392.0;
   hh.v =5468.0;
   
   //extinkcio
   Sned.JD=0;
   Sned.w2=7.63*EBV;
   Sned.m2=8.37*EBV;
   Sned.w1=6.18*EBV;
   Sned.u =5.00*EBV;
   Sned.b =4.16*EBV;
   Sned.v =3.16*EBV;  
   
   ZP=ZP-Sned;
   
   //swift adat beolvasas
   printf("Beolvasott Swift adatok: (v hiba nelkul)\n");
   i=0;
   while (!feof(fsw)){	  
   		 				fscanf(fsw,"%f %f %f %f %f %f %f %f %f %f %f %f %f\n",&swbe[i].JD,&swbe[i].w2,&swbeerr[i].w2,&swbe[i].m2,&swbeerr[i].m2,&swbe[i].w1,&swbeerr[i].w1,&swbe[i].u,&swbeerr[i].u,&swbe[i].b,&swbeerr[i].b,&swbe[i].v,&swbeerr[i].v);  
                        //printf("%f %f %f %f %f %f %f %f %f %f %f %f %f\n",swbe[i].JD,swbe[i].w2,swbeerr[i].w2,swbe[i].m2,swbeerr[i].m2,swbe[i].w1,swbeerr[i].w1,swbe[i].u,swbeerr[i].u,swbe[i].b,swbeerr[i].b,swbe[i].v,swbeerr[i].v);  
                        cout << swbe[i].JD << " " << swbe[i].w2 << " " << swbeerr[i].w2 << " " << swbe[i].m2 << " " << swbeerr[i].m2 << " " << swbe[i].w1 << " " << swbeerr[i].w1 << " " << swbe[i].u << " " << swbeerr[i].u << " " << swbe[i].b  << " " << swbeerr[i].b << " " << swbe[i].v << " "  << "\n";
                        // << swbeerr[i].v
                        
						swbeerr[i].JD=swbe[i].JD; swszam++; i++; 
						}
                              
   //swift-re ugyan az mint az alapra
   
   printf("\nsw szam=%d\n\n",swszam);
                         
   fclose(fsw);
   
   
   
   
   
   //JD-hez hozza ad egy szamot
   for(i=0;i<swszam;i++) swbe[i].JD=datenull+swbe[i].JD;
   
   
   // 0 se szamit jonak!!!
   for(i=0;i<swszam;i++){
   		 if(swbe[i].w2==0) swbe[i].w2=-1;
   		 if(swbe[i].m2==0) swbe[i].m2=-1;
   		 if(swbe[i].w1==0) swbe[i].w1=-1;
   		 if(swbe[i].u ==0) swbe[i].u =-1;
   		 if(swbe[i].b ==0) swbe[i].b =-1;
   		 if(swbe[i].v ==0) swbe[i].v =-1;
   		 }


   // sorba rendezi a JD-t a swiftre
   for(i=0;i<swszam;i++){
					 
					 for(j=0;j<swszam-1;j++)					  
                    	if(swbe[j].JD>swbe[j+1].JD){ swcsere=swbe[j]; swbe[j]=swbe[j+1]; swbe[j+1]=swcsere; 
						swcsereb=swbeerr[j]; swbeerr[j]=swbeerr[j+1]; swbeerr[j+1]=swcsereb; }
					
					}



																					
// interpol(float x, float xm, float ym, float xp, float yp)		  
//swift interpolacio azonos JD-re															
for(j=0;j<szumk;j++){
   sw[j].JD=swerr[j].JD=JD[j];
   if(swbe[swszam-1].JD>=JD[j])
                    for(i=0;i<swszam-1;i++){

	
	                //w2
					csekk=0; csekkb=0;
					if(swbe[i].JD<=JD[j] && swbe[i+1].JD>JD[j]){  
                                           while(swbe[i-csekk].w2==-1.0 && i-csekk>0) csekk++;
					                       while(swbe[i+1+csekkb].w2==-1.0 && i+1+csekkb<swszam-1) csekkb++;
					                       //printf("%d %d\n",csekk,csekkb);
					                       
					                       if( swbe[i-csekk].w2!=-1.0 && swbe[i+1+csekkb].w2!=-1.0 ){
										   interpolszol(JD[j],swbe[i-csekk].JD,swbe[i-csekk].w2,swbe[i+1+csekkb].JD,swbe[i+1+csekkb].w2,"w2");
					                       sw[j].w2=interpol(JD[j],swbe[i-csekk].JD,swbe[i-csekk].w2,swbe[i+1+csekkb].JD,swbe[i+1+csekkb].w2);
					                       swerr[j].w2=interpolhib(JD[j],swbe[i-csekk].JD,swbeerr[i-csekk].w2,swbe[i+1+csekkb].JD,swbeerr[i+1+csekkb].w2);
										   //swerr[j].w2=h(swbeerr[i-csekk].w2,swbeerr[i+1+csekkb].w2); 	
										   																}   
										   }

	                //m2
					csekk=0; csekkb=0;
					if(swbe[i].JD<=JD[j] && swbe[i+1].JD>JD[j]){  
                                           while(swbe[i-csekk].m2==-1.0 && i-csekk>0) csekk++;
					                       while(swbe[i+1+csekkb].m2==-1.0 && i+1+csekkb<swszam-1) csekkb++;
					                       
					                       if( swbe[i-csekk].m2!=-1.0 && swbe[i+1+csekkb].m2!=-1.0 ){
										   interpolszol(JD[j],swbe[i-csekk].JD,swbe[i-csekk].m2,swbe[i+1+csekkb].JD,swbe[i+1+csekkb].m2,"m2");
										   sw[j].m2=interpol(JD[j],swbe[i-csekk].JD,swbe[i-csekk].m2,swbe[i+1+csekkb].JD,swbe[i+1+csekkb].m2);
										   swerr[j].m2=interpolhib(JD[j],swbe[i-csekk].JD,swbeerr[i-csekk].m2,swbe[i+1+csekkb].JD,swbeerr[i+1+csekkb].m2);					                       
					                       //swerr[j].m2=h(swbeerr[i-csekk].m2,swbeerr[i+1+csekkb].m2); 	
										   																}
										   }
										   
					                    
	                //w1
					csekk=0; csekkb=0;
					if(swbe[i].JD<=JD[j] && swbe[i+1].JD>JD[j]){  
                                           while(swbe[i-csekk].w1==-1.0 && i-csekk>0) csekk++;
					                       while(swbe[i+1+csekkb].w1==-1.0 && i+1+csekkb<swszam-1) csekkb++;
					                       
					                       if( swbe[i-csekk].w1!=-1.0 && swbe[i+1+csekkb].w1!=-1.0 ){
 	   									   interpolszol(JD[j],swbe[i-csekk].JD,swbe[i-csekk].w1,swbe[i+1+csekkb].JD,swbe[i+1+csekkb].w1,"w1");
										   sw[j].w1=interpol(JD[j],swbe[i-csekk].JD,swbe[i-csekk].w1,swbe[i+1+csekkb].JD,swbe[i+1+csekkb].w1);
										   swerr[j].w1=interpolhib(JD[j],swbe[i-csekk].JD,swbeerr[i-csekk].w1,swbe[i+1+csekkb].JD,swbeerr[i+1+csekkb].w1);					                       
					                       //swerr[j].w1=h(swbeerr[i-csekk].w1,swbeerr[i+1+csekkb].w1); 	
										   																}
										   }
										   
					                    
	                //u
					csekk=0; csekkb=0;
					if(swbe[i].JD<=JD[j] && swbe[i+1].JD>JD[j]){  
                                           while(swbe[i-csekk].u==-1.0 && i-csekk>0) csekk++;
					                       while(swbe[i+1+csekkb].u==-1.0 && i+1+csekkb<swszam-1) csekkb++;
					                       
					                       if( swbe[i-csekk].u!=-1.0 && swbe[i+1+csekkb].u!=-1.0 ){
 	   									   interpolszol(JD[j],swbe[i-csekk].JD,swbe[i-csekk].u ,swbe[i+1+csekkb].JD,swbe[i+1+csekkb].u ,"S u");
										   sw[j].u =interpol(JD[j],swbe[i-csekk].JD,swbe[i-csekk].u ,swbe[i+1+csekkb].JD,swbe[i+1+csekkb].u );
										   swerr[j].u =interpolhib(JD[j],swbe[i-csekk].JD,swbeerr[i-csekk].u ,swbe[i+1+csekkb].JD,swbeerr[i+1+csekkb].u );					                       
										   //swerr[j].u =h(swbeerr[i-csekk].u,swbeerr[i+1+csekkb].u);	
										   			  												}    
										   }

	                //b
					csekk=0; csekkb=0;
					if(swbe[i].JD<=JD[j] && swbe[i+1].JD>JD[j]){  
                                           while(swbe[i-csekk].b==-1.0 && i-csekk>0) csekk++;
					                       while(swbe[i+1+csekkb].b==-1.0 && i+1+csekkb<swszam-1) csekkb++;
					                       
					                       if( swbe[i-csekk].b!=-1.0 && swbe[i+1+csekkb].b!=-1.0 ){
 	   									   interpolszol(JD[j],swbe[i-csekk].JD,swbe[i-csekk].b ,swbe[i+1+csekkb].JD,swbe[i+1+csekkb].b ,"S b");	
										   sw[j].b =interpol(JD[j],swbe[i-csekk].JD,swbe[i-csekk].b ,swbe[i+1+csekkb].JD,swbe[i+1+csekkb].b );	
										   swerr[j].b =interpolhib(JD[j],swbe[i-csekk].JD,swbeerr[i-csekk].b ,swbe[i+1+csekkb].JD,swbeerr[i+1+csekkb].b );				                       
										   //swerr[j].b =h(swbeerr[i-csekk].b,swbeerr[i+1+csekkb].b);	
										   			  												}    
										   }
					                    
	                //v
					csekk=0; csekkb=0;
					if(swbe[i].JD<=JD[j] && swbe[i+1].JD>JD[j]){  
                                           while(swbe[i-csekk].v==-1.0 && i-csekk>0) csekk++;
					                       while(swbe[i+1+csekkb].v==-1.0 && i+1+csekkb<swszam-1) csekkb++;
					                       
					                       if( swbe[i-csekk].v!=-1.0 && swbe[i+1+csekkb].v!=-1.0 ){
 	   									   interpolszol(JD[j],swbe[i-csekk].JD,swbe[i-csekk].v ,swbe[i+1+csekkb].JD,swbe[i+1+csekkb].v ,"S v");	
										   sw[j].v =interpol(JD[j],swbe[i-csekk].JD,swbe[i-csekk].v ,swbe[i+1+csekkb].JD,swbe[i+1+csekkb].v );	
										   swerr[j].v =interpolhib(JD[j],swbe[i-csekk].JD,swbeerr[i-csekk].v ,swbe[i+1+csekkb].JD,swbeerr[i+1+csekkb].v );				                       
										   //swerr[j].v =h(swbeerr[i-csekk].v,swbeerr[i+1+csekkb].v);	
										   			  												}    
										   }
						
						
						
										   
					
					//extra -1 nap, elore
					if(swbe[0].JD- 1 <=JD[j] && swbe[0].JD>JD[j]){  
					                       
					                       if( swbe[0].w2!=-1.0 && swbe[1].w2!=-1.0 ){
					                       sw[j].w2=interpol(JD[j],swbe[0].JD,swbe[0].w2,swbe[1].JD,swbe[1].w2);
					                       swerr[j].w2=interpolhib(JD[j],swbe[0].JD,swbeerr[0].w2,swbe[1].JD,swbeerr[1].w2);
										   //swerr[j].w2=h(swbeerr[0].w2,swbeerr[1].w2); 	
										   												}   
										     
					                       
					                       if( swbe[0].m2!=-1.0 && swbe[1].m2!=-1.0 ){
					                       sw[j].m2=interpol(JD[j],swbe[0].JD,swbe[0].m2,swbe[1].JD,swbe[1].m2);
					                       swerr[j].m2=interpolhib(JD[j],swbe[0].JD,swbeerr[0].m2,swbe[1].JD,swbeerr[1].m2);
										   //swerr[j].m2=h(swbeerr[0].m2,swbeerr[1].m2); 	
										   												}   
										   
					                       
					                       if( swbe[0].w1!=-1.0 && swbe[1].w1!=-1.0 ){
					                       sw[j].w1=interpol(JD[j],swbe[0].JD,swbe[0].w1,swbe[1].JD,swbe[1].w1);
					                       swerr[j].w1=interpolhib(JD[j],swbe[0].JD,swbeerr[0].w1,swbe[1].JD,swbeerr[1].w1);
										   //swerr[j].w1=h(swbeerr[0].w1,swbeerr[1].w1); 	
										   												}   
										    
					                       
					                       if( swbe[0].u!=-1.0 && swbe[1].u!=-1.0 ){
					                       sw[j].u=interpol(JD[j],swbe[0].JD,swbe[0].u,swbe[1].JD,swbe[1].u);
					                       swerr[j].u=interpolhib(JD[j],swbe[0].JD,swbeerr[0].u,swbe[1].JD,swbeerr[1].u);
										   //swerr[j].u=h(swbeerr[0].u,swbeerr[1].u); 	
										   												}   
										   
					                       
					                       if( swbe[0].b!=-1.0 && swbe[1].b!=-1.0 ){
					                       sw[j].b=interpol(JD[j],swbe[0].JD,swbe[0].b,swbe[1].JD,swbe[1].b);
					                       swerr[j].b=interpolhib(JD[j],swbe[0].JD,swbeerr[0].b,swbe[1].JD,swbeerr[1].b);
										   //swerr[j].b=h(swbeerr[0].b,swbeerr[1].b); 	
										   												}   
										   
					                       
					                       if( swbe[0].v!=-1.0 && swbe[1].v!=-1.0 ){
					                       sw[j].v=interpol(JD[j],swbe[0].JD,swbe[0].v,swbe[1].JD,swbe[1].v);
					                       swerr[j].v=interpolhib(JD[j],swbe[0].JD,swbeerr[0].v,swbe[1].JD,swbeerr[1].v);
										   //swerr[j].v=h(swbeerr[0].v,swbeerr[1].v); 	
										   												}   
										   }
					
										   
		            //extra 2 nap
					if(swbe[swszam-1].JD<=JD[j] && swbe[swszam-1].JD+ 2 >JD[j]){  
					                       
					                       if( swbe[swszam-1].w2!=-1.0 && swbe[swszam-2].w2!=-1.0 ){
					                       sw[j].w2=interpol(JD[j],swbe[swszam-2].JD,swbe[swszam-2].w2,swbe[swszam-1].JD,swbe[swszam-1].w2);
					                       swerr[j].w2=interpolhib(JD[j],swbe[swszam-2].JD,swbeerr[swszam-2].w2,swbe[swszam-1].JD,swbeerr[swszam-1].w2);
										   //swerr[j].w2=h(swbeerr[swszam-1].w2,swbeerr[swszam-2].w2); 	
										   																}   
										     
					                       
					                       if( swbe[swszam-1].m2!=-1.0 && swbe[swszam-2].m2!=-1.0 ){
					                       sw[j].m2=interpol(JD[j],swbe[swszam-2].JD,swbe[swszam-2].m2,swbe[swszam-1].JD,swbe[swszam-1].m2);
					                       swerr[j].m2=interpolhib(JD[j],swbe[swszam-2].JD,swbeerr[swszam-2].m2,swbe[swszam-1].JD,swbeerr[swszam-1].m2);
										   //swerr[j].m2=h(swbeerr[swszam-1].m2,swbeerr[swszam-2].m2); 	
										   																}   
										   
					                       
					                       if( swbe[swszam-1].w1!=-1.0 && swbe[swszam-2].w1!=-1.0 ){
					                       sw[j].w1=interpol(JD[j],swbe[swszam-2].JD,swbe[swszam-2].w1,swbe[swszam-1].JD,swbe[swszam-1].w1);
					                       swerr[j].w1=interpolhib(JD[j],swbe[swszam-2].JD,swbeerr[swszam-2].w1,swbe[swszam-1].JD,swbeerr[swszam-1].w1);
										   //swerr[j].w1=h(swbeerr[swszam-1].w1,swbeerr[swszam-2].w1); 	
										   																}   
										    
					                       
					                       if( swbe[swszam-1].u!=-1.0 && swbe[swszam-2].u!=-1.0 ){
					                       sw[j].u=interpol(JD[j],swbe[swszam-2].JD,swbe[swszam-2].u,swbe[swszam-1].JD,swbe[swszam-1].u);
					                       swerr[j].u=interpolhib(JD[j],swbe[swszam-2].JD,swbeerr[swszam-2].u,swbe[swszam-1].JD,swbeerr[swszam-1].u);
										   //swerr[j].u=h(swbeerr[swszam-1].u,swbeerr[swszam-2].u); 	
										   															}   
										   
					                       
					                       if( swbe[swszam-1].b!=-1.0 && swbe[swszam-2].b!=-1.0 ){
					                       sw[j].b=interpol(JD[j],swbe[swszam-2].JD,swbe[swszam-2].b,swbe[swszam-1].JD,swbe[swszam-1].b);
					                       swerr[j].b=interpolhib(JD[j],swbe[swszam-2].JD,swbeerr[swszam-2].b,swbe[swszam-1].JD,swbeerr[swszam-1].b);
										   //swerr[j].b=h(swbeerr[swszam-1].b,swbeerr[swszam-2].b); 	
										   															}   
										   
					                       
					                       if( swbe[swszam-1].v!=-1.0 && swbe[swszam-2].v!=-1.0 ){
					                       sw[j].v=interpol(JD[j],swbe[swszam-2].JD,swbe[swszam-2].v,swbe[swszam-1].JD,swbe[swszam-1].v);
					                       swerr[j].v=interpolhib(JD[j],swbe[swszam-2].JD,swbeerr[swszam-2].v,swbe[swszam-1].JD,swbeerr[swszam-1].v);
										   //swerr[j].v=h(swbeerr[swszam-1].v,swbeerr[swszam-2].v); 	
										   															}   
										   
										   }
		            
										   

                     }
}   

   
swszam=szumk;

   // f�jlba �rat�s
   //printf("\nswift JD:\n");
   fprintf(f,"\nSwift Interpolalas utan:\nJD       w2 mag    w2 err    m2 mag    m2 err    w1 mag    w1 err    u mag    u err    b mag    b err    v mag    v err\n");				
   for(i=0;i<swszam;i++){
					fprintf(f,"%f %f %f %f %f %f %f %f %f %f %f %f %f\n",sw[i].JD,sw[i].w2,swerr[i].w2,sw[i].m2,swerr[i].m2,sw[i].w1,swerr[i].w1,sw[i].u,swerr[i].u,sw[i].b,swerr[i].b,sw[i].v,swerr[i].v);
					//printf("%f\n",sw[i].JD);
										
					}
   printf("\n");


   // fluxust szamol [erg/s/cm2/A] (2. a hiba)
   // -1 es erteket nullazza
   for(i=0;i<swszam;i++){
   sws[i] =texp(-0.4*sw[i])*texp(-0.4*ZP);
   swse[i]=texp(-0.4*sw[i])*texp(-0.4*ZP) * 0.4*log(10)*swerr[i];
   }
   
      // f�jlba �rat�s, fluxus
   fprintf(f,"\nSwift fluxus: [erg/cm/cm/s/A]\nJD       w2 mag    w2 err    m2 mag    m2 err    w1 mag    w1 err    u mag    u err    b mag    b err    v mag    v err   \n");				
   for(i=0;i<swszam;i++){
					fprintf(f,"%4.1f  %4.3e %4.3e %4.3e %4.3e %4.3e %4.3e %4.3e %4.3e %4.3e %4.3e %4.3e %4.3e\n",sws[i].JD,sws[i].w2,swse[i].w2,sws[i].m2,swse[i].m2,sws[i].w1,swse[i].w1,sws[i].u,swse[i].u,sws[i].b,swse[i].b,sws[i].v,swse[i].v);
										
					}
					
					
					
					
				// beleiras az adatflux tipusba
				for(i=0;i<szumk;i++){
												 
					if(sws[i].w2!=0){ 
					fluxusok[i][Tn[i]].l=hh.w2;
					fluxusok[i][Tn[i]].flux=sws[i].w2;
					fluxusok[i][Tn[i]].err=swse[i].w2;
					Tn[i]++;}
					 
					if(sws[i].m2!=0){  
					fluxusok[i][Tn[i]].l=hh.m2;
					fluxusok[i][Tn[i]].flux=sws[i].m2;
					fluxusok[i][Tn[i]].err=swse[i].m2;
					Tn[i]++;}
					
					if(sws[i].w1!=0){  
					fluxusok[i][Tn[i]].l=hh.w1;
					fluxusok[i][Tn[i]].flux=sws[i].w1;
					fluxusok[i][Tn[i]].err=swse[i].w1;
					Tn[i]++;}
					
					if(sws[i].u!=0){  
					fluxusok[i][Tn[i]].l=hh.u;
					fluxusok[i][Tn[i]].flux=sws[i].u;
					fluxusok[i][Tn[i]].err=swse[i].u;
					Tn[i]++;}
					
					if(sws[i].b!=0){  
					fluxusok[i][Tn[i]].l=hh.b;
					fluxusok[i][Tn[i]].flux=sws[i].b;
					fluxusok[i][Tn[i]].err=swse[i].b;
					Tn[i]++;}
					
					if(sws[i].v!=0){  
					fluxusok[i][Tn[i]].l=hh.v;
					fluxusok[i][Tn[i]].flux=sws[i].v;
					fluxusok[i][Tn[i]].err=swse[i].v;
					Tn[i]++;}
	
					}
   
}
// Swift+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// JHK ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
FILE *fjhk;
fjhk=fopen("JHK-gorbe.txt","rb");
if(fjhk==NULL) printf("\nNincs JHK file!\n\n");

if(fjhk!=NULL){
			   
int szumj;  // JHK szam
float Adatj[m][7];	// JHK adattomb
float Adatjk[m][7]; // JHK adattomb 2
float fluxjhk[m][7]; // JHK fluxusok
//nullazza
for(i=0;i<m;i++){ Adatjk[i][1]=-1; Adatjk[i][3]=-1; Adatjk[i][5]=-1;
				  Adatjk[i][2]=0; Adatjk[i][4]=0; Adatjk[i][6]=0; Adatjk[i][0]=0;
				  }
for(i=0;i<m;i++) for(k=0;k<7;k++) fluxjhk[i][k]=0;
				  


i=0; 
szumj=0;

while (!feof(fjhk)){  
			   //fscanf(fall,"%f   %f   %f   %f   %f   %f   %f \n",&Adatj[i][0],&Adatj[i][1],&Adatj[i][2],&Adatj[i][3],&Adatj[i][4],&Adatj[i][5],&Adatj[i][6]);
			   
			   fscanf(fjhk,"%f/%f/%f   %f   %f   %f   %f   %f    %f    %f  %f \n",&csere,&csere,&csere,&Adatj[i][0],&Adatj[i][1],&Adatj[i][2],&Adatj[i][3],&Adatj[i][4],&Adatj[i][5],&Adatj[i][6],&csere);
			   
			   szumj++; i++;}
	

for(i=0;i<szumj;i++){
					if(Adatj[i][1]==0) Adatj[i][1]=-1; 
					if(Adatj[i][3]==0) Adatj[i][3]=-1;
					if(Adatj[i][5]==0) Adatj[i][5]=-1;
					}

printf("JHK szam:%d\n\n",szumj);


//rendezes
//sorba rendezi a JD-t			 
for(i=0;i<szumj;i++){
					 for(j=0;j<szumj-1;j++)					  
                    	if(Adatj[j][0]>Adatj[j+1][0]) for(k=0;k<7;k++){ cserea[k]=Adatj[j][k]; Adatj[j][k]=Adatj[j+1][k]; Adatj[j+1][k]=cserea[k]; }
					
					 }


// azonos JD-juket beteszi, interpolalas nelkul
if(interpolal==0)
for(i=0;i<szumk;i++){ 
					  Adatjk[i][0]=JD[i];
					  for(j=0;j<szumj;j++) if( int(Adatj[j][0])==int(JD[i]) ) for(k=0;k<7;k++) Adatjk[i][k]=Adatj[j][k];
					  }



																	
// interpol(float x, float xm, float ym, float xp, float yp)		  
//JHK interpolacio azonos JD-re	
if(interpolal==1)														
for(j=0;j<szumk;j++){
   Adatjk[j][0]=JD[j];
   if(Adatj[szumj-1][0]>=JD[j] && !(53642.5<JD[j] && 53677.40>JD[j]) )
                    for(i=0;i<szumj-1;i++){

	                //J
					csekk=0; csekkb=0;
					if(Adatj[i][0]<=JD[j] && Adatj[i+1][0]>JD[j]){  
                                           while(Adatj[i-csekk][1]==-1.0 && i-csekk>0) csekk++;
					                       while(Adatj[i+1+csekkb][1]==-1.0 && i+1+csekkb<szumj-1) csekkb++;
					                       
					                       if( Adatj[i-csekk][1]!=-1.0 && Adatj[i+1+csekkb][1]!=-1.0 ){
										   interpolszol(JD[j],Adatj[i-csekk][0],Adatj[i-csekk][1] ,Adatj[i+1+csekkb][0],Adatj[i+1+csekkb][1] ,"J");
										   Adatjk[j][1] =interpol(JD[j],Adatj[i-csekk][0],Adatj[i-csekk][1] ,Adatj[i+1+csekkb][0],Adatj[i+1+csekkb][1] );
										   Adatjk[j][2] =interpolhib(JD[j],Adatj[i-csekk][0],Adatj[i-csekk][2] ,Adatj[i+1+csekkb][0],Adatj[i+1+csekkb][2] );					                       
										   //Adatjk[j][2] =h(Adatj[i-csekk][2],Adatj[i+1+csekkb][2]);	
										   															}    
										   }

	                //H
					csekk=0; csekkb=0;
					if(Adatj[i][0]<=JD[j] && Adatj[i+1][0]>JD[j]){  
                                           while(Adatj[i-csekk][3]==-1.0 && i-csekk>0) csekk++;
					                       while(Adatj[i+1+csekkb][3]==-1.0 && i+1+csekkb<szumj-1) csekkb++;
					                       
					                       if( Adatj[i-csekk][3]!=-1.0 && Adatj[i+1+csekkb][3]!=-1.0 ){
										   interpolszol(JD[j],Adatj[i-csekk][0],Adatj[i-csekk][3] ,Adatj[i+1+csekkb][0],Adatj[i+1+csekkb][3] ,"H");
										   Adatjk[j][3] =interpol(JD[j],Adatj[i-csekk][0],Adatj[i-csekk][3] ,Adatj[i+1+csekkb][0],Adatj[i+1+csekkb][3] );
										   Adatjk[j][4] =interpolhib(JD[j],Adatj[i-csekk][0],Adatj[i-csekk][4] ,Adatj[i+1+csekkb][0],Adatj[i+1+csekkb][4] );					                       
										   //Adatjk[j][4] =h(Adatj[i-csekk][4],Adatj[i+1+csekkb][4]);	
										   															}    
										   }
					                    
	                //K
					csekk=0; csekkb=0;
					if(Adatj[i][0]<=JD[j] && Adatj[i+1][0]>JD[j]){  
                                           while(Adatj[i-csekk][5]==-1.0 && i-csekk>0) csekk++;
					                       while(Adatj[i+1+csekkb][5]==-1.0 && i+1+csekkb<szumj-1) csekkb++;
					                       
					                       if( Adatj[i-csekk][5]!=-1.0 && Adatj[i+1+csekkb][5]!=-1.0 ){
										   interpolszol(JD[j],Adatj[i-csekk][0],Adatj[i-csekk][5] ,Adatj[i+1+csekkb][0],Adatj[i+1+csekkb][5] ,"K");
										   Adatjk[j][5] =interpol(JD[j],Adatj[i-csekk][0],Adatj[i-csekk][5] ,Adatj[i+1+csekkb][0],Adatj[i+1+csekkb][5] );					                       
										   Adatjk[j][6] =interpolhib(JD[j],Adatj[i-csekk][0],Adatj[i-csekk][6] ,Adatj[i+1+csekkb][0],Adatj[i+1+csekkb][6] );
										   //Adatjk[j][6] =h(Adatj[i-csekk][6],Adatj[i+1+csekkb][6]);	
										   															}    
										   }
										   
		   }
}




fprintf(f,"\nInterp.:JD       J                  H                    K\n");
for(i=0;i<szumk;i++) fprintf(f,"%f  %f  %f  %f  %f  %f  %f\n",Adatjk[i][0],Adatjk[i][1],Adatjk[i][2],Adatjk[i][3],Adatjk[i][4],Adatjk[i][5],Adatjk[i][6]);



// J:31.47 	 H:11.38 	K:3.961   x 1e-11 erg/cm/cm/s/A
for(i=0;i<szumk;i++){

					fluxjhk[i][0]=Adatjk[i][0];
					
					
					if(Adatjk[i][1]!=-1.0){
					Adatjk[i][1]=Adatjk[i][1]-nedj;
					fluxjhk[i][1]= pow(10.0,-0.4*(Adatjk[i][1]+23.76));	 
					fluxjhk[i][2]= pow(10.0,-0.4*(Adatjk[i][1]+23.76)) * 0.4*log(10)*Adatjk[i][2];
					}
					
					
					if(Adatjk[i][3]!=-1.0){
					Adatjk[i][3]=Adatjk[i][3]-nedh;
					fluxjhk[i][3]= pow(10.0,-0.4*(Adatjk[i][3]+24.86));	
					fluxjhk[i][4]= pow(10.0,-0.4*(Adatjk[i][3]+24.86)) * 0.4*log(10)*Adatjk[i][4];
					}
					
					
					if(Adatjk[i][5]!=-1.0){
					Adatjk[i][5]=Adatjk[i][5]-nedk;
					fluxjhk[i][5]= pow(10.0,-0.4*(Adatjk[i][5]+26.00));	 
					fluxjhk[i][6]= pow(10.0,-0.4*(Adatjk[i][5]+26.00)) * 0.4*log(10)*Adatjk[i][6];
					}
															
             
			 }



//flux kiiras
fprintf(f,"\nFluxusok: JD  J H K es hibais [erg/cm/cm/s/A]\n");
for(i=0;i<szumk;i++){
					fprintf(f,"%4.3f   %4.3e   %4.3e   %4.3e   %4.3e   %4.3e   %4.3e \n",fluxjhk[i][0],fluxjhk[i][1],fluxjhk[i][2],fluxjhk[i][3],fluxjhk[i][4],fluxjhk[i][5],fluxjhk[i][6]);
										
					
					}
					

			

// adatflux tipusba taroljuk tovabb, + JD-ben az idot
// JD es Tn is itt kezdodik
//lsx formatum van, de lsx=ljx, igy van megadva
for(i=0;i<szumk;i++){
					 
					 if(fluxjhk[i][1]!=0){ 
					 fluxusok[i][Tn[i]].l=12600;
					 fluxusok[i][Tn[i]].flux=fluxjhk[i][1];
					 fluxusok[i][Tn[i]].err=fluxjhk[i][2];
					 Tn[i]++;}
					 
					 if(fluxjhk[i][3]!=0){ 
					 fluxusok[i][Tn[i]].l=16000;
					 fluxusok[i][Tn[i]].flux=fluxjhk[i][3];
					 fluxusok[i][Tn[i]].err=fluxjhk[i][4];
					 Tn[i]++;}
					 
					 if(fluxjhk[i][5]!=0){ 
					 fluxusok[i][Tn[i]].l=22200;
					 fluxusok[i][Tn[i]].flux=fluxjhk[i][5];
					 fluxusok[i][Tn[i]].err=fluxjhk[i][6];
					 Tn[i]++;}
					 
					 }





}
// JHK +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
					



//rendezes
//fluxusok[szumk][20];
// sorba rendezi a hullamhosszat-t
for(k=0;k<szumk;k++)
					 
            for(i=0;i<Tn[k];i++){
					 for(j=0;j<Tn[k]-1;j++)					  
                    	if(fluxusok[k][j].l>fluxusok[k][j+1].l){ cseref=fluxusok[k][j]; fluxusok[k][j]=fluxusok[k][j+1]; fluxusok[k][j+1]=cseref; }
					
					 }

printf("\nJD, letezo szurok szama, es hullamhosszaik (A):\n");
for(i=0;i<szumk;i++){
					 printf("%4.2f Jo:%d  ",JD[i],Tn[i]);
					 for(j=0;j<Tn[i];j++) cout << fluxusok[i][j].l << " ";
					 printf("\n");
					 }
printf("\n");



// fluxus integralas +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// bolometrikus f�nyes�ggek
double bolom[szumk][5];


// bolometrikus f�nyess�g elk�szit�se, integr�l�sa, PROBLEMA: ahol nincs adat, ott 0
for(i=0;i<szumk;i++){					 
					 
					bolom[i][0]=flux[i][0];
					 					 
					//if(mod==0) bolom[i][1]= bolints(flux[i][1],flux[i][3],flux[i][5],flux[i][7]);
					//if(mod==1) bolom[i][1]= bolintj(flux[i][1],flux[i][3],flux[i][5],flux[i][7]);
					if(Tn[i]>2) fprintf(Trki,"%f ",bolom[i][0]);
					bolom[i][1]= bolint(fluxusok[i],Tn[i]);
					
			        //if(mod==0) bolom[i][2]= bolhibs(flux[i][1],flux[i][3],flux[i][5],flux[i][7],flux[i][2],flux[i][4],flux[i][6],flux[i][8]);
					//if(mod==1) bolom[i][2]= bolhibj(flux[i][1],flux[i][3],flux[i][5],flux[i][7],flux[i][2],flux[i][4],flux[i][6],flux[i][8]);
					bolom[i][2]= bolhib(fluxusok[i],Tn[i]);
								        	        
			        bolom[i][3]=-2.5*log10(4*PI*tav*tav*bolom[i][1]/1000.0)+71.21;
			        			        
			        bolom[i][4]=2.5*(bolom[i][2]/bolom[i][1])/(log(10));
					 
					}
					 


// bolometrikus f�nyess�gek kiirat�sa
for(i=0;i<szumk;i++){
					 if(bolom[i][1]!=0) fprintf(bol,"%f %e %e %f %f\n",bolom[i][0],bolom[i][1],bolom[i][2],bolom[i][3],bolom[i][4]);
					 
					 }

// BC=bol-g    szin=g-r
// BC=bol-B    szin=B-I
// BC es szint is kiirja pluszba meg				 
csekk=0;
for(i=0;i<szumk;i++){
					 while( 1-tiltas(Adat[i+csekk][0]) ) csekk++;
					 //if ( tiltas(Adat[i+csekk][0]) ) ;  else csekk++;
					 if(mod==0) if(Adat[i][1]!=-1 && Adat[i][3]!=-1) fprintf(bc,"%f %f %f %f %f %f %f\n",bolom[i][0],bolom[i][3],bolom[i][4],bolom[i][3]-Adat[i+csekk][1]+5*log10(tav /3.086/pow(10,16))-5,h(bolom[i][4],Adat[i+csekk][2]),Adat[i+csekk][1]-Adat[i+csekk][3],h(Adat[i+csekk][2],Adat[i+csekk][4]));
					 if(mod==1) if(Adat[i][7]!=-1 && Adat[i][5]!=-1) fprintf(bc,"%f %f %f %f %f %f %f\n",bolom[i][0],bolom[i][3],bolom[i][4],bolom[i][3]-Adat[i+csekk][7]+5*log10(tav /3.086/pow(10,16))-5,h(bolom[i][4],Adat[i+csekk][8]),Adat[i+csekk][7]-Adat[i+csekk][5],h(Adat[i+csekk][8],Adat[i+csekk][6]));
					 
					 }


// Kimenet: MJD, fluxus [erg/s/cm2], fluxus hiba [erg/s/cm2], abszol�t bolometrikus f�nyess�g [watt, magni], hiba [-II-]

fclose(f);
fclose(bol);
fclose(bc);
fclose(Trki);

printf("\nLefutott\n");
		
getchar();
	
	
	
	
}





/*
        // fit param�terek megad�sa:
		   a=0.037349;
		   b=-2102.5424;
		   ah=0.000829;
		   
                    //g extra
					if( Adat[i][0]> 56784.000000  )     // honnant�l! ADD MEG!
					if(Adat[i][1]==-1.0){  Adat[i][1]=a*Adat[i][0]+b;
					                    Adat[i][2]=ah*(Adat[i][0]-56700); }  // eltol�s!

*/

/*
//fluxus hiba regebbi valtozata, igazabol jo ez is, de a mostani egyszerubb, es hivatalosabb

                    flux[i-csekk][2]= pow(10.0,-0.4*(Adat[i][1]-Adat[i][2]+48.60))*300.0/( (lsg*pow(10,-8))*(lsg*pow(10,-8)) )- flux[i-csekk][1];
					flux[i-csekk][4]= pow(10.0,-0.4*(Adat[i][3]-Adat[i][4]+48.60))*300.0/( (lsr*pow(10,-8))*(lsr*pow(10,-8)) )- flux[i-csekk][3];
					flux[i-csekk][6]= pow(10.0,-0.4*(Adat[i][5]-Adat[i][6]+48.60))*300.0/( (lsi*pow(10,-8))*(lsi*pow(10,-8)) )- flux[i-csekk][5];
					flux[i-csekk][8]= pow(10.0,-0.4*(Adat[i][7]-Adat[i][8]+48.60))*300.0/( (lsz*pow(10,-8))*(lsz*pow(10,-8)) )- flux[i-csekk][7];

					flux[i-csekk][2]= pow(10.0,-0.4*(Adat[i][1]-Adat[i][2]+21.10))- flux[i-csekk][1]; 
				    flux[i-csekk][4]= pow(10.0,-0.4*(Adat[i][3]-Adat[i][4]+21.65))- flux[i-csekk][3];
				    flux[i-csekk][6]= pow(10.0,-0.4*(Adat[i][5]-Adat[i][6]+22.37))- flux[i-csekk][5];
				    flux[i-csekk][8]= pow(10.0,-0.4*(Adat[i][7]-Adat[i][8]+20.50))- flux[i-csekk][7];
*/





/*	
// linearis interpolacio fuggveny nelkul	   	
Adat[i][1]=Adat[i-1-csekk][1]+ (Adat[i][0]-Adat[i-1-csekk][0]) * (Adat[i+1+csekkb][1]-Adat[i-1-csekk][1]) / (Adat[i+1+csekkb][0]-Adat[i-1-csekk][0]);	
Adat[i][3]=Adat[i-1-csekk][3]+ (Adat[i][0]-Adat[i-1-csekk][0]) * (Adat[i+1+csekkb][3]-Adat[i-1-csekk][3]) / (Adat[i+1+csekkb][0]-Adat[i-1-csekk][0]);
Adat[i][5]=Adat[i-1-csekk][5]+ (Adat[i][0]-Adat[i-1-csekk][0]) * (Adat[i+1+csekkb][5]-Adat[i-1-csekk][5]) / (Adat[i+1+csekkb][0]-Adat[i-1-csekk][0]);
Adat[i][7]=Adat[i-1-csekk][7]+ (Adat[i][0]-Adat[i-1-csekk][0]) * (Adat[i+1+csekkb][7]-Adat[i-1-csekk][7]) / (Adat[i+1+csekkb][0]-Adat[i-1-csekk][0]);	   	

Adat[i][2]=sqrt(Adat[i-1-csekk][2]*Adat[i-1-csekk][2]+Adat[i+1+csekkb][2]*Adat[i+1+csekkb][2]); 
Adat[i][4]=sqrt(Adat[i-1-csekk][4]*Adat[i-1-csekk][4]+Adat[i+1+csekkb][4]*Adat[i+1+csekkb][4]); 
Adat[i][6]=sqrt(Adat[i-1-csekk][6]*Adat[i-1-csekk][6]+Adat[i+1+csekkb][6]*Adat[i+1+csekkb][6]); 
Adat[i][8]=sqrt(Adat[i-1-csekk][8]*Adat[i-1-csekk][8]+Adat[i+1+csekkb][8]*Adat[i+1+csekkb][8]);  
*/

/*
// swift lineraris interpolacio fuggveny nelkul
//for(j=0;j<swszam;j++)   if(sw[j].JD<=JD[i] && sw[j+1].JD>JD[i]){
//if(swbe[i].w2==0.0){
					  
swbe[i].w2=swbe[i-1-csekk].w2+ (swbe[i].JD-swbe[i-1-csekk].JD) * (swbe[i+1+csekkb].w2-swbe[i-1-csekk].w2) / (swbe[i+1+csekkb].JD-swbe[i-1-csekk].JD);
swbe[i].m2=swbe[i-1-csekk].m2+ (swbe[i].JD-swbe[i-1-csekk].JD) * (swbe[i+1+csekkb].m2-swbe[i-1-csekk].m2) / (swbe[i+1+csekkb].JD-swbe[i-1-csekk].JD);
swbe[i].w1=swbe[i-1-csekk].w1+ (swbe[i].JD-swbe[i-1-csekk].JD) * (swbe[i+1+csekkb].w1-swbe[i-1-csekk].w1) / (swbe[i+1+csekkb].JD-swbe[i-1-csekk].JD);
swbe[i].u=swbe[i-1-csekk].u+ (swbe[i].JD-swbe[i-1-csekk].JD) * (swbe[i+1+csekkb].u-swbe[i-1-csekk].u) / (swbe[i+1+csekkb].JD-swbe[i-1-csekk].JD);
swbe[i].b=swbe[i-1-csekk].b+ (swbe[i].JD-swbe[i-1-csekk].JD) * (swbe[i+1+csekkb].b-swbe[i-1-csekk].b) / (swbe[i+1+csekkb].JD-swbe[i-1-csekk].JD);
swbe[i].v=swbe[i-1-csekk].v+ (swbe[i].JD-swbe[i-1-csekk].JD) * (swbe[i+1+csekkb].v-swbe[i-1-csekk].v) / (swbe[i+1+csekkb].JD-swbe[i-1-csekk].JD);


swbeerr[i].w2=sqrt(swbeerr[i-1-csekk].w2*swbeerr[i-1-csekk].w2+swbeerr[i+1+csekkb].w2*swbeerr[i+1+csekkb].w2);
swbeerr[i].m2=sqrt(swbeerr[i-1-csekk].m2*swbeerr[i-1-csekk].m2+swbeerr[i+1+csekkb].m2*swbeerr[i+1+csekkb].m2);    
swbeerr[i].w1=sqrt(swbeerr[i-1-csekk].w1*swbeerr[i-1-csekk].w1+swbeerr[i+1+csekkb].w1*swbeerr[i+1+csekkb].w1);    
swbeerr[i].u=sqrt(swbeerr[i-1-csekk].u*swbeerr[i-1-csekk].u+swbeerr[i+1+csekkb].u*swbeerr[i+1+csekkb].u);
swbeerr[i].b=sqrt(swbeerr[i-1-csekk].b*swbeerr[i-1-csekk].b+swbeerr[i+1+csekkb].b*swbeerr[i+1+csekkb].b);
swbeerr[i].v=sqrt(swbeerr[i-1-csekk].v*swbeerr[i-1-csekk].v+swbeerr[i+1+csekkb].v*swbeerr[i+1+csekkb].v);

*/


/*
//regi bolometirkus integralok

//UNUSED
// fluxus integralas, trapezoid modszer, ha nincs valahol adat kilep es 0
// kikommentelhetoek egyes sorok, hogy azokat ne vegye szamitsba, csak ha nincs egy z sem, akkor jo
// ahol nincs adat, ott rosszul szamol
float bolints(float g, float r, float i, float z){
	  float bol;
	  
	  if(g==0) return 0;
	  if(r==0) return 0;
	  if(i==0) return 0;
	  //if(z==0) return 0;
	  
	  
					bol=0.5*( lsg-lecsap)*g +
                    ( g+0.5*(r-g) )*( lsr-lsg ) +
                    ( r+0.5*(i-r) )*( lsi-lsr ) +
				    //( i+0.5*(z-i) )*( lsz-lsi ) +
			        //(lsz*z)/3.0
			        (lsi*i)/3.0
			        ;
	  
	  
	  return bol;
	  }


//UNUSED
// hiba: hibaterjedes: trapezoid, ha nincs valahol adat kilep es 0
// ahol nincs adat, ott 0 a hiba, igy az nincs figyelembe veve: nem okoz problemat
float bolhibs(float g, float r, float i, float z, float ge, float re, float ie, float ze){
	  float hib;
			        
   	  if(g==0) return 0;
	  if(r==0) return 0;
	  if(i==0) return 0;
	  //if(z==0) return 0;
			        
                    hib=sqrt( 
					h( 0.5*ge *(lsg-lecsap)  + 0.5*ge *( lsr-lsg ) ) + 
                    h( 0.5*re *( lsr-lsg )   + 0.5*re *( lsi-lsr ) ) +
                    h( 0.5*ie *( lsi-lsr )   + 0.5*ie *( lsz-lsi ) ) +
				    h( 0.5*ze *( lsz-lsi )   + (lsz*ze)/3.0    )     
					);  
	   
	  return hib;
	  }
	  
	  

//UNUSED	  
// fluxus integralas, trapezoid modszer, ha nincs valahol adat kilep es 0
// kikommentelhetoek egyes sorok, hogy azokat ne vegye szamitsba, csak ha nincs egy z sem, akkor jo
// ahol nincs adat, ott rosszul szamol
float bolintj(float v, float r, float i, float b){
	  float bol;
	  
	  if(v==0) return 0;
	  if(r==0) return 0;
	  if(i==0) return 0;
	  if(b==0) return 0;
	  
					bol=0.5*( ljb-lecsap)*b +
                    ( b+0.5*(v-b) )*( ljv-ljb ) +
                    ( v+0.5*(r-v) )*( ljr-ljv ) +
				    ( r+0.5*(i-r) )*( lji-ljr ) +
			        (lji*i)/3.0
			        //(ljr*r)/3.0
			        ;
	  
	  
	  return bol;
	  }


//UNUSED
// hiba: hibaterjedes: trapezoid, ha nincs valahol adat kilep es 0
// ahol nincs adat, ott 0 a hiba, igy az nincs figyelembe veve: nem okoz problemat
float bolhibj(float v, float r, float i, float b, float ve, float re, float ie, float be){
	  float hib;
	  
	  if(v==0) return 0;
	  if(r==0) return 0;
	  if(i==0) return 0;
	  if(b==0) return 0;
			        
                    hib=sqrt( 
					h( 0.5*be *(ljb-lecsap)  + 0.5*be *( ljv-ljb ) ) + 
                    h( 0.5*ve *( ljv-ljb )   + 0.5*ve *( ljr-ljv ) ) +
                    h( 0.5*re *( ljr-ljv )   + 0.5*re *( lji-ljr ) ) +
				    h( 0.5*ie *( lji-ljr )   + (lji*ie)/3.0    )     
					);  
	   
	  return hib;
	  }
*/



/*
//bolometrikus integralas regebbi valtozata, fuggveny nelkul, mukodik, �gy mentve

					bolom[i][1]= 0.5*(4770.0-2000.0)*flux[i][1] +
                    (flux[i][1]+0.5*(flux[i][3]-flux[i][1]))*(6230.0-4770.0) +
                    (flux[i][3]+0.5*(flux[i][5]-flux[i][3]))*(7630.0-6230.0) +
				    (flux[i][5]+0.5*(flux[i][7]-flux[i][5]))*(9130.0-7630.0) +
			        (9130.0*flux[i][7])/3.0;
			        
			        bolom[i][2]=(0.5*(4770.0-2000.0)*(flux[i][1]+flux[i][2]) +
                    (flux[i][1]+flux[i][2]+0.5*(flux[i][3]+flux[i][4]-flux[i][1]-flux[i][2]))*(6230.0-4770.0) +
                    (flux[i][3]+flux[i][4]+0.5*(flux[i][5]+flux[i][6]-flux[i][3]-flux[i][4]))*(7630.0-6230.0) +
				    (flux[i][5]+flux[i][6]+0.5*(flux[i][7]+flux[i][8]-flux[i][5]-flux[i][6]))*(9130.0-7630.0) +
			        (9130.0*(flux[i][7]+flux[i][8]))/3.0) - bolom[i][1];
*/


/*
//bolometrikus integralas regebbi valtozata, verzio fuggveny valtozata
			        hib=(0.5*(4770.0-2000.0)*(g+ge) +
                    (g+ge+0.5*(r+re-g-ge))* (lsr-lsg) +
                    (r+re+0.5*(i+ie-r-re))* (lsi-lsr) +
				    (i+ie+0.5*(z+ze-i-ie))* (lsz-lsi) +
			        (lsz*(z+ze))/3.0) - bol;
*/

