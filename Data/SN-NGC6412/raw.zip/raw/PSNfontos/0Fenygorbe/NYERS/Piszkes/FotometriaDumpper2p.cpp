#include <math.h>
#include <stdio.h>

#define PI 3.14159265358979

//tiltott adatok: (0 a mind, 0 az elso)
//i==0 || i==4
       #define tiltott i==0 
       #define tilt 1





//kivon� f�ggv�ny (szin fugges mentes)(tiltott referencia csillagokat manu�lisan �llisd be) ELLEN�RIZD!
//M�k�d�s: adatokat megkapja, �s a megfelel� sz�r�t, majd pedig a k�l�nbs�gek �tlag�t veszi, �s ezt adja vissza. IF-es r�szben a NEM KIV�NT referencia csillagod adjuk meg.
//k: korrekci�. Ahol 0.0 �rt�k� a ref csill, azt nem sz�mitja bele
float kivonas(float a[][4],float b[],int n){
	float e=0;
	int i;
	int k=0;
	for(i=0;i<n;i++){
	  
	  //tiltott adatok:	  			 
	  if(        tiltott         ){} else{	
      if(a[i][1]==0.0){k=k+1;}     else{			 
	  e=e+( a[i][1]-b[i] );
      //printf("%f\n",a[i][1]-b[i]);
	  }}}
	  
    e=e/(n-k-tilt);
	
	return e;
	}

//kivon�s szor�s�t hat�rozza meg	
float hiba(float a[][4],float b[],int n){
	float e=0;
	float sz=0;
	int i;
	int k=0;
	for(i=0;i<n;i++){
	  	  			 
	  if(          tiltott            ){} else{	
      if(a[i][1]==0.0){k=k+1;}     else{			 
	  e=e+( a[i][1]-b[i] );
         
	  }}}
    e=e/(n-k-tilt);
    
    k=0;
    printf("\n");
    for(i=0;i<n;i++){
	  		    			 
	  if(         tiltott          ){} else{
      if(a[i][1]==0.0){k=k+1;}     else{				 
	  sz=sz+(e-a[i][1]+b[i])*(e-a[i][1]+b[i]);
	  printf("%f  ",a[i][1]-b[i]);
	  printf("%f\n",e-a[i][1]+b[i]);
   	  }}}
	  
	  sz=sqrt(sz/(n-k-tilt));
	
	return sz;
	}
	







//kivon� f�ggv�ny (tiltott referencia csillagokat manu�lisan �llisd be) ELLEN�RIZD!
//M�k�d�s: adatokat megkapja, �s a megfelel� sz�r�t, majd pedig a k�l�nbs�gek �s szinfugges �tlag�t veszi, �s ezt adja vissza. IF-es r�szben a NEM KIV�NT referencia csillagod adjuk meg.
//mert adat, ref adat (amihez hasonlitunk), szin ref c-d, szin ref, mennyi az osszes, szintag
float kivonas2(float a[][4],float b[],float c[],float d[],int n,float Cx){
	float e=0;
	int i;
	int k=0;
	for(i=0;i<n;i++){
	  
	  //tiltott adatok:	  			 
	  if(        tiltott         ){} else{
      if(a[i][1]==0.0){k=k+1;}     else{				 
	  e=e+( a[i][1]-b[i] -Cx*(c[i]-d[i]) );
      //printf("%f\n",a[i][1]-b[i] +Cx*(c[i]-d[i]) );
	  }}}
	  
    e=e/(n-k-tilt);
	
	return e;
	}

//kivon�s szor�s�t hat�rozza meg, adatok ugyan azok	
float hiba2(float a[][4],float b[],float c[],float d[],int n,float Cx){
	float e=0;
	float sz=0;
	int i;
	int k=0;
	for(i=0;i<n;i++){
	  	  			 
	  if(          tiltott            ){} else{
      if(a[i][1]==0.0){k=k+1;}     else{				 
	  e=e+( a[i][1]-b[i] -Cx*(c[i]-d[i]) );
         
	  }}}
    e=e/(n-k-tilt);
    
    k=0;
    printf("\n");
    for(i=0;i<n;i++){
	  		    			 
	  if(         tiltott          ){} else{
      if(a[i][1]==0.0){k=k+1;}     else{				 
	  sz=sz+(e-a[i][1]+b[i] +Cx*(c[i]-d[i]) )*(e-a[i][1]+b[i] +Cx*(c[i]-d[i]) );
	  printf("%f  ",a[i][1]-b[i] -Cx*(c[i]-d[i]) );
	  printf("%f\n",e-a[i][1]+b[i] +Cx*(c[i]-d[i]) );
   	  }}}
	  
	  sz=sqrt(sz/(n-k-tilt));
	
	return sz;
	}
	
	
	

	



		// txdumpba: ifilter,otime,mag,merr, minden mehet egy f�jlba! ez lesz a bemenet
		// referencia csillagok UT�N legyen mindig a m�rend� objektum adatai

int main ()
{
 
 
int n;   // referencia csillagok sz�ma
int m=0;   // 4* m�rt �jszak�k sz�ma


                    //referencia csillagok sz�ma (n)
                    n=5; 
 
 
 
//referencia csillagoknak a t�mbjei
float Tg[n];
float Tr[n];
float Ti[n];
float Tz[n];

float TV[n];  //VRIB szuro
float TR[n];
float TI[n];
float TB[n];

float Adat[n+1][4];   //beolvasand� adatok
float Adatk[100][4];  //beolvasand� adatok a 2. r�szhez
float temp[4];        //ideiglenes t�bl�zat a mozgat�shoz
char szuro [100];   //sz�r�

int i;   // ciklus v�ltoz�k
int j;
int k;
float e=0;   //eredm�ny
float sz=0;  //szor�s
float s=0;   //seged
double dat;    //kezd� d�tum

float Cg;
float Cr;
float Ci;
float Cz;


FILE *f;
FILE *fg;
FILE *fr;
FILE *fi;
FILE *fz;
FILE *fgk;
FILE *frk;
FILE *fik;
FILE *fzk;
FILE *fszin;


	 //bemenet:
     f=fopen("Eredmeny.txt","r");

//kimenet: sz�r�nk�nt 1-1
fg=fopen("V-gorbeS.txt","wt+r");
fr=fopen("R-gorbeS.txt","wt+r");
fi=fopen("I-gorbeS.txt","wt+r");
fz=fopen("B-gorbeS.txt","wt+r");

//kimenet: sz�r�nk�nt 1-1
fgk=fopen("V-gorbe.txt","wt+r");
frk=fopen("R-gorbe.txt","wt+r");
fik=fopen("I-gorbe.txt","wt+r");
fzk=fopen("B-gorbe.txt","wt+r");

//szini kimenet
fszin=fopen("szin-gorbe.txt","wt");




   // Referencia csillagok f�nyess�gei: �RD BE MANU�LISAN!! (g r i z)


//NGC6412 sn regio (javitott 3)
  //  1                      2                        3                      4                        5
   TV[0]=16.298000;        TV[1]=16.243700;        TV[2]=16.709751;        TV[3]=16.006701;        TV[4]=15.479350;        
   TR[0]=16.001579;        TR[1]=15.845460;        TR[2]=16.391581;        TR[3]=15.696990;        TR[4]=15.082399;        
   TI[0]=15.612380;        TI[1]=15.419061;        TI[2]=16.002378;        TI[3]=15.279890;        TI[4]=14.637400;        
   TB[0]=16.884201;        TB[1]=17.023062;        TB[2]=17.339849;        TB[3]=16.610460;        TB[4]=16.249929;
   

//RC 2015 javitott
//szinfuggo lemez konstansok megadasa (ezt egy masik program szamolja)
   Cg=0;
   Cr=0;
   Ci=0;
   Cz=0;


//griz tombe viszi, hogy ne kelljen ezeket atirni!
for(i=0;i<n;i++){
 Tg[i]=TV[i];
 Tr[i]=TR[i];
 Ti[i]=TI[i];
 Tz[i]=TB[i];
}



//megm�ri a f�jl hossz�t (menezheti mit olvas be)
printf("Beolvasva:\n");
while(!feof(f)){
  for(k=0;k<n+1;k++) fscanf(f,  "%f  %s  %f  %f  %f\n",&Adat[k][3],szuro,&Adat[k][0],&Adat[k][1],&Adat[k][2]);
  for(k=0;k<n+1;k++) printf(  "%d  %s  %f  %f  %f\n",int(Adat[k][3]),szuro,Adat[k][0],Adat[k][1],Adat[k][2]);      printf("\n");
  m++; }

printf("szamolt kepek: %d",m);
getchar();





dat=2400000;  // kezd� d�tum, hogy sz�p legyen a grafikon, MJD

rewind (f);

/*m�k�d�s: bels� ciklus beolvassa az adatokat, annyi sort ah�ny referencia csillag van +1,
a k�ls� ciklus pedig annyiszor csin�lja ezt amennyi m�rt �jszaka van *4.
sz�r�t is beolvassa, �s ennek megfelel�en k�l�nb�z�en j�r el.
j� sz�r�s f�nyess�g adatokat elk�ldi a f�ggv�nynek, referencia csillagok f�nyess�g�t kivonja az adatokb�l,
majd az �tlag�t kivonja az objektum f�yness�g�b�l, majd f�ljba �rja, sz�r�nk�nt m�sba*/




for(i=0;i<m+1;i++){

  for(k=0;k<n+1;k++){
  fscanf(f,  "%f  %s  %f  %f  %f\n",&Adat[k][3],szuro,&Adat[k][0],&Adat[k][1],&Adat[k][2]);
  }


  for(k=n;k>0;k--){
     for(j=0;j<k;j++){
         if(Adat[j][3]>Adat[j+1][3]){
		    temp[3]=Adat[j][3];
			temp[0]=Adat[j][0];
			temp[1]=Adat[j][1];
			temp[2]=Adat[j][2];
			
			Adat[j][3]=Adat[j+1][3];
			Adat[j][0]=Adat[j+1][0];
			Adat[j][1]=Adat[j+1][1];
			Adat[j][2]=Adat[j+1][2];
			
			Adat[j+1][3]=temp[3];
			Adat[j+1][0]=temp[0];
			Adat[j+1][1]=temp[1];
			Adat[j+1][2]=temp[2];							 
		    }
		 
	 }
  }
  
  if(Adat[n][0]==Adat[0][0]){  printf("\nDatum JO");} else  printf("\nDatum ROSSZ"); 
  //Datum ellenorzes
  


  if(*szuro=='V'){ float e=kivonas2(Adat,Tg,Tg,Ti,n,Cg);  float sz=hiba2(Adat,Tg,Tg,Ti,n,Cg);
  printf("%f %f %f %s\n",e,sz,Adat[n][1]-e,szuro); 
  fprintf(fg,"%f %f %f %f\n",Adat[n][0]-dat,Adat[n][1]-e,Adat[n][2],sz); }
  
  if(*szuro=='R'){ float e=kivonas2(Adat,Tr,Tg,Ti,n,Cr);  float sz=hiba2(Adat,Tr,Tg,Ti,n,Cr);
  printf("%f %f %f %s\n",e,sz,Adat[n][1]-e,szuro);   
  fprintf(fr,"%f %f %f %f\n",Adat[n][0]-dat,Adat[n][1]-e,Adat[n][2],sz); }
  
  if(*szuro=='I'){ float e=kivonas2(Adat,Ti,Tg,Ti,n,Ci);  float sz=hiba2(Adat,Ti,Tg,Ti,n,Ci);
  printf("%f %f %f %s\n",e,sz,Adat[n][1]-e,szuro); 
  fprintf(fi,"%f %f %f %f\n",Adat[n][0]-dat,Adat[n][1]-e,Adat[n][2],sz); }
  
  if(*szuro=='B'){ float e=kivonas2(Adat,Tz,Tg,Ti,n,Cz);  float sz=hiba2(Adat,Tz,Tg,Ti,n,Cz);
  printf("%f %f %f %s\n",e,sz,Adat[n][1]-e,szuro); 
  fprintf(fz,"%f %f %f %f\n",Adat[n][0]-dat,Adat[n][1]-e,Adat[n][2],sz); }
  
  

}

printf("\negyeni atlag, atlagtol valo elteres\nkulonbseg, szorasa, eredmeny, szuro");

      //kimenet: d�tum, f�nyess�g, f�nyess�g hiba, kivon�s hib�ja 
      //x-gorbeS



fclose(f);
getchar();




// 2. resz: szinfugges korrekcio ===============================================

for(i=0;i<100;i++) Adatk[i][0]=0;
for(i=0;i<100;i++) Adatk[i][1]=0;
for(i=0;i<100;i++) Adatk[i][2]=0;
for(i=0;i<100;i++) Adatk[i][3]=0;


rewind (fg);
rewind (fi);


//g-t ujra olvasva, hossz meghatarozashoz. Ido, g fenyesseget berakja a tombbe
printf("\nBeolvasva:\n");
m=0;
while(!feof(fg)){
  fscanf(fg,"%f %f %f %f\n",&Adatk[m][0],&Adatk[m][1],&e,&e);
  m++; }

printf("szamolt hossz: %d, g\n",m);


//i-t ujra olvasva, datummal ellenorizve, g melle rakja
i=0;
while(!feof(fi)){
  fscanf(fi,"%f %f %f %f\n",&s,&sz,&e,&e);
  for(j=0;j<m+1;j++){ if( int(s)==int(Adatk[j][0]) ){Adatk[j][2]=sz; j=m+1;}  }
  i++; }
                   
printf("szamolt hossz: %d, i\n",i);



//g-i tombbe rakja, kiirja
printf("\nA szinek:\n");
printf("JD, g, i, g-i\n");
for(i=0;i<m+1;i++){
                   if( Adatk[i][1]+Adatk[i][2]!=0 ) Adatk[i][3]=Adatk[i][1]-Adatk[i][2];
                   printf("%f %f %f %f\n",Adatk[i][0],Adatk[i][1],Adatk[i][2],Adatk[i][3]);
                   }
//kiiras: JD, g, i, g-i
                   
                   
                   
rewind (fg);
rewind (fr);
rewind (fi);
rewind (fz);


//Sima-t beolvassa, datummal ellenorizve szint korrigal, es kiirja mashova
//+ a szint is kiirja
//! ahol nincs g, i, vagy datum, akkor 0-val korrigal (nincs korrekcio)
for(i=0;i<m+1;i++){
                   e=0;
                   fscanf(fg,"%f %f %f %f\n",&Adat[0][0],&Adat[0][1],&Adat[0][2],&Adat[0][3]);
                   for(j=0;j<m+1;j++) if( int(Adat[0][0])==int(Adatk[j][0]) ){ e=Adatk[j][3]; j=m+1; }
                   fprintf(fgk,"%f %f %f %f\n", Adat[0][0], Adat[0][1]-Cg*e, Adat[0][2], Adat[0][3]);
                   
                   e=0;
                   fscanf(fr,"%f %f %f %f\n",&Adat[0][0],&Adat[0][1],&Adat[0][2],&Adat[0][3]);
                   for(j=0;j<m+1;j++) if( int(Adat[0][0])==int(Adatk[j][0]) ){ e=Adatk[j][3]; j=m+1; }
                   fprintf(frk,"%f %f %f %f\n", Adat[0][0], Adat[0][1]-Cr*e, Adat[0][2], Adat[0][3]);
                   
                   e=0;
                   fscanf(fi,"%f %f %f %f\n",&Adat[0][0],&Adat[0][1],&Adat[0][2],&Adat[0][3]);
                   for(j=0;j<m+1;j++) if( int(Adat[0][0])==int(Adatk[j][0]) ){ e=Adatk[j][3]; j=m+1; }
                   fprintf(fik,"%f %f %f %f\n", Adat[0][0], Adat[0][1]-Ci*e, Adat[0][2], Adat[0][3]);
                   
                   e=0;
                   fscanf(fz,"%f %f %f %f\n",&Adat[0][0],&Adat[0][1],&Adat[0][2],&Adat[0][3]);
                   for(j=0;j<m+1;j++) if( int(Adat[0][0])==int(Adatk[j][0]) ){ e=Adatk[j][3]; j=m+1; }
                   fprintf(fzk,"%f %f %f %f\n", Adat[0][0], Adat[0][1]-Cz*e, Adat[0][2], Adat[0][3]);              
                   
                   if(Adatk[i][3]!=0) fprintf(fszin,"%f %f\n",Adatk[i][0],Adatk[i][3]);
                   }




      //kimenet: d�tum, korr f�nyess�g, f�nyess�g hiba, kivon�s hib�ja
      //x-gorbe   az alap a v�gs� szinkorrig�lt 

fclose(fg);
fclose(fr);
fclose(fi);
fclose(fz);

fclose(fgk);
fclose(frk);
fclose(fik);
fclose(fzk);
fclose(fszin);


printf("\n\n");
getchar();
return 0;		

}

