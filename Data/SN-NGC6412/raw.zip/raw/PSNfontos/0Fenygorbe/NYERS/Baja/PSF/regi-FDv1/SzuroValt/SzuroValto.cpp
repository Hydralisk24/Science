#include <stdio.h>
#include <math.h>

//hatvanyozas
double h(double x){
       double y;
       y=x*x;
       return y;
       }



int main (){
    
int n;  // ref csill szam
int i;  // ciklus valt
int j;
int m; // szamolja az ejszakak szamat

int hib; //seged bool


         //ref csillaogk szama
         n=5;
    
    
    
float Tg[n];  //griz tomb
float Tr[n];
float Ti[n];
float Tz[n];   

float TV[n];   //VRIB tomb
float TR[n];
float TI[n];
float TB[n];   


float Adat[100][13];  //konvertalt tomb
float Adatk[100][13]; //bevitelo tomb

float s;  //segedek
float sz;
float szz;
float szzz;



FILE *f;

//kimenet:
f=fopen("szuro.txt","wt");






   
if(1){  //szekcio engedelyezese (1:igen 0:nem)  
//ugriz -> UBVRcIc   

//NGC6412 sn regio (javitott 3)
  //  1                      2                   3                   4                   5
   Tg[0]=16.54;           Tg[1]=16.61;        Tg[2]=16.98;        Tg[3]=16.26;        Tg[4]=15.84;
   Tr[0]=16.14;           Tr[1]=15.99;        Tr[2]=16.53;        Tr[3]=15.84;        Tr[4]=15.23;
   Ti[0]=16.00;           Ti[1]=15.81;        Ti[2]=16.39;        Ti[3]=15.67;        Ti[4]=15.03;
   Tz[0]=00.00;           Tz[1]=00.00;        Tz[2]=00.00;        Tz[3]=00.00;        Tz[4]=00.00;
    
    

//ugriz -> UBVRcIc    
for(i=0;i<n;i++){

   TB[i] = Tg[i] + 0.313  *(Tg[i]-Tr[i]) + 0.219;
   TV[i] = Tg[i] + -0.565 *(Tg[i]-Tr[i]) - 0.016;
   TR[i] = Tr[i] + -0.153 *(Tr[i]-Ti[i]) - 0.117;
   TI[i] = TR[i] - 0.930  *(Tr[i]-Ti[i]) - 0.259;
   //TI[i] = Ti[i] + -0.386 *(Ti[i]-Tz[i]) - 0.397;

}
    


//kiirasa, szuro.txt-be
fprintf(f,"\n   ");
for(i=0;i<n;i++)   fprintf(f,"TV[%d]=%f;        ",i,TV[i]);           
                      
fprintf(f,"\n   ");
for(i=0;i<n;i++)   fprintf(f,"TR[%d]=%f;        ",i,TR[i]);  

fprintf(f,"\n   ");
for(i=0;i<n;i++)   fprintf(f,"TI[%d]=%f;        ",i,TI[i]);      
    
fprintf(f,"\n   ");
for(i=0;i<n;i++)   fprintf(f,"TB[%d]=%f;        ",i,TB[i]);  



printf("\n");
for(i=0;i<n;i++)   printf("TV[%d]=%f;    ",i,TV[i]);           
                      
printf("\n");
for(i=0;i<n;i++)   printf("TR[%d]=%f;    ",i,TR[i]);  

printf("\n");
for(i=0;i<n;i++)   printf("TI[%d]=%f;    ",i,TI[i]);      
    
printf("\n");
for(i=0;i<n;i++)   printf("TB[%d]=%f;    ",i,TB[i]);  

}








if(0){  //szekcio engedelyezese (1:igen 0:nem)   
//UBVRcIc -> ugriz 

//NGC6412 sn regio (javitott 2)
  //  1                      2                   3                   4                   5
   TV[0]=16.235800;        TV[1]=16.145401;        TV[2]=16.643200;        TV[3]=15.940150;        TV[4]=15.385400;
   TR[0]=15.979340;        TR[1]=15.805571;        TR[2]=16.367811;        TR[3]=15.671690;        TR[4]=15.042510;
   TI[0]=15.515740;        TI[1]=15.258270;        TI[2]=15.894912;        TI[3]=15.161591;        TI[4]=14.476610;
   TB[0]=16.716640;        TB[1]=16.766720;        TB[2]=17.159161;        TB[3]=16.429771;        TB[4]=16.006720;    
    

//UBVRcIc -> ugriz    
for(i=0;i<n;i++){

   Tg[i] = TV[i] + 0.630*(TB[i]-TV[i]) - 0.124;
   //Tg[i] = TB[i] - 0.370*(TB[i]-TV[i]) - 0.124;
   Tr[i] = TR[i] + 0.267*(TV[i]-TR[i]) + 0.088;
   Ti[i] = TI[i] + 0.247*(TR[i]-TI[i]) + 0.329;

}
    


//kiirasa, szuro.txt-be
fprintf(f,"\n   ");
for(i=0;i<n;i++)   fprintf(f,"Tg[%d]=%f;        ",i,Tg[i]);           
                      
fprintf(f,"\n   ");
for(i=0;i<n;i++)   fprintf(f,"Tr[%d]=%f;        ",i,Tr[i]);  

fprintf(f,"\n   ");
for(i=0;i<n;i++)   fprintf(f,"Ti[%d]=%f;        ",i,Ti[i]);      
    
fprintf(f,"\n   ");
for(i=0;i<n;i++)   fprintf(f,"Tz[%d]=%f;        ",i,0.0);  



printf("\n");
for(i=0;i<n;i++)   printf("Tg[%d]=%f;    ",i,Tg[i]);           
                      
printf("\n");
for(i=0;i<n;i++)   printf("Tr[%d]=%f;    ",i,Tr[i]);  

printf("\n");
for(i=0;i<n;i++)   printf("Ti[%d]=%f;    ",i,Ti[i]);      
    
printf("\n");
for(i=0;i<n;i++)   printf("Tz[%d]=%f;    ",i,0.0);  

}

fclose(f);
printf("\n\n");
getchar();






// 2. resz: tobb atvaltas  ================================================================
if(1){  //szekcio engedelyezese (1:igen 0:nem)  

FILE *fg;
FILE *fr;
FILE *fi;
FILE *fz;
FILE *fgk;
FILE *frk;
FILE *fik;
FILE *fzk;


                          //Allitando!!!
                          //bemenet: sz�r�nk�nt 1-1
                          fg=fopen("g-gorbe.txt","r");
                          fr=fopen("r-gorbe.txt","r");
                          fi=fopen("i-gorbe.txt","r");
                          fz=fopen("z-gorbe.txt","r");

                          //kimenet: sz�r�nk�nt 1-1
                          fgk=fopen("V-gorbeC.txt","wt");
                          frk=fopen("R-gorbeC.txt","wt");
                          fik=fopen("I-gorbeC.txt","wt");
                          fzk=fopen("B-gorbeC.txt","wt");



//nullazas
for(i=0;i<100;i++) for(j=0;j<13;j++) Adatk[i][j]=0;

for(i=0;i<100;i++) for(j=0;j<13;j++) Adat[i][j]=0;



//g,V-t ujra olvasva, hossz meghatarozashoz. Ido, g,V fenyesseget berakja a tombbe
printf("\nBeolvasva:\n");
m=0;
while(!feof(fg)){
  fscanf(fg,"%f %f %f %f\n",&Adatk[m][0],&Adatk[m][1],&Adatk[m][5],&Adatk[m][9]);
  m++; }

printf("szamolt hossz: %d, g,V\n",m);



//r,R-t ujra olvasva, datummal ellenorizve, g,V melle rakja
//ha olyan datumot talal ami g-nel nem volt, akkor belerakja (mindnel!)
i=0;
while(!feof(fr)){
  hib=1;
  fscanf(fr,"%f %f %f %f\n",&s,&sz,&szz,&szzz);
  for(j=0;j<m;j++){ if( int(s)==int(Adatk[j][0]) ){Adatk[j][2]=sz; Adatk[j][6]=szz; Adatk[j][10]=szzz; j=m+1; hib=0;}  }
  if(hib){ Adatk[m][0]=s; Adatk[m][2]=sz; Adatk[m][6]=szz; Adatk[m][10]=szzz; m++; }
  i++;
  }
                   
printf("szamolt hossz: %d, r,R\n",i);



//i,I-t ujra olvasva, datummal ellenorizve, g,V melle rakja
i=0;
while(!feof(fi)){
  hib=1;
  fscanf(fi,"%f %f %f %f\n",&s,&sz,&szz,&szzz);
  for(j=0;j<m;j++){ if( int(s)==int(Adatk[j][0]) ){Adatk[j][3]=sz; Adatk[j][7]=szz; Adatk[j][11]=szzz; j=m+1; hib=0;}  }
  if(hib){ Adatk[m][0]=s; Adatk[m][3]=sz; Adatk[m][7]=szz; Adatk[m][11]=szzz; m++; }
  i++;
  }
                   
printf("szamolt hossz: %d, i,I\n",i);



//z,B-t ujra olvasva, datummal ellenorizve, g,V melle rakja
i=0;
while(!feof(fz)){
  hib=1;
  fscanf(fz,"%f %f %f %f\n",&s,&sz,&szz,&szzz);
  for(j=0;j<m;j++){ if( int(s)==int(Adatk[j][0]) ){Adatk[j][4]=sz; Adatk[j][8]=szz; Adatk[j][12]=szzz; j=m+1; hib=0;}  }
  if(hib){ Adatk[m][0]=s; Adatk[m][4]=sz; Adatk[m][8]=szz; Adatk[m][12]=szzz; m++; }
  i++;
  }
                   
printf("szamolt hossz: %d, z,B\n",i);


//Adatk[][]-ben van most a 4 szuro erteke DATUMra rendezve!





//ugriz -> UBVRcIc    
//Ha csak az egyik komponsens is nincs meg, nincs atvaltas!!!!! jav
//Mindig a z menteset resziti elonyben, de ha csak az van, vegre hajta azt 
//Adat  B:4 V:1 R:2 I:3
//Adatk g:1 r:2 i:3 z:4
//hiba: hibaterjedessel (2. 3.)
for(i=0;i<m;i++){
                 
   Adat[i][0]=Adatk[i][0];
   if(Adatk[i][1]*Adatk[i][2])        Adat[i][4] = Adatk[i][1] + 0.313  *(Adatk[i][1]-Adatk[i][2]) + 0.219;
   if(Adatk[i][1]*Adatk[i][2])        Adat[i][1] = Adatk[i][1] + -0.565 *(Adatk[i][1]-Adatk[i][2]) - 0.016;
   if(Adatk[i][2]*Adatk[i][3])        Adat[i][2] = Adatk[i][2] + -0.153 *(Adatk[i][2]-Adatk[i][3]) - 0.117;
   if(Adatk[i][2]*Adatk[i][3])        Adat[i][3] = Adat[i][2]  - 0.930  *(Adatk[i][2]-Adatk[i][3]) - 0.259;
   else if(Adatk[i][3]*Adatk[i][4])   Adat[i][3] = Adatk[i][3] + -0.386 *(Adatk[i][3]-Adatk[i][4]) - 0.397;

   if(Adatk[i][1]*Adatk[i][2])        Adat[i][8] =sqrt( 1.15*h(Adatk[i][5])+0.10*h(Adatk[i][6]) );
   if(Adatk[i][1]*Adatk[i][2])        Adat[i][5] =sqrt( 0.19*h(Adatk[i][5])+0.32*h(Adatk[i][6]) );
   if(Adatk[i][2]*Adatk[i][3])        Adat[i][6] =sqrt( 0.72*h(Adatk[i][6])+0.02*h(Adatk[i][7]) );
   if(Adatk[i][2]*Adatk[i][3])        Adat[i][7] =sqrt( h(Adat[i][6] )+0.86*h(Adatk[i][6])+0.86*h(Adatk[i][7]) );
   else if(Adatk[i][3]*Adatk[i][4])   Adat[i][7] =sqrt( 0.38*h(Adatk[i][7])+0.15*h(Adatk[i][8]) );

   if(Adatk[i][1]*Adatk[i][2])        Adat[i][12] =sqrt( 1.15*h(Adatk[i][ 9])+0.10*h(Adatk[i][10]) );
   if(Adatk[i][1]*Adatk[i][2])        Adat[i][ 9] =sqrt( 0.19*h(Adatk[i][ 9])+0.32*h(Adatk[i][10]) );
   if(Adatk[i][2]*Adatk[i][3])        Adat[i][10] =sqrt( 0.72*h(Adatk[i][10])+0.02*h(Adatk[i][11]) );
   if(Adatk[i][2]*Adatk[i][3])        Adat[i][11] =sqrt( h(Adat[i][10] )+0.86*h(Adatk[i][10])+0.86*h(Adatk[i][11]) );
   else if(Adatk[i][3]*Adatk[i][4])   Adat[i][11] =sqrt( 0.38*h(Adatk[i][11])+0.15*h(Adatk[i][12]) );
   
}


/*
//UBVRcIc -> ugriz  
//Ha csak az egyik komponsens is nincs meg, nincs atvaltas!!!!!
//g-nel a kisebb hibajut resziti elonyben (B es V kozott)
//Adatk B:4 V:1 R:2 I:3
//Adat  g:1 r:2 i:3 z:4
//hiba: hibaterjedessel (2. 3.)
for(i=0;i<m;i++){
                 
   Adat[i][0]=Adatk[i][0];
   if(Adatk[i][1]*Adatk[i][4] && Adatk[i][5]<=Adatk[i][8])  Adat[i][1] = Adatk[i][1] + 0.630*(Adatk[i][4]-Adatk[i][1]) - 0.124;
   if(Adatk[i][1]*Adatk[i][4] && Adatk[i][5]>Adatk[i][8] )  Adat[i][1] = Adatk[i][4] - 0.370*(Adatk[i][4]-Adatk[i][1]) - 0.124;
   if(Adatk[i][1]*Adatk[i][2])                              Adat[i][2] = Adatk[i][2] + 0.267*(Adatk[i][1]-Adatk[i][2]) + 0.088;
   if(Adatk[i][2]*Adatk[i][3])                              Adat[i][3] = Adatk[i][3] + 0.247*(Adatk[i][2]-Adatk[i][3]) + 0.329;

   if(Adatk[i][1]*Adatk[i][4] && Adatk[i][5]<=Adatk[i][8])  Adat[i][5] =sqrt( 0.14*h(Adatk[i][5])+0.40*h(Adatk[i][8]) );
   if(Adatk[i][1]*Adatk[i][4] && Adatk[i][5]>Adatk[i][8] )  Adat[i][5] =sqrt( 0.40*h(Adatk[i][8])+0.14*h(Adatk[i][5]) );
   if(Adatk[i][1]*Adatk[i][2])                              Adat[i][6] =sqrt( 0.54*h(Adatk[i][6])+0.07*h(Adatk[i][5]) );
   if(Adatk[i][2]*Adatk[i][3])                              Adat[i][7] =sqrt( 0.57*h(Adatk[i][7])+0.06*h(Adatk[i][6]) );

   if(Adatk[i][1]*Adatk[i][4] && Adatk[i][5]<=Adatk[i][8])  Adat[i][ 9] =sqrt( 0.14*h(Adatk[i][ 9])+0.40*h(Adatk[i][12]) );
   if(Adatk[i][1]*Adatk[i][4] && Adatk[i][5]>Adatk[i][8] )  Adat[i][ 9] =sqrt( 0.40*h(Adatk[i][12])+0.14*h(Adatk[i][ 9]) );
   if(Adatk[i][1]*Adatk[i][2])                              Adat[i][10] =sqrt( 0.54*h(Adatk[i][10])+0.07*h(Adatk[i][ 9]) );
   if(Adatk[i][2]*Adatk[i][3])                              Adat[i][11] =sqrt( 0.57*h(Adatk[i][11])+0.06*h(Adatk[i][10]) );
   
}*/


//Adat[][]-ben van most az ATVALTOTT 4 szuro erteke DATUMra rendezve!                   



//Fajlba iras
for(i=0;i<m;i++){
                 
   fprintf(fgk,"%f %f %f %f\n",Adat[i][0],Adat[i][1],Adat[i][5],Adat[i][9]);                
   fprintf(frk,"%f %f %f %f\n",Adat[i][0],Adat[i][2],Adat[i][6],Adat[i][10]);    
   fprintf(fik,"%f %f %f %f\n",Adat[i][0],Adat[i][3],Adat[i][7],Adat[i][11]);    
   fprintf(fzk,"%f %f %f %f\n",Adat[i][0],Adat[i][4],Adat[i][8],Adat[i][12]);    
                 
}             



fclose(fg);
fclose(fr);
fclose(fi);
fclose(fz);

fclose(fgk);
fclose(frk);
fclose(fik);
fclose(fzk);

printf("\n\n");
getchar();

}
    
    
    
/*   
(Jordi et al. 2006 A&A 460, 339)

ugriz -> UBVRcIc
B = g + ( 0.313 � 0.003)*(g-r) + (0.219 � 0.002)
V = g + (-0.565 � 0.001)*(g-r) - (0.016 � 0.001)
R = r + (-0.153 � 0.003)*(r-i) - (0.117 � 0.003)
I = R - ( 0.930 � 0.005)*(r-i) - (0.259 � 0.002)
I = i + (-0.386 � 0.004)*(i-z) - (0.397 � 0.001)

UBVRcIc -> ugriz
g = V +0.63*(B-V) -0.124
g = B -0.37*(B-V) -0.124
r = R +0.267*(V-R) + 0.088
i = I +0.247*(R-I) + 0.329

*/  
  
  

  
return 0;   
    
}
