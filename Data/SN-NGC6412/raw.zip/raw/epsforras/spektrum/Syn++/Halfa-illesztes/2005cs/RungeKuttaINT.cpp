#include <stdio.h>
#include <math.h>

#define PI 3.141592653
#define E 2.718281828

// RungeKutta modszer integr�l�s �ltalanosan


double h(double x){ return x*x; }

double save=0;


//integr�land� fuggveny:
double af(double t, double x){
	  double y;
	  
	  double a,b,aa,bb;
	  double K,v;
	  
	  K=6563;
	  v=7./300;
	  
a               = 0.383985         ;// +/- 0.005228     (1.361%)
b               = 101.308          ;// +/- 2.042        (2.015%)
aa              = 0.235776         ;// +/- 0.008988     (3.812%)
bb              = 46.2619          ;// +/- 1.8          (3.891%)
//aa=bb=0;
	  
	  save=  a*exp(-h((x-K)/b)/2.)  -  aa*exp(-h((x-K*(1-v) )/bb)/2.)   ;
	  y=fabs(save);
	  
	  
	  return y;	  
	  
	  }
	  


int main(){

double s;
double v;  // integr�l
double a;  // alap f

double dt;
double t;
double tig;

double ce;
double ck;
double ch;
double cn;

double de;
double dk;
double dh;
double dn;

double i;

//FILE *f; f=fopen("numRK.txt","wt");


    s=5000;     // t�l
    t=8000;    // ig
    dt=0.1;

int seged=0;

v=0;
	
tig=t/dt;
s=s/dt;

for(i=s;i<tig;i++){

a=af(v,i*dt);
ce=dt*a;

a=af(v+0.5*ce,(i+0.5)*dt);
ck=dt*a;

a=af(v+0.5*ck,(i+0.5)*dt);
ch=dt*a;

a=af(v+1.0*ch,(i+1.0)*dt);
cn=dt*a;


v=v+(1.0/6.0)*ce+(1.0/3.0)*ck+(1.0/3.0)*ch+(1.0/6.0)*cn;

if(save>0.01 && seged==0){ printf("\nInt @ %f: %f\n\n",i*dt,v);  seged=1; }



//fprintf(f,"%f %f\n",i*dt,v);
           }

printf("\nInt: %f\n done\n",v);

getchar();

//fclose(f);

//id� , sebess�g, �t


}
