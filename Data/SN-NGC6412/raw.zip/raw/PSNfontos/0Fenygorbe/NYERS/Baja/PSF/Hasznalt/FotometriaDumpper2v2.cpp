
#include <math.h>
#include <stdio.h>

#define PI 3.14159265358979

//tiltott adatok: (0 a mind, 0 az elso)
//i==0 || i==4
       #define tiltott i==0 
       #define tilt 1





//kivon� f�ggv�ny (szin fugges mentes)(tiltott referencia csillagokat manu�lisan �llisd be) ELLEN�RIZD!
//M�k�d�s: adatokat megkapja, �s a megfelel� sz�r�t, majd pedig a k�l�nbs�gek �tlag�t veszi, �s ezt adja vissza. IF-es r�szben a NEM KIV�NT referencia csillagod adjuk meg.
//k: korrekci�. Ahol 0.0 �rt�k� a ref csill, azt nem sz�mitja bele
float kivonas(float a[][4],float b[],int n){
	float e=0;
	int i;
	int k=0;
	for(i=0;i<n;i++){
	  
	  //tiltott adatok:	  			 
	  if(        tiltott         ){} else{	
      if(a[i][1]==0.0){k=k+1;}     else{			 
	  e=e+( a[i][1]-b[i] );
      //printf("%f\n",a[i][1]-b[i]);
	  }}}
	  
    e=e/(n-k-tilt);
	
	return e;
	}

//kivon�s szor�s�t hat�rozza meg	
float hiba(float a[][4],float b[],int n){
	float e=0;
	float sz=0;
	int i;
	int k=0;
	for(i=0;i<n;i++){
	  	  			 
	  if(          tiltott            ){} else{	
      if(a[i][1]==0.0){k=k+1;}     else{			 
	  e=e+( a[i][1]-b[i] );
         
	  }}}
    e=e/(n-k-tilt);
    
    k=0;
    printf("\n");
    for(i=0;i<n;i++){
	  		    			 
	  if(         tiltott          ){} else{
      if(a[i][1]==0.0){k=k+1;}     else{				 
	  sz=sz+(e-a[i][1]+b[i])*(e-a[i][1]+b[i]);
	  printf("%f  ",a[i][1]-b[i]);
	  printf("%f\n",e-a[i][1]+b[i]);
   	  }}}
	  
	  sz=sqrt(sz/(n-k-tilt));
	
	return sz;
	}
	




/*
m' a standard, m a mert, szin: g'-i' (standard) (m lehet g r i z)

m-m'= Cx*szin+e (Cx negativ)
m'= m - Cx*szin - e
e = m-m'- Cx*szin

ref csill.: (i. edik ref csill) (kivonas2)
e = szum(i){  m_i - m'_i - Cx*szin_i }/ref csill szam (n)  }
jeloles: e += a[] - b[] - Cx * (c[] - d[])   / n   , a[]:m  b[]:m'  c[]:g'  d[]:i'

SN:
m''_SN = m_SN - e
m'_SN = m''_SN - Cx*szin_SN
szin_SN: szin korigalatlan (g''-i'' -vel szamolt)
*/

//kivon� f�ggv�ny (tiltott referencia csillagokat manu�lisan �llisd be) ELLEN�RIZD!
//M�k�d�s: adatokat megkapja, �s a megfelel� sz�r�t, majd pedig a k�l�nbs�gek �s szinfugges �tlag�t veszi, �s ezt adja vissza. IF-es r�szben a NEM KIV�NT referencia csillagod adjuk meg.
//mert adat, ref adat (amihez hasonlitunk), szin ref c-d, szin ref, mennyi az osszes, szintag
float kivonas2(float a[][4],float b[],float c[],float d[],int n,float Cx){
	float e=0;
	int i;
	int k=0;
	for(i=0;i<n;i++){
	  
	  //tiltott adatok:	  			 
	  if(        tiltott         ){} else{
      if(a[i][1]==0.0){k=k+1;}     else{				 
	  e=e+( a[i][1]-b[i] -Cx*(c[i]-d[i]) );
      //printf("%f\n",a[i][1]-b[i] +Cx*(c[i]-d[i]) );
	  }}}
	  
    e=e/(n-k-tilt);
	
	return e;
	}

//kivon�s szor�s�t hat�rozza meg, adatok ugyan azok	
float hiba2(float a[][4],float b[],float c[],float d[],int n,float Cx){
	float e=0;
	float sz=0;
	int i;
	int k=0;
	for(i=0;i<n;i++){
	  	  			 
	  if(          tiltott            ){} else{
      if(a[i][1]==0.0){k=k+1;}     else{				 
	  e=e+( a[i][1]-b[i] -Cx*(c[i]-d[i]) );
         
	  }}}
    e=e/(n-k-tilt);
    
    k=0;
    printf("\n");
    for(i=0;i<n;i++){
	  		    			 
	  if(         tiltott          ){} else{
      if(a[i][1]==0.0){k=k+1;}     else{				 
	  sz=sz+(e-a[i][1]+b[i] +Cx*(c[i]-d[i]) )*(e-a[i][1]+b[i] +Cx*(c[i]-d[i]) );
	  printf("%f  ",a[i][1]-b[i] -Cx*(c[i]-d[i]) );
	  printf("%f\n",e-a[i][1]+b[i] +Cx*(c[i]-d[i]) );
   	  }}}
	  
	  sz=sqrt(sz/(n-k-tilt));
	
	return sz;
	}
	
	
	

	



		// txdumpba: ifilter,otime,mag,merr, minden mehet egy f�jlba! ez lesz a bemenet
		// referencia csillagok UT�N legyen mindig a m�rend� objektum adatai

int main ()
{
 
 
int n;   // referencia csillagok sz�ma
int m=0;   // 4* m�rt �jszak�k sz�ma

int gm=0;  // mennyi van belole szamlalo
int rm=0;
int im=0;
int zm=0;


                    //referencia csillagok sz�ma (n)
                    n=5; 
 
 
 
//referencia csillagoknak a t�mbjei
float Tg[n];
float Tr[n];
float Ti[n];
float Tz[n];

float Adat[n+1][4];   //beolvasand� adatok
float Adatk[200][7];  //beolvasand� adatok a 2. r�szhez
float temp[4];        //ideiglenes t�bl�zat a mozgat�shoz
char szuro [200];   //sz�r�

int i;   // ciklus v�ltoz�k
int j;
int k;
float e=0;   //eredm�ny
float sz=0;  //szor�s
float s=0;   //seged
float szz;   //seged2
double dat;    //kezd� d�tum

float Cg;
float Cr;
float Ci;
float Cz;


FILE *f;
FILE *fg;
FILE *fr;
FILE *fi;
FILE *fz;
FILE *fgk;
FILE *frk;
FILE *fik;
FILE *fzk;
FILE *fszin;


	 //bemenet:
     f=fopen("Eredmeny.txt","r");

//kimenet: sz�r�nk�nt 1-1
fg=fopen("g-gorbeS.txt","wt+r");
fr=fopen("r-gorbeS.txt","wt+r");
fi=fopen("i-gorbeS.txt","wt+r");
fz=fopen("z-gorbeS.txt","wt+r");

//kimenet: sz�r�nk�nt 1-1
fgk=fopen("g-gorbe.txt","wt+r");
frk=fopen("r-gorbe.txt","wt+r");
fik=fopen("i-gorbe.txt","wt+r");
fzk=fopen("z-gorbe.txt","wt+r");

//szini kimenet
fszin=fopen("szin-gorbe.txt","wt");




   // Referencia csillagok f�nyess�gei: �RD BE MANU�LISAN!! (g r i z)


//NGC6412 sn regio (javitott 3)
  //  1                      2                   3                   4                   5
   Tg[0]=16.54;           Tg[1]=16.61;        Tg[2]=16.98;        Tg[3]=16.26;        Tg[4]=15.84;
   Tr[0]=16.14;           Tr[1]=15.99;        Tr[2]=16.53;        Tr[3]=15.84;        Tr[4]=15.23;
   Ti[0]=16.00;           Ti[1]=15.81;        Ti[2]=16.39;        Ti[3]=15.67;        Ti[4]=15.03;
   Tz[0]=00.00;           Tz[1]=00.00;        Tz[2]=00.00;        Tz[3]=00.00;        Tz[4]=00.00;


//RC 2015 javitott
//szinfuggo lemez konstansok megadasa (ezt egy masik program szamolja)
   Cg=-0.125;
   Cr=-0.009;
   Ci=-0.095;
   Cz=0;








//megm�ri a f�jl hossz�t (menezheti mit olvas be)
printf("Beolvasva:\n");
while(!feof(f)){
  for(k=0;k<n+1;k++) fscanf(f,  "%f  %s  %f  %f  %f\n",&Adat[k][3],szuro,&Adat[k][0],&Adat[k][1],&Adat[k][2]);
  for(k=0;k<n+1;k++) printf(  "%d  %s  %f  %f  %f\n",int(Adat[k][3]),szuro,Adat[k][0],Adat[k][1],Adat[k][2]);      printf("\n");
  m++; }

printf("szamolt kepek: %d",m);
getchar();





dat=2400000.5;  // kezd� d�tum, hogy sz�p legyen a grafikon, MJD

rewind (f);

/*m�k�d�s: bels� ciklus beolvassa az adatokat, annyi sort ah�ny referencia csillag van +1,
a k�ls� ciklus pedig annyiszor csin�lja ezt amennyi m�rt �jszaka van *4.
sz�r�t is beolvassa, �s ennek megfelel�en k�l�nb�z�en j�r el.
j� sz�r�s f�nyess�g adatokat elk�ldi a f�ggv�nynek, referencia csillagok f�nyess�g�t kivonja az adatokb�l,
majd az �tlag�t kivonja az objektum f�yness�g�b�l, majd f�ljba �rja, sz�r�nk�nt m�sba*/




for(i=0;i<m;i++){

  for(k=0;k<n+1;k++){
  fscanf(f,  "%f  %s  %f  %f  %f\n",&Adat[k][3],szuro,&Adat[k][0],&Adat[k][1],&Adat[k][2]);
  }


  for(k=n;k>0;k--){
     for(j=0;j<k;j++){
         if(Adat[j][3]>Adat[j+1][3]){
		    temp[3]=Adat[j][3];
			temp[0]=Adat[j][0];
			temp[1]=Adat[j][1];
			temp[2]=Adat[j][2];
			
			Adat[j][3]=Adat[j+1][3];
			Adat[j][0]=Adat[j+1][0];
			Adat[j][1]=Adat[j+1][1];
			Adat[j][2]=Adat[j+1][2];
			
			Adat[j+1][3]=temp[3];
			Adat[j+1][0]=temp[0];
			Adat[j+1][1]=temp[1];
			Adat[j+1][2]=temp[2];							 
		    }
		 
	 }
  }
  
  if(int(Adat[n][0]+0.5)==int(Adat[0][0]+0.5)){  printf("\nDatum JO");} else  printf("\nDatum ROSSZ"); 
  //Datum ellenorzes
  


  if(*szuro=='g'){ float e=kivonas2(Adat,Tg,Tg,Ti,n,Cg);  float sz=hiba2(Adat,Tg,Tg,Ti,n,Cg); gm++;
  printf("%f %f %f %s\n",e,sz,Adat[n][1]-e,szuro); 
  fprintf(fg,"%f %f %f %f\n",Adat[n][0]-dat,Adat[n][1]-e,Adat[n][2],sz); }
  
  if(*szuro=='r'){ float e=kivonas2(Adat,Tr,Tg,Ti,n,Cr);  float sz=hiba2(Adat,Tr,Tg,Ti,n,Cr); rm++;
  printf("%f %f %f %s\n",e,sz,Adat[n][1]-e,szuro);   
  fprintf(fr,"%f %f %f %f\n",Adat[n][0]-dat,Adat[n][1]-e,Adat[n][2],sz); }
  
  if(*szuro=='i'){ float e=kivonas2(Adat,Ti,Tg,Ti,n,Ci);  float sz=hiba2(Adat,Ti,Tg,Ti,n,Ci); im++;
  printf("%f %f %f %s\n",e,sz,Adat[n][1]-e,szuro); 
  fprintf(fi,"%f %f %f %f\n",Adat[n][0]-dat,Adat[n][1]-e,Adat[n][2],sz); }
  
  if(*szuro=='z'){ float e=kivonas2(Adat,Tz,Tg,Ti,n,Cz);  float sz=hiba2(Adat,Tz,Tg,Ti,n,Cz); zm++;
  printf("%f %f %f %s\n",e,sz,Adat[n][1]-e,szuro); 
  fprintf(fz,"%f %f %f %f\n",Adat[n][0]-dat,Adat[n][1]-e,Adat[n][2],sz); }
  
  

}

printf("\negyeni atlag, atlagtol valo elteres\nkulonbseg, szorasa!, eredmeny, szuro");

      //kimenet: d�tum, f�nyess�g, f�nyess�g hiba, kivon�s hib�ja 
      //x-gorbeS



fclose(f);
getchar();




// 2. resz: szinfugges korrekcio ===============================================

for(i=0;i<200;i++) Adatk[i][0]=0;
for(i=0;i<200;i++) Adatk[i][1]=0;
for(i=0;i<200;i++) Adatk[i][2]=0;
for(i=0;i<200;i++) Adatk[i][3]=0;


rewind (fg);
rewind (fi);


//g-t ujra olvasva, hossz meghatarozashoz. Ido, g fenyesseget berakja a tombbe
printf("\n\nBeolvasva:\n");
m=0;
while(!feof(fg)){
  fscanf(fg,"%f %f %f %f\n",&Adatk[m][0],&Adatk[m][1],&e,&Adatk[m][4]);
  m++; }

printf("szamolt hossz: %d, g\n",m);


//i-t ujra olvasva, datummal ellenorizve, g melle rakja
i=0;
while(!feof(fi)){
  fscanf(fi,"%f %f %f %f\n",&s,&sz,&e,&szz);
  for(j=0;j<m;j++){ if( int(s+0.5)==int(Adatk[j][0]+0.5) ){Adatk[j][2]=sz; Adatk[j][5]=szz; j=m+1;}  }
  i++; }
                   
printf("szamolt hossz: %d, i\n",i);



//g-i tombbe rakja, kiirja
printf("\nA szinek: (ahol van korrekcio)\n");
printf("JD, g, i, g-i\n");
for(i=0;i<m;i++){
                   if( Adatk[i][1]!=0 && Adatk[i][2]!=0 ) {Adatk[i][3]=Adatk[i][1]-Adatk[i][2]; Adatk[i][6]=sqrt( Adatk[i][4]*Adatk[i][4]+Adatk[i][5]*Adatk[i][5] );}
                   printf("%f %f %f %f\n",Adatk[i][0],Adatk[i][1],Adatk[i][2],Adatk[i][3]);
                   }
//kiiras: JD, g, i, g-i
                   
                   
                   
rewind (fg);
rewind (fr);
rewind (fi);
rewind (fz);


printf("\n");
//Sima-t beolvassa, datummal ellenorizve szint korrigal, es kiirja mashova
//+ a szint is kiirja
//! ahol nincs g, i, vagy datum, akkor 0-val korrigal (nincs korrekcio)
for(i=0;i<gm;i++){
                   e=0;
                   fscanf(fg,"%f %f %f %f\n",&Adat[0][0],&Adat[0][1],&Adat[0][2],&Adat[0][3]);
                   for(j=0;j<m;j++) if( int(Adat[0][0]+0.5)==int(Adatk[j][0]+0.5) ){ e=Adatk[j][3]; j=m+1; }
                   fprintf(fgk,"%f %f %f %f\n", Adat[0][0], Adat[0][1]-Cg*e, Adat[0][2], Adat[0][3]);
                   if(e==0) printf("Nincs korrekcio itt: g %f %f\n",Adat[0][0],Adat[0][1]);
				   }  

for(i=0;i<rm;i++){                   
                   e=0;
                   fscanf(fr,"%f %f %f %f\n",&Adat[0][0],&Adat[0][1],&Adat[0][2],&Adat[0][3]);
                   for(j=0;j<m;j++) if( int(Adat[0][0]+0.5)==int(Adatk[j][0]+0.5) ){ e=Adatk[j][3]; j=m+1; }
                   fprintf(frk,"%f %f %f %f\n", Adat[0][0], Adat[0][1]-Cr*e, Adat[0][2], Adat[0][3]);
                   if(e==0) printf("Nincs korrekcio itt: r %f %f\n",Adat[0][0],Adat[0][1]);
				   }

for(i=0;i<im;i++){
                   e=0;
                   fscanf(fi,"%f %f %f %f\n",&Adat[0][0],&Adat[0][1],&Adat[0][2],&Adat[0][3]);
                   for(j=0;j<m;j++) if( int(Adat[0][0]+0.5)==int(Adatk[j][0]+0.5) ){ e=Adatk[j][3]; j=m+1; }
                   fprintf(fik,"%f %f %f %f\n", Adat[0][0], Adat[0][1]-Ci*e, Adat[0][2], Adat[0][3]);
                   if(e==0) printf("Nincs korrekcio itt: i %f %f\n",Adat[0][0],Adat[0][1]);
				   }
                   
for(i=0;i<zm;i++){
                   e=0;
                   fscanf(fz,"%f %f %f %f\n",&Adat[0][0],&Adat[0][1],&Adat[0][2],&Adat[0][3]);
                   for(j=0;j<m;j++) if( int(Adat[0][0]+0.5)==int(Adatk[j][0]+0.5) ){ e=Adatk[j][3]; j=m+1; }
                   fprintf(fzk,"%f %f %f %f\n", Adat[0][0], Adat[0][1]-Cz*e, Adat[0][2], Adat[0][3]);
                   if(e==0) printf("Nincs korrekcio itt: z %f %f\n",Adat[0][0],Adat[0][1]);
				   }              
                   
for(i=0;i<m;i++){
                 if(Adatk[i][3]!=0) fprintf(fszin,"%f %f %f\n",Adatk[i][0],Adatk[i][3],Adatk[i][6]);
                 }


printf("\n\nEnnyi van: szin=%d g=%d r=%d i=%d z=%d \n",m,gm,rm,im,zm);



      //kimenet: d�tum, korr f�nyess�g, f�nyess�g hiba, kivon�s hib�ja !!!
      //x-gorbe   az alap a v�gs� szinkorrig�lt 

fclose(fg);
fclose(fr);
fclose(fi);
fclose(fz);

fclose(fgk);
fclose(frk);
fclose(fik);
fclose(fzk);
fclose(fszin);


printf("\n\nLefutott\n");
getchar();
return 0;		

}

